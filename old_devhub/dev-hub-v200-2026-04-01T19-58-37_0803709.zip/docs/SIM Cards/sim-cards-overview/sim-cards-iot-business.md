---
title: IoT SIM Card Business
excerpt: Basics about the 1NCE IoT SIM Cards Business.
deprecated: false
hidden: false
link:
  new_tab: false
metadata:
  title: 1NCE SIM Cards - IoT Business | 1NCE Developer Hub
  description: ''
  robots: index
---
# IoT SIM Card Business

Although the first, traditional plastic-backed SIM cards were introduced to the mobile network market over 30 years ago, the adapted form factor and technical specifications still apply today as a major key for mobile network communication. As part of the 1NCE connectivity services, the plastic 3in1 IoT SIM Card Business offers the fundamental entrance to the world of mobile IoT communication.

This section will cover the basics about the physical IoT SIM Card Business form factor, technical specifications as well as recommendations for IoT hardware application cases.

![Overview of the 1NCE 3in1 IoT SIM Card Business](https://files.readme.io/613cd18-cliu9g5y5003i0rqmejpnayyt-sim-card.max.png "Overview of the 1NCE 3in1 IoT SIM Card Business, which includes the 2FF, 3FF and 4FF form factors.")

---

## SIM Form Factor

Over the years, with the hardware miniaturization and especially IoT use cases for mobile networks, the physical SIM Card format was adapted multiple times to make the overall footprint smaller. As the SIM chip design and layout was retained to provide backwards combability, the surrounding plastic format was changed. As a result, four common SIM Card form factors (1-4 FF) were established. Original full-size SIM Cards (1FF) had the typical credit card form factor. As this standard is used only rarely today, it has been phased out of production. The remainder 2FF, 3FF and 4FF are still commonly used and sold as 3in1 breakout, plastic-backed SIM Cards. The four SIM Card form factors are specified in [ETSI TS 102 221](https://www.etsi.org/deliver/etsi_ts/102200_102299/102221/15.00.00_60/ts_102221v150000p.pdf). The exact dimension specifications of the form factors are listed in the table below.

|               | 2FF - Mini SIM | 3FF - Micro SIM | 4FF - Nano SIM           |
| :------------ | :------------- | :-------------- | :----------------------- |
| **Height**    | 25mm           | 15mm            | 12.3mm ± 0.1 mm          |
| **Width**     | 15mm           | 12mm            | 8.8mm                    |
| **Thickness** | 0.76mm         | 0.76mm          | 0.67mm +0.03 mm/-0.07 mm |

1NCE IoT SIM Card Business are 3in1 plastic-backed SIMs which incorporate the standardized 2FF Mini, 3FF Micro and 4FF Nano form factors. The 1NCE SIMs are shipped in a half-size carrier to make handling and shipping of the breakout SIMs easier. Depending on the customer needs the IoT SIM Card Business can be carefully broken down into the needed form factor and also reassembled back up to 2FF Mini with the supplied adapters.

![1NCE IoT SIM Card Business 4FF reference dimensions](https://files.readme.io/20aeb83-1NCE_4FF_SIM_Dimensions.png "1NCE IoT SIM Card Business 4FF reference dimensions and pin assignment as of ETSI TS 102 221.")

As 4FF is the smallest form factor that minimizes the plastic-backed SIM Card to the bare IC, we will use it as reference for the pinout. The pinout is the same for all IoT SIM Card Businesses as the SIM IC is identical. Shown above is the pinout reference and dimensions of the 4FF SIM according to [ETSI TS 102 221](https://www.etsi.org/deliver/etsi_ts/102200_102299/102221/15.00.00_60/ts_102221v150000p.pdf). While the 1NCE IoT SIM Card Business 4FF and IoT SIM Chip Industrial form factor are different, the pinout of the actual ICs are the same. The pinout table references the pinout of the dimensional reference figure for the 4FF SIM Card.

| Contact Pin | Spec. Description | 1NCE IoT SIM Card Business Pinout |
|-------------|-------------------|-----------------------------------|
| C1 | **VCC**<br/>Supply Voltage | VCC |
| C2 | **RST**<br/>Reset Pin | RST |
| C3 | **CLK**<br/>Clock Signal | CLK |
| C4 and C8 | **Optional**<br/>USB interface according to ETSI TS 102 600 | N/A |
| C5 | **GND**<br/>Ground Connection | GND |
| C6 | **VPP**<br/>Programming Voltage | N/A |
| C7 | **I/O**<br/>Input Output Data | I/O |

---

## Shipping & Assembly Packaging

1NCE 3in1 IoT SIM Card Business Cards are packaged in a half-size breakout card to save on plastic wastage. This makes handling and shipping of the different SIM form factors easier. Each of these breakout cards, shown below, contains one 3in1 SIM. For easier identification, on the back of the cards a barcode and numerical representation of the EAN code and the ICCID is printed. When ordering low quantities of IoT SIM Card Business, the cards will be packaged and shipped in small plastic wrapped packages. For larger orders will be fulfilled by shipping boxes of 100 or 500 SIMs respectively. These boxes are packaged in sequence, lowest to highest ICCID with a label sticker indicating the first and last ICCID of the box.

![1NCE 3in1 IoT SIM Card Business packaging](https://files.readme.io/a2dce8795d72eda003b894480f74b2ca4184cc2a229c63e32e0fc2a1dbf7baab-SIMCBusiness.png "1NCE 3in1 IoT SIM Card Business inside the half-size breakout card used for easier shipping and packaging.")

---

## SIM ICCID Identification

Each SIM Card can be uniquely identified by the ICCID. This SIM identification is used throughout the 1NCE ecosystem to mark each unique SIM. The ICCID can be read by the hardware modem using an AT-Command or manufacturer specific request. For easier physical identification, each 1NCE IoT SIM Card Business has the ICCID of the particular SIM printed on the 4FF physical chip card.

---

## IoT SIM Card Business Specifications

SIM Cards for mobile network applications follow strict standards for the physical form factor as well as the technology and interfaces. 1NCE IoT SIM Card Business comply with these technical standard specifications. Besides the key standard compliances, SIM Cards are validated for specific environmental ranges in which they need to be operated in. The table below shows the most important 1NCE IoT SIM Card Business specifications that are relevant for the deployment of the 1NCE IoT SIM Card Business. Furthermore, references to the key standard compliances for the SIM interfaces are referenced.

| Parameter | 1NCE IoT SIM Card Business (3in1) |
|-----------|-----------------------------------|
| Form Factors (FF) | 2FF - Mini, 3FF - Micro, 4FF - Nano |
| Supported Radio Access Technologies (RAT) | 2G, 3G, 4G, CAT-M1, NB-IoT |
| Environmental Temperature | -25°C to +85°C |
| Operating Voltages | Class A, B and C (1.8V –5.0V ±10%) |
| Data Retention Period | min. 10 years |
| Read/Write Cycles | min. 500 000 cycles |
| Key Standard Compliances | [3GPP TR 31.919](https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=1833) |
| | [ETSI TS 101 220](https://www.etsi.org/deliver/etsi_ts/101200_101299/101220/13.01.00_60/ts_101220v130100p.pdf) |
| | [ETSI TS 102 221](https://www.etsi.org/deliver/etsi_ts/102200_102299/102221/15.00.00_60/ts_102221v150000p.pdf) |
| | [3GPP TS 31.101](https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=1802) |
| | [3GPP TS 31.111](https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=1807) |
| | [3GPP TR 31.900](https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=1831) |

---

## IoT SIM Card Business Application Cases

As the plastic-backed IoT SIM Card Business is currently still the most commonly used form factor in the mobile communication field, it is best suited as a general purpose SIM for most off-the-shelve, ready-to-use IoT devices. The 3in1 form factor of the 1NCE IoT SIM Card Business is compatible with a wide range of devices which accept this standardized form factor. This form factor of SIM is easy to install, exchange, swappable between devices and ready for the IoT production environment. These key features makes the 1NCE IoT SIM Card Business ideal for every stage of the IoT device life cycle, from early, flexible prototyping to deploying thousands of devices in the field.

For any open questions about the detailed 1NCE IoT SIM Card Business product or more extensive help in selecting the right IoT SIM for the specific application case, feel free to contact us ([1NCE Contact](https://1nce.com/en-eu/support)).