---
title: Features & Limitations
excerpt: >-
  A comprehensive look into what the 1NCE Data Streamer can and cannot do,
  including Network Events, Usage Records, and SMS Events.
deprecated: false
hidden: false
link:
  new_tab: false
metadata:
  title: Data Streamer - Features and Limitations | 1NCE Developer Hub
  description: ''
  robots: index
---
# Features

## Network, Usage, and SMS Event Monitoring

With the 1NCE Data Streamer Service, customers can get live-streamed Network Events, Usage Records, and SMS Events for their 1NCE SIM cards. This comprehensive monitoring solution allows 1NCE customers to track the connectivity status and usage patterns of each SIM individually in near real-time.

### Network Events
Network Events provide detailed insights into device connectivity to the mobile network, including:
- Connection establishment and termination events
- Location updates and network attachments
- Network warnings and error debugging information
- PDP context creation and deletion events
- Mobile network status changes

Network Events help troubleshoot connectivity issues and monitor the overall network performance of your IoT devices.

### Usage Records
Usage Records deliver granular insights into data and SMS volume consumption patterns, including:
- Data traffic volume monitoring (both transmitted and received)
- SMS usage tracking for both mobile-originated (MO) and mobile-terminated (MT) messages
- Volume thresholds and quota management alerts
- Cost tracking and billing insights

Usage Records are generated in real-time, with data session records created after session closure and SMS records generated per individual message.

### SMS Events
SMS Events provide comprehensive monitoring of SMS messaging activity, including:
- Mobile-terminated (MT) SMS delivery status tracking
- Mobile-originated (MO) SMS reception monitoring
- SMS buffering and retry attempt information
- Delivery confirmation and failure notifications
- Message payload and metadata tracking

SMS Events enable full visibility into your device's messaging capabilities and help ensure reliable communication.

## Multi-Target Streaming

The 1NCE Data Streamer Service allows configuring multiple target applications for the same streamed data across all event types. This allows customers to integrate Network Events, Usage Records, and SMS Events into multiple data analytics and monitoring systems simultaneously. Each configured receiver will get the latest updates pushed for all three event types. The individual streams can be configured in the 1NCE Portal under the Configuration Tab, where individual data streams can also be paused/resumed and deleted.

## Data Analytics Platforms

All three event types (Network, Usage, and SMS) can be integrated into the most commonly used platforms for data analytics and monitoring. 1NCE provides ready-to-use integrations for selected 3rd party platforms. Currently the 1NCE Data Streamer supports the following integration options:

* <a href="https://aws.amazon.com/kinesis/" target="_blank">AWS Kinesis</a>
* <a href="https://aws.amazon.com/s3/" target="_blank">AWS S3</a>
* DataDog
* Keen.io

## Custom API Endpoint

In addition to the ready-to-use 3rd party integrations, 1NCE offers the possibility to integrate your own HTTP Post Endpoint which can be configured to receive all three types of records (Network Events, Usage Records, and SMS Events) from the data streamer. Customers can use this integration to include the 1NCE Data Streamer Service into their application or monitoring system of choice.

The HTTP endpoint handles POST requests with a JSON body containing up to 3,000 records per request. Your endpoint should respond with HTTP 200 status code to acknowledge successful receipt - acknowledged records will not be resent.

## Real-Time Processing and Historical Data

The Data Streamer provides near real-time processing of all event types with the option to include historical data from the last seven days during initial setup. This ensures you can start monitoring immediately while maintaining continuity with recent activity.

# Limitations

## Data Retention
Event and usage data in the API is retained for a maximum of seven days due to data retention policies. For long-term storage and analysis, use the Data Streamer Service integrations.

## API Rate Limits
The API is not recommended for large automated queries on a regular basis. For automated monitoring of multiple SIMs, use the Data Streamer Service instead.

## SMS Message Limits
- MT-SMS messages are limited to 160 characters per message
- Concatenated SMS can be sent via API for longer messages
- Default SMS expiry time is 24 hours (customizable)

## Integration Limits
- Up to 10 different data streams can be configured per customer account
- HTTP endpoints must handle POST requests and respond with HTTP 200 status
- Maximum of 3,000 JSON records per HTTP POST request