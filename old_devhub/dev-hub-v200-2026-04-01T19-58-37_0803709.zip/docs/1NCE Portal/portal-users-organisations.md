---
title: Users
excerpt: Managing Users.
deprecated: false
hidden: false
metadata:
  title: 1NCE Portal - Users and Organisation | 1NCE Developer Hub
  description: ''
  robots: index
next:
  description: ''
---
# User Management

The 1NCE Customer Portal offers the option to create multiple user accounts which allows for different user roles and access rights. In the "User" tab a root owner of the account can create and edit new user accounts. A general overview of all current users of the 1NCE organization is provided in a list view.

<Image align="center" alt={1255} border={false} caption="List view of all current active user accounts of the organization." title="1NCE_User_List.PNG" src="https://files.readme.io/a0afaf01e6360e71b0042c05b6eef736863c01482f7ebff05b2bf74e29994ea9-CleanShot_2025-09-26_at_13.13.532x.png" width="80%" />

## User Roles

The following roles for additional user accounts are available:

| Role         | Description                                                                                                                                                                                                                                                                                                                                           |
| :----------- | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Owner        | Initial user of the organization that cannot be changed. Includes all functionalities and access to the entire organization. New users can have the Owner role assigned as well. The owner also has access to the Management API. Can administer users with Admin, User, API User, Read Only. _To administer Owner, please submit a service request._ |
| Adminstrator | Includes all functionalities and access to the entire organization.  Can administer users with User, API User, Read Only, and 3rd party access role. This user role has no access the Management API.                                                                                                                                                 |
| User         | Can manage SIM Cards in the Portal, but has no access to orders and top-ups, and cannot trigger new orders or manage users. This user role has no access to the Mangement API.                                                                                                                                                                        |
| Read Only    | User role designed to allow Read-only access to the Portal. This user role has no access to the Mangement API.                                                                                                                                                                                                                                        |

### User Roles Details

See the following table for an exact overview of the roles and the permissions for each component of the 1NCE Portal.

<HTMLBlock>{`
<style type="text/css">
.tg  {border-collapse:collapse;border-spacing:0;}
.tg td{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:14px;
  overflow:hidden;padding:10px 5px;word-break:normal;}
.tg th{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:14px;
  font-weight:normal;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg .tg-cly1{text-align:left;vertical-align:middle}
.tg .tg-0lax{text-align:left;vertical-align:top}
</style>
<table class="tg">
<thead>
  <tr>
    <th class="tg-0lax" colspan="2">Portal Areas</th>
    <th class="tg-0lax">Owner</th>
    <th class="tg-0lax">Admin</th>
    <th class="tg-0lax">User</th>
    <th class="tg-0lax">Read Only</th>
    <th class="tg-0lax">3rd Party Access</th>
    <th class="tg-0lax">API User</th>
  </tr>
</thead>
<tbody>
  <tr>
    <td class="tg-cly1" rowspan="3">Dashboard</td>
    <td class="tg-0lax">See All</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax" rowspan="42"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Reorder Button</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Latest Order Widget</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-cly1" rowspan="8">My SIMs</td>
    <td class="tg-0lax">See All</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">SIM State</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">IMEI Lock</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Auto-Top-Up</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Reset Connectivity</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">SIM List Export</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Reorder / Top-Up</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Send SMS</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-cly1" rowspan="9">Configuration</td>
    <td class="tg-0lax">Network Settings</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Breakout Settings</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Monthly Limit</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">IMEI Lock</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Auto-Top-Up</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Data Streams</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">SMS Forwarder</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">OpenVPN</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Management API</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">1NCE OS</td>
    <td class="tg-0lax">Tab Available</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-cly1" rowspan="6">Account</td>
    <td class="tg-0lax">See All</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Customer Data</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">User Data</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Add New E-Mail</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Billing and Shipping Address</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Payment Details</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-cly1" rowspan="4">Orders</td>
    <td class="tg-0lax">See All</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Download Invoices</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Trigger New Order</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Download Affected SIMs</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-cly1" rowspan="5">Users</td>
    <td class="tg-0lax">See All</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">Administer Own User</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">Administer Owner</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">Administer Admin</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">Administer User</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">Administer API User</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">Administer Read Only</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">Administer 3rd party access</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-cly1" rowspan="3">Organisation</td>
    <td class="tg-0lax">See All</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Add Organisation</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">SIM Transfer</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Performance</td>
    <td class="tg-0lax">See All</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-cly1" rowspan="2">Support</td>
    <td class="tg-0lax">See All</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">New Service Request</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">API Access</td>
    <td class="tg-0lax"></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
</tbody>
</table>
`}</HTMLBlock>

## User Creation

A new user can be created using the "New User" button on the top right. The mandatory details depend on the type of the user that needs to be created. The e-mail address is used for the confirmation of the account as well as the login name for the 1NCE services. Customers have to make sure that the entered e-mail address is valid and can receive messages. After creating a new user an e-mail is sent to the new mail address requesting to set an initial new password for the 1NCE Customer Portal.

<Image align="center" alt={1131} border={false} caption="New User popup for creating a new user and attaching a user role." title="1NCE_Add_User.png" src="https://files.readme.io/3b8d1a9fb7e070e40e352faf3df0bef8980257ae245cb24fa4ce5c8ad41fc9aa-CleanShot_2025-09-26_at_13.14.542x.png" width="80%" />

## User Account Alteration

By clicking on a user shown in the list of current users, the details of this account can be changed or deleted. Changes can be applied by editing the boxes in the form and saving the new data. A user can be deleted by clicking on the "Delete" button in the Edit User popup.

<Image align="center" alt={1132} border={false} caption="User Edit popup windows used for editing user details or deleting a user." title="1NCE_User_Edit.png" src="https://files.readme.io/694845b9eafe7f8c1f050e820684b02ecd6a09bced9070761895fdd636cbbf0a-CleanShot_2025-09-26_at_13.15.152x.png" width="80%" />
