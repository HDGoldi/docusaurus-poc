---
title: Performance & Support
excerpt: Monitoring 1NCE Services & Getting Support
deprecated: false
hidden: false
metadata:
  title: 1NCE Portal - Performance and Support | 1NCE Developer Hub
  description: ''
  robots: index
next:
  description: ''
---
# Performance

The performance dashboard provides an insight into the key components and their current status of the 1NCE Services. In case of any incident, the status of the particular service will change accordingly. Customers can use this page to get a better understanding of a current incident and receive updates.

Below the overview, a list of recent incidents in the network with a detailed description is listed.

<Image alt="The 1NCE Performance dashboard, showing the current status of all 1NCE Services." align="center" src="https://files.readme.io/330e922e9b61a5e1bf2b845ad9ada5c11d2e8274ebb38eb18cc98efe3401a0a1-CleanShot_2025-09-26_at_13.16.162x.png">
  The 1NCE Performance dashboard, showing the current status of all 1NCE Services.
</Image>

***

# Support

Through the "Support" tab, 1NCE customers can quickly access documentation resources as well as technical support and customer service. On the page, links to the 1NCE Developer Hub, API Reference and a search integration for the documentation is given.

<Image title="Support DevHub.PNG" alt={1412} align="center" src="https://files.readme.io/cd14abf9c8b4465c2bf337a73061988a422378f9b1b7a8db84d711c311edd873-CleanShot_2025-09-26_at_13.16.342x.png">
  Support page, with references to the Developer Hub, API Reference and Customer Service.
</Image>

Technical support and customer service is provided either directly via phone or by placing a new service request ticket. The access to technical support is only available for existing customers. Customer service is provided either in German or English language. Telephone support is available from Monday to Friday from 9 a.m. to 6 p.m. (CET/CEST) (except for national public holidays). Tickets are mainly processed within the service hours.
