---
title: Configuration
excerpt: 1NCE Services Configuration and Setup
deprecated: false
hidden: false
link:
  new_tab: false
metadata:
  title: 1NCE Portal - Configuration | 1NCE Developer Hub
  description: ''
  robots: index
---
# Network Settings

The network settings contain the basic information to get the SIM Cards connected to the 1NCE network.

| Parameter           |                                                                                                                                                                                                                                                                      |
| :------------------ | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `APN`               | Needs to be set in the very first step to set up a connection to the network.                                                                                                                                                                                        |
| `SMSC Number`       | Is generally needed to aim all Mobile Originated SMS in the network, although this setting is rarely needed for manual configuration.                                                                                                                                |
| `Internet Breakout` | Shows the IP addresses used for all 1NCE SIMs to access the public internet through a NAT. Get all available [Internet Breakout IPs](https://help.1nce.com/dev-hub/docs/network-services-internet-breakout)                                                          |
| `IP Address Space`  | Shows the IP spaces assigned to SIMs in the given organization. Each SIM has a static IP address which can to be used for direct access via the VPN Service. Additional IP spaces will be assigned for new SIM orders if the remaining IP space is not large enough. |
| `IP Addresses`      | Shows the availability of the IP address spaces assigned to the organization.                                                                                                                                                                                        |

<Image align="center" alt="Network Settings in the Configuration tab." border={false} src="https://files.readme.io/aeb241aa06b66c63c00011a6aafe5560534c95173e9899a4a3be45e062eb137c-Screenshot_from_2025-10-13_22-31-32.png" />

***

# Monthly Limits

By using "Monthly Limits" a customer can set an individual monthly data and SMS limit. The SMS limit can be configured separately for Mobile Originated (MO) and Mobile Terminated (MT) SMS. These limits will be applied to all of the customer's SIMs. By checking or unchecking the boxes these options can be set or cancelled easily at any time. The limits apply to the period of the calendar month. Putting another limit in the same month will not reset the previously consumed quota.
Example: The first limit is 100 MB. After reaching it you put in 200 MB as a new limit. Now only 100 additional MB can be consumed because the previously consumed 100 MB are considered.

## Exceeding the Limits

When the self-set limits are exceeded, error or warning messages are triggered based on the type of limit.

### Data Session

When the limit is reached, new PDP data sessions will be rejected: **PDP Context Request rejected, because endpoint is currently blocked due to exceeded traffic limit.**  However, some devices might retry indefinitely to reconnect in such a case. 1NCE strongly advices to use a back-off approach in this rejection case to not flood the network with PDP session requests.

### MT-SMS

Using the 1NCE API, if the self-set limit for MT-SMS is reached, **Traffic limit of X SMS per month exceeded** is returned as error.
In the 1NCE Portal **Set monthly limit of SMS exceeded** is shown, when the MT-SMS limit was reached and a new SMS is issued.

### MO-SMS

For **MO-SMS** no notification will be shown in the 1NCE Portal or Data Stream. The SMS will be rejected by the network resulting in an error return code from the device modem.

<Image alt="Monthly Limits configuration for Data and MO-/MT-SMS." border={false} src="https://files.readme.io/c8d77b66ba6ba12172f6249d362d6f4ca8380b1986da4485396ee9d92dfa2114-CleanShot_2025-09-26_at_13.04.282x.png" />

***

# Global IMEI Lock

A global IMEI Lock can be set for all SIM Cards of the organization. The IMEI lock works by saving the IMEI of the device the SIM is installed in. With the feature enabled, the 1NCE network will only accept the saved device IMEI - SIM card combination to access the network resource. Any other IMEI - SIM combination will be refused. If this feature is activated, the IMEI lock will be set during the next network attach. Consequently the SIM card can only be used with the current device. For new SIM Card orders a checkbox can be selected to enable the IMEI lock by default. This way newly ordered SIMs will have the IMEI Lock set automatically. A separate IMEI lock for individual cards of the organization can be set either via the 1NCE API or in the "My SIMs" tab.

<img src="https://files.readme.io/cef13621e996114510632031ee01fbad2ac8679975fcf187a623ba4f02313a06-CleanShot_2025-09-26_at_13.04.462x.png" alt="Global IMEI SIM lock settings." style={{ width: '80%', display: 'block', margin: '0 auto' }} />

***

# Data Streams

The 1NCE Data Streaming Service allows customers to subscribe to real-time events and usage data for all SIM Cards by pushing data directly to the customer's server or an already integrated cloud service such as AWS Kinesis.

The Data Streams configuration shows a list of all currently configured streams including the name, API type, stream type, URL, status indicator and controls for each stream. Each stream can be controlled individually. Besides basic stop, start and delete, a stream integration can be restarted. A restart needs to be performed if the stream enters a error state and needs to be recovered.

To create a new data stream integration click on the New Data Stream button. Further details on how to setup a stream integration can be found in the [Data Streamer Setup Guides](doc:streamer-setup) section of the Developer Hub.

<img src="https://files.readme.io/c73282d01529a325637692194a720826c9182d8f3a84c65b90ecdacc4ef4ba91-CleanShot_2025-09-26_at_13.04.462x.png" alt="Overview of the current Data Streamer integrations." style={{ width: '80%', display: 'block', margin: '0 auto' }} />

<br />

***

# OpenVPN Configuration

OpenVPN is the recommended application setup by 1NCE to establish a secure, bidirectional data connection between the 1NCE network and the customer server.

When the should OpenVPN be used first, on the account the enrollement to the service needs to be starte.

<Image alt="Specific configuration for Manual Mode (Europe) breakout." border={false} src="https://files.readme.io/050b1c58c91a310a940f69bacc4323157d6b9ca85c9831f4c5c49172a6f153c0-CleanShot_2025-09-26_at_13.10.002x.png" />

The OpenVPN client needs to be installed on the customer server to which the SIMs should access via the VPN client IP. For the OpenVPN connection to the 1NCE network a configuration file and credentials file is needed. These files can be downloaded in this section of the 1NCE Customer Portal. There are two different versions for Windows and for Linux/MacOS available. For more details about the VPN Service, its setup and operation users can proceed to the [VPN Service](doc:network-services-vpn-service) section of the Developer Hub.
