---
title: Account
excerpt: Account Management
deprecated: false
hidden: false
metadata:
  title: 1NCE Portal - Accounts and Orders | 1NCE Developer Hub
  description: ''
  robots: index
next:
  description: ''
---
# Account

The "Account" tab allows the customer to view and edit their personal/company data, billing and shipping addresses as well as to manage the Auto-Top-Up payment.

> ❗️ Non-Changeable Data Fields
>
> Due to legal reasons we cannot allow to change the company name or billing country of the billing address. For assistance please contact our support.

In the Customer and User Data dropdown, the contact information and account details for the root organization and for the logged-in user can be viewed and changed. Note that the e-mail address shown in the Customer Data column is the main contact where all invoices are being sent to digitally. An additional e-mail address can be stored which receives the invoices in copy, for example the accounting department. Please select the category "Invoice" for that.
Furthermore the category "Volume Notifications" can be selected. This includes all e-mails on volume notifications for data/SMS as well as reaching the monthly set volume limit.
The language selection defines the contact language meaning e-mails, invoices and service notifications.

In the User Data column information regarding the currently logged-in user data can be viewed and changed. The logged-in user (no matter which role) can change their personal details like name and e-mail address as well as password. These details can also be changed by an Admin or Owner via the "Users" tab except the password for the roles Owner, Admin and User.

The Billing and Shipping Addresses dropdown shows all saved billing and shipping addresses. Existing entries can be changed and new addresses can be added by the customer for future orders. The addresses are stored and will appear each time the user orders additional SIM cards or Top-Ups.

<Image align="center" alt={898} border={false} caption="Account page with customer details, shipping and billing addresses." title="220422_Account_tab.PNG" src="https://files.readme.io/ca27c6dd20a72ca43a5066ea06bed894932fb0c50f5c3ad8b7de0c37042cfec3-account1.png" width="80%" />

***

# Orders

In the "Orders" tab, all orders from the organization's 1NCE account are listed. The table provides an overview of the important order parameters as well as the current status of an order. The status indicator (completed, in preparation or cancelled) can be used to monitor pending orders.
On this page, previous invoices of specific orders can be downloaded. Additionally, a CSV list of all SIMs of a particular order can be downloaded using the link in the "Affected SIMs" column. This list for a dedicated order consists of ICCID, label, IMSI and MSISDN of the SIMs. In case there has been any correction to the order, the corrected or updated invoices can be downloaded in the column "Additional Documents".

<Image align="center" alt={1350} border={false} caption="Orders tab with past orders and corresponding invoices and SIM files" title="20220218_Orders.PNG" src="https://files.readme.io/4d5df8f0b8e5723b572e08582062bfb9afa74e574a0b1a86634c816785363983-CleanShot_2025-09-26_at_13.12.132x.png" />

<br />

# Management API Access

We offer RESTful APIs for seamless device management. To access them, generate API credentials in the section below. Communication with the API is done over HTTP(S) requests with JSON body content of content-type "application/json" and authorization type oauth2 (OAuth2, application) required for every API call.

<Image align="center" alt={1350} border={false} caption="Generation of new API credentials." title="20220218_Orders.PNG" src="https://files.readme.io/08d136a345c2d1fc342ca8ee10e8ca55f2147c571a1ecde9a4f92db31ac6da4f-CleanShot_2025-09-26_at_13.12.582x.png" />