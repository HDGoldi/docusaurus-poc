---
title: Data Streamer Service
excerpt: Setup Guides and Examples for all Data Streamer Integrations.
deprecated: false
hidden: false
metadata:
  title: Examples - Data Streamer Service | 1NCE Developer Hub
  description: ''
  robots: index
next:
  description: ''
---
The 1NCE Data Streamer offers multiple integration possibilities. For each of the available integrations 1NCE provides a setup guide and examples for testing. Please click on one of the icons to get to the setup guide for the selected integration.

<HTMLBlock>{`
<div class="button-flex-container">
	<div class="button-flex-item">
    <a href="examples-data-streamer-http">
      	<img src="https://files.readme.io/d47972b-rest_api.svg"></img> 
    </a>
	</div>
<div class="button-flex-item">
  <a href="examples-data-streamer-kinesis">
		<img src="https://files.readme.io/c2c9384-aws_kinesis.svg"> </img>
  </a>
	</div>
</div>
`}</HTMLBlock>
