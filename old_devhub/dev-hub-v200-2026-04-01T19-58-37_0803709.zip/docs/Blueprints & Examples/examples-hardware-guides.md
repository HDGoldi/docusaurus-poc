---
title: Hardware & Modem Guides
excerpt: Code examples for using 1NCE with specific Modems and Devices.
deprecated: false
hidden: false
link:
  new_tab: false
  url: https://help.1nce.com/dev-hub/page/recipes
metadata:
  title: Examples - Hardware Guides | 1NCE Developer Hub
  description: ''
  robots: index
next:
  description: ''
---