---
title: Welcome
excerpt: Welcome to the 1NCE Developer Hub!
deprecated: false
hidden: false
metadata:
  title: Introduction - Welcome | 1NCE Developer Hub
  description: Digging into the 1NCE Documentation Guide!
  robots: index
next:
  description: ''
---
<HTMLBlock>{`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Documentation Selector</title>
    <style>
        
        .option-container {
            background-color: #e6eaed;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .option-title {
            font-size: 20px;
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }
        
        .option-description {
            margin-bottom: 15px;
            color: #444;
        }
        
        .countries-box {
            background-color: white;
            border-radius: 10px;
            padding: 15px;
            margin: 15px 0;
            font-style: italic;
        }
        
        .date-highlight {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="option-container">
        <div class="option-title">1. Updated Documentation for Eligible Customers</div>
        <div class="option-description">
            For <b>new</b> customers in selected countries who purchased their first SIMs on/after <span class="date-highlight">6 October 2025</span> and are located in one of the following countries:
        </div>
        <div class="countries-box">
           Albania, Austria, Aland Islands, Bosnia And Herzegovina, Belgium, Bulgaria, Switzerland, Cyprus, Czech Republic, Germany, Denmark, Estonia, Spain, Finland, France, United Kingdom, French Guiana, Guadeloupe, Greece, Croatia, Hungary, Ireland, Iceland, Italy, Liechtenstein, Lithuania, Luxembourg, Latvia, Monaco, Moldova, Republic of, Montenegro, North Macedonia, Martinique, Malta, Netherlands, Norway, Poland, Portugal, Romania, Serbia, Sweden, Slovenia, Slovakia, San Marino, Ukraine
        </div>
        <a href="https://help.1nce.com/dev-hub/v200/docs/introduction-welcome" class="continue-btn">Continue (V2.0)</a>
    </div>
    
    <div class="option-container">
        <div class="option-title">2. General Documentation</div>
        <div class="option-description">
            For customers who purchased their SIM before <span class="date-highlight">6 October 2025</span> or are not located in one of the countries listed above.
        </div>
        <a href="https://help.1nce.com/dev-hub/docs/introduction-welcome" class="continue-btn">Continue (V1.0)</a>
    </div>
</body>
</html>
`}</HTMLBlock>
