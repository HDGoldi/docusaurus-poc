---
title: Bearer Authorization
hidden: false
---