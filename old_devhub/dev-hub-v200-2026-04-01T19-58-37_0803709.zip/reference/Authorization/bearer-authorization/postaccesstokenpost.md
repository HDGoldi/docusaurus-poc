---
title: Obtain Access Token
excerpt: >-
  Obtain a token for accessing other 1NCE API resources by using a POST request
  with a valid username and password combination for a 1NCE user account that
  has the permission to use the API.
api:
  file: 0_1nce_authorization.yaml
  operationId: postAccessTokenPOST
hidden: false
---
<Callout icon="❗️" theme="error">
  Dedicated **API credentials** required. Creation of API Keys in Customer Portal under the Account Tag -> Management API access
</Callout>