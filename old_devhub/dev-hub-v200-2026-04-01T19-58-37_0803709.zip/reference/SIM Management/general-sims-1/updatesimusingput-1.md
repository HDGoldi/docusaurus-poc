---
title: Modify SIM card
excerpt: >-
  Modification of a SIM card to activate, deactivate, change label, change IMEI
  lock, etc.
api:
  file: sim-management.json
  operationId: updateSimUsingPUT
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---