---
title: Get Single SIM
excerpt: >-
  Get detail information (status, label, MSISDN, IMSI, ICCID, Lifetime, etc.)
  for a singe SIM based on the ICCID.
api:
  file: sim-management.json
  operationId: getSimUsingGET
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---