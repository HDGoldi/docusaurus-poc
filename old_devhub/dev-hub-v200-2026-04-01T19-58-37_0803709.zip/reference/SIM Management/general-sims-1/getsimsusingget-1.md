---
title: Get All SIMs
excerpt: Get a List of SIMs for the current account.
api:
  file: sim-management.json
  operationId: getSimsUsingGET
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---