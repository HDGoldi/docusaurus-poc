---
title: Get SIM Status
excerpt: >-
  Query the current status of a specific SIM card.


  This API retrieves connectivity details of a SIM. The following is a list of
  possible statuses: 

  * `ATTACHED`:
      The Endpoint has successfully attached to the Home Core network in the past.
      The device will be shown as `ATTACHED` until the visited network has signaled that the device is inactive/offline.
      Usually the visited network informs the Core Network within 1-2 days after a device went offline.

  * `ONLINE`:
      The Endpoint has an active data connection

  * `OFFLINE`:
      The Endpoint has not attached to the core network yet or the device was previously attached but the visited network signaled that the device had no activity for the last 1-2 days.
      Note: The device is not reachable for external services (e.g. SMS, MSRN lookup).

  * `BLOCKED`:
      The Endpoint is blocked
api:
  file: sim-management.json
  operationId: getStatusForSimUsingGET
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---