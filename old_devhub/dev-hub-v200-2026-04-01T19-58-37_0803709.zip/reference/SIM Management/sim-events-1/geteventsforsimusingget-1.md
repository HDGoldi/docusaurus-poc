---
title: Get SIM Events
excerpt: Get diagnostic/event information for a SIM card.
api:
  file: sim-management.json
  operationId: getEventsForSimUsingGET
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---