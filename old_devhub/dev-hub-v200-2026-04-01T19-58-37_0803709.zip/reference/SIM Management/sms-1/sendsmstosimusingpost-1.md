---
title: Create SMS
excerpt: Create and send an MT-SMS to a device.
api:
  file: sim-management.json
  operationId: sendSmsToSimUsingPOST
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---