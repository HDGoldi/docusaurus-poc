---
title: Get MT/MO-SMS
excerpt: Get a list of SMS sent and received by a specific SIM card.
api:
  file: sim-management.json
  operationId: getSmsForSimUsingGET
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---