---
title: Create Single Top Up
excerpt: Top up the data/SMS volume of one specific SIM.
api:
  file: sim-management.json
  operationId: topUpUsingPOST
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---