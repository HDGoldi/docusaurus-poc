---
title: Get SIM SMS Quota
excerpt: Get the current SMS quota of a particular SIM.
api:
  file: sim-management.json
  operationId: getSmsQuotaForSimUsingGET
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---