---
title: Get SIM Data Quota
excerpt: Get the current data quota of a particular SIM.
api:
  file: sim-management.json
  operationId: getDataQuotaForSimUsingGET
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---