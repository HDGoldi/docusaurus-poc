---
title: Create Connectivity Reset
excerpt: >-
  Trigger a connectivity reset for a given SIM. The actual reset will be done
  asynchronously. A positive-response only means that the connectivity-reset has
  been successfully placed into the queue.
api:
  file: sim-management.json
  operationId: resetConnectivityUsingPOST
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---