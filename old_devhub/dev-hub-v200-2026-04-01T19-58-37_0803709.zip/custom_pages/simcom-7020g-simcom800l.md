---
title: SIMCOM 7020G & SIMCOM800L
fullscreen: false
hidden: false
metadata:
  title: ''
  description: ''
---
SIMCom SIM7020E is a Multi-Band NB-IoT module solution in a SMT format for the European market. It has strong extension capability with rich interfaces including UART, GPIO etc.  
The package of SIM7020 is compatible with SIM800C.

# Network Registration

[block:tutorial-tile]
{
  "backgroundColor": "#018FF4",
  "emoji": "📲",
  "id": "665d794b229ccf003029f496",
  "link": "https://help.1nce.com/v2.4.14/recipes/sim800l-network-registration",
  "slug": "sim800l-network-registration",
  "title": "SIM800L Network Registration"
}
[/block]


# ICMP PING

[block:tutorial-tile]
{
  "backgroundColor": "#018FF4",
  "emoji": "📲",
  "id": "665d794b229ccf003029f491",
  "link": "https://help.1nce.com/v2.4.14/recipes/sim800l-icmp-ping",
  "slug": "sim800l-icmp-ping",
  "title": "SIM800L ICMP Ping"
}
[/block]


# SIM800L MO-SMS

[block:tutorial-tile]
{
  "backgroundColor": "#018FF4",
  "emoji": "📲",
  "id": "665d794b229ccf003029f494",
  "link": "https://help.1nce.com/v2.4.14/recipes/sim800l-mo-sms",
  "slug": "sim800l-mo-sms",
  "title": "SIM800L MO-SMS"
}
[/block]


# SIM800L MT-SMS

[block:tutorial-tile]
{
  "backgroundColor": "#018FF4",
  "emoji": "📲",
  "id": "665d794b229ccf003029f495",
  "link": "https://help.1nce.com/v2.4.14/recipes/sim800l-mt-sms",
  "slug": "sim800l-mt-sms",
  "title": "SIM800L MT-SMS"
}
[/block]


# SIM800L HTTP GET

this functionality used just for SIM800L not SIM7020G

[block:tutorial-tile]
{
  "backgroundColor": "#018FF4",
  "emoji": "📲",
  "id": "665d794b229ccf003029f493",
  "link": "https://help.1nce.com/v2.4.14/recipes/sim800l-http-get",
  "slug": "sim800l-http-get",
  "title": "SIM800L HTTP GET"
}
[/block]


# SIM800L HTTP POST

[block:tutorial-tile]
{
  "backgroundColor": "#018FF4",
  "emoji": "📲",
  "id": "665d794b229ccf003029f49a",
  "link": "https://help.1nce.com/v2.4.14/recipes/sim800l-http-post",
  "slug": "sim800l-http-post",
  "title": "SIM800L HTTP POST"
}
[/block]


# SIM800L & SIM7020G TCP Client

[block:tutorial-tile]
{
  "backgroundColor": "#018FF4",
  "emoji": "📲",
  "id": "665d794b229ccf003029f498",
  "link": "https://help.1nce.com/v2.4.14/recipes/sim800l-tcp-client-connection",
  "slug": "sim800l-tcp-client-connection",
  "title": "SIM800L TCP Client Connection"
}
[/block]


# 1NCE OS UDP Protocol

[block:tutorial-tile]
{
  "backgroundColor": "#018FF4",
  "emoji": "📲",
  "id": "665d794b229ccf003029f499",
  "link": "https://help.1nce.com/v2.4.14/recipes/sim800l-udp-client-connection",
  "slug": "sim800l-udp-client-connection",
  "title": "SIM800L UDP Client Connection"
}
[/block]


# 1NCE OS CoAP Protocol

[block:tutorial-tile]
{
  "backgroundColor": "#018FF4",
  "emoji": "🦉",
  "id": "665d794b229ccf003029f4b2",
  "link": "https://help.1nce.com/v2.4.14/recipes/sim7000g-1nce-os-coap",
  "slug": "sim7000g-1nce-os-coap",
  "title": "SIM7000G 1NCE OS COAP"
}
[/block]