---
title: Recipes
fullscreen: false
hidden: false
metadata:
  title: Hardware Recipes | 1NCE Developer Hub
  description: ''
---
## Quectel

Quectel is a leading provider of cellular and GNSS modules, with a wide range of products available. Here are some resources to help you get started with Quectel modules using our 1NCE services:

[Quectel BG95](https://help.1nce.com/dev-hub/page/quectel-bg95-m3)

[Quectel EC25 & EC21](https://help.1nce.com/dev-hub/page/quectel-ec25-ec21)

## SIMCOM

SIMCOM is a global provider of wireless modules and solutions, offering a range of products for different applications. Here are some resources to help you get started with SIMCOM modules using 1NCE services:

[SIMCOM7020E](https://help.1nce.com/dev-hub/page/simcom-7020g-simcom800l)

[SIM7000G](https://help.1nce.com/dev-hub/page/sim7000g)

## UBlox

u-blox is a leading provider of positioning and wireless communication technologies for the automotive, industrial, and consumer markets. Here are some resources to help you get started with u-blox modules using 1NCE services:

[SARA-R410M](https://help.1nce.com/dev-hub/page/sara-r410m)

## Others

[block:tutorial-tile]
{
  "backgroundColor": "#018FF4",
  "emoji": "📶",
  "id": "665d794b229ccf003029f492",
  "link": "https://help.1nce.com/v2.4.14/recipes/wvdial-tutorial",
  "slug": "wvdial-tutorial",
  "title": "WvDial Tutorial"
}
[/block]


 **1NCE VPN** establishes a secure and encrypted tunnel between your device and the VPN server. This ensures that your online activities, such as communication, are protected from eavesdropping, hacking, and surveillance.

[block:tutorial-tile]
{
  "backgroundColor": "#018FF4",
  "emoji": "🖥️",
  "id": "665d794b229ccf003029f497",
  "link": "https://help.1nce.com/v2.4.14/recipes/1nce-vpn-linux-client",
  "slug": "1nce-vpn-linux-client",
  "title": "1NCE VPN Linux Client"
}
[/block]