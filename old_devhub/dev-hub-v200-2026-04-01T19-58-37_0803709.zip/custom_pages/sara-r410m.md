---
title: SARA-R410M
fullscreen: false
hidden: false
metadata:
  title: ''
  description: ''
---
SARA-R410M AT command interface defaults to the GSM character set.  
Developers could understand and develop applications quickly and efficiently based on these recipes.

# Network Registration:

[block:tutorial-tile]
{
  "backgroundColor": "#018FF4",
  "emoji": "🦉",
  "id": "665d794b229ccf003029f4b3",
  "link": "https://help.1nce.com/v2.4.14/recipes/sara-r410m-network-registration",
  "slug": "sara-r410m-network-registration",
  "title": "SARA-R410M Network Registration"
}
[/block]


# SARA-R410M HTTP GET

[block:tutorial-tile]
{
  "backgroundColor": "#018FF4",
  "emoji": "🦉",
  "id": "665d794b229ccf003029f4b5",
  "link": "https://help.1nce.com/v2.4.14/recipes/sara-r4-get-http",
  "slug": "sara-r4-get-http",
  "title": "SARA-R4 GET HTTP"
}
[/block]


# 1NCE OS UDP

[block:tutorial-tile]
{
  "backgroundColor": "#018FF4",
  "emoji": "🦉",
  "id": "665d794b229ccf003029f4b4",
  "link": "https://help.1nce.com/v2.4.14/recipes/sara-r410m-1nce-os-udp",
  "slug": "sara-r410m-1nce-os-udp",
  "title": "SARA-R410M 1NCE OS UDP"
}
[/block]