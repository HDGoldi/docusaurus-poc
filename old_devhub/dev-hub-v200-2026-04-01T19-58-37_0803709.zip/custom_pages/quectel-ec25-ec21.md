---
title: Quectel EC25 & EC21
fullscreen: false
hidden: false
metadata:
  title: ''
  description: ''
---
EC25 & EC21 AT command interface defaults to the GSM character set. EC25 & EC21 modules support  
the following character sets:

- GSM format
- UCS2
- IRA

# EC25 RAT Configuration

Setup and configure the Quectel EC25 or EC21 for use with 1NCE SIM.

[block:tutorial-tile]
{
  "backgroundColor": "#018FF4",
  "emoji": "📲",
  "id": "665d794b229ccf003029f4a5",
  "link": "https://help.1nce.com/v2.4.14/recipes/ec25-rat-configuration",
  "slug": "ec25-rat-configuration",
  "title": "EC25 RAT Configuration"
}
[/block]


# Network Registration:

Network registration is the process by which a cellular device connects to a cellular network and obtains the necessary credentials to access the network's services. This process involves several steps, including network selection, authentication, and registration.

[block:tutorial-tile]
{
  "backgroundColor": "#018FF4",
  "emoji": "📲",
  "id": "665d794b229ccf003029f4a6",
  "link": "https://help.1nce.com/v2.4.14/recipes/ec25-network-registration",
  "slug": "ec25-network-registration",
  "title": "EC25 Network Registration"
}
[/block]


# ICMP Ping

Connect with the EC25 or EC21 to a mobile network, start a data session, and issue an ICMP Ping request. 

[block:tutorial-tile]
{
  "backgroundColor": "#018FF4",
  "emoji": "📲",
  "id": "665d794b229ccf003029f4a7",
  "link": "https://help.1nce.com/v2.4.14/recipes/ec25-icmp-ping",
  "slug": "ec25-icmp-ping",
  "title": "EC25 ICMP Ping"
}
[/block]


# MO-SMS

Send an SMS message from an EC25 or EC21 to the 1NCE SMS Forwarding Service.

[block:tutorial-tile]
{
  "backgroundColor": "#018FF4",
  "emoji": "📲",
  "id": "665d794b229ccf003029f4a8",
  "link": "https://help.1nce.com/v2.4.14/recipes/ec25-mo-sms",
  "slug": "ec25-mo-sms",
  "title": "EC25 MO-SMS"
}
[/block]


# MT-SMS

Receive SMS messages with a Quectel EC25 or EC21.

[block:tutorial-tile]
{
  "backgroundColor": "#018FF4",
  "emoji": "📲",
  "id": "665d794b229ccf003029f4a9",
  "link": "https://help.1nce.com/v2.4.14/recipes/ec25-mt-sms",
  "slug": "ec25-mt-sms",
  "title": "EC25 MT-SMS"
}
[/block]


# TCP Client

Connect to a TCP Server and send/receive data using a Quectel EC25 or EC21.

[block:tutorial-tile]
{
  "backgroundColor": "#018FF4",
  "emoji": "📲",
  "id": "665d794b229ccf003029f4aa",
  "link": "https://help.1nce.com/v2.4.14/recipes/ec25-tcp-client-connection",
  "slug": "ec25-tcp-client-connection",
  "title": "EC25 TCP Client Connection"
}
[/block]


# 1NCE OS UDP Protocol

[block:tutorial-tile]
{
  "backgroundColor": "#018FF4",
  "emoji": "🦉",
  "id": "665d794b229ccf003029f4af",
  "link": "https://help.1nce.com/v2.4.14/recipes/ec25-ec21-1nce-os-udp",
  "slug": "ec25-ec21-1nce-os-udp",
  "title": "EC25 & EC21 1NCE OS UDP"
}
[/block]