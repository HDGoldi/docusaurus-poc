---
title: Admin Logs
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: 1NCE OS - Admin Logs | 1NCE Developer Hub
  description: ''
  robots: index
next:
  description: ''
---
As 1NCE OS is intended to ease the entry into IoT applications, the 1NCE Admin Logs provides an aggregator of events from devices and errors. From the Admin Logs, the events and errors can be viewed via the Web Interface or queried using the Management API for further processing.
