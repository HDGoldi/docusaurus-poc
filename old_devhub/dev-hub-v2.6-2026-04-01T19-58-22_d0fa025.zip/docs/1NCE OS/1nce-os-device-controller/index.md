---
title: Device Controller
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: 1NCE OS - Device Controller | 1NCE Developer Hub
  description: ''
  robots: index
next:
  description: ''
---
The Device Controller supports sending messages to the device via the 1NCE OS managed services. For that we offer three protocols in Device Integrator.

<Image title="IoT Integrator" alt="Device Controller as part of the IoT Integrator" align="center" width="80%" src="https://files.readme.io/d496e66-IoT_Integrator.png">
  Device Controller as part of the IoT Integrator
</Image>
