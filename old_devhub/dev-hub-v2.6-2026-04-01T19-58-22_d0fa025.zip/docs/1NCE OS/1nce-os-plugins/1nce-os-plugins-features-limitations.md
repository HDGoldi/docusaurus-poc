---
title: Features & Limitations
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: Plugins - Features and Limitations | 1NCE Developer Hub
  description: ''
  robots: index
next:
  description: ''
---
# Features

* All [Event Types](doc:1nce-os-cloud-integrator#event-types) from 1NCE OS will be forwarded to Plugins.\
    *Doesn't apply for Mender and Memfault plugin*

* [Event Types](doc:1nce-os-cloud-integrator#event-types) messages will be forwarded in JSON format.\
  *Doesn't apply for Mender and Memfault plugin*

# Limitations

* The plugin cannot be edited. It should be reinstalled if any changes are required.
* Only one entity per Plugin type is allowed to be created.
