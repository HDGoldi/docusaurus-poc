---
title: Energy Saver
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: 1NCE OS - Energy Saver | 1NCE Developer Hub
  description: ''
  robots: index
next:
  description: ''
---
<Image width="80% " src="https://files.readme.io/a82aa07-1NCE-OS-Grafiken-202211221024_7.png" />

With the energy saver, 1NCE offers a simple way to decode freeform third-party binary payloads. With the help of BCL, JSON objects are created. This chapter will guide through the setup and usage process with full examples and code snippets.
