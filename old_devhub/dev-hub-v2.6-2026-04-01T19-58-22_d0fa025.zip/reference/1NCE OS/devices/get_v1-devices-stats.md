---
title: Get Devices Statistics
excerpt: Get general statistics related to customer devices
api:
  file: 1nce-os.json
  operationId: get_v1-devices-stats
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---