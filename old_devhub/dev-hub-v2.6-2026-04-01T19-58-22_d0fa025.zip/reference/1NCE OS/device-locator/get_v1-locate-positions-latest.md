---
title: Get Latest Devices Positions
excerpt: >
  Get latest positions of customer devices (maximum of last 7 days). Only one
  latest position is possible for a single device independent of source: either
  Celltower or GPS. This means that `source` query parameter selection can lead
  to no latest position returned for some devices.

  ![Creative Commons
  License](https://mirrors.creativecommons.org/presskit/buttons/80x15/svg/by-sa.svg)
  [OpenCelliD Project](https://opencellid.org/) is licensed under a [Creative
  Commons Attribution-ShareAlike 4.0 International
  License](https://creativecommons.org/licenses/by-sa/4.0/)
api:
  file: 1nce-os.json
  operationId: get_v1-locate-positions-latest
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---