---
title: Get all geofences
excerpt: Get an overview of all geofences.
api:
  file: 1nce-os.json
  operationId: get_v1-locate-geofences
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---