---
title: Create geofence
excerpt: Create a new geofence.
api:
  file: 1nce-os.json
  operationId: post_v1-locate-geofences
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---