---
title: Delete geofence
excerpt: Delete a geofence.
api:
  file: 1nce-os.json
  operationId: delete_v1-locate-geofences-geofenceid
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---