---
title: Get a geofence
excerpt: Get details of a geofence.
api:
  file: 1nce-os.json
  operationId: get_v1-locate-geofences-geofenceid
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---