---
title: Get Device Positions
excerpt: >
  Get positions of a specific device (maximum of last 7 days).

  ![Creative Commons
  License](https://mirrors.creativecommons.org/presskit/buttons/80x15/svg/by-sa.svg)
  [OpenCelliD Project](https://opencellid.org/) is licensed under a [Creative
  Commons Attribution-ShareAlike 4.0 International
  License](https://creativecommons.org/licenses/by-sa/4.0/)
api:
  file: 1nce-os.json
  operationId: get_v1-locate-devices-deviceid-positions
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---