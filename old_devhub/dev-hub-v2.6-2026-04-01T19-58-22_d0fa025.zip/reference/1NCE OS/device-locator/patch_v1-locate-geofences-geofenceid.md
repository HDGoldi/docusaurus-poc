---
title: Patch a geofence
excerpt: Update an existing geofence
api:
  file: 1nce-os.json
  operationId: patch_v1-locate-geofences-geofenceid
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---