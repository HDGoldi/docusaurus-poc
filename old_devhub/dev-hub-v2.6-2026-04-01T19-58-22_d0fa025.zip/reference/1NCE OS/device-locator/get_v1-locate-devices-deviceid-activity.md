---
title: Get Device Celltower location resolutions
excerpt: >
  Get Cell location resolutions for one device (maximum of last 7 days).

  ![Creative Commons
  License](https://mirrors.creativecommons.org/presskit/buttons/80x15/svg/by-sa.svg)
  [OpenCelliD Project](https://opencellid.org/) is licensed under a [Creative
  Commons Attribution-ShareAlike 4.0 International
  License](https://creativecommons.org/licenses/by-sa/4.0/)
api:
  file: 1nce-os.json
  operationId: get_v1-locate-devices-deviceid-activity
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---