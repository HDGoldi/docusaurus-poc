---
title: Get Administration Log Payload
excerpt: >-
  Get a URL pointing to a single administration log payload. The received URL
  will trigger a download.
api:
  file: 1nce-os.json
  operationId: get_v1-administrationlogs-adminlogid-payload
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---