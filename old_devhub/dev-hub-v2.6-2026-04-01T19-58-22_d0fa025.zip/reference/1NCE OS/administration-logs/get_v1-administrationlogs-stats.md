---
title: Get Administration Logs Statistics
excerpt: Get the administration logs statistics for the current organization.
api:
  file: 1nce-os.json
  operationId: get_v1-administrationlogs-stats
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---