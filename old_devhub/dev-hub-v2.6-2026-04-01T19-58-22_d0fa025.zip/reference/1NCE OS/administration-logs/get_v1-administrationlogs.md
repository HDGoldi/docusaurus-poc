---
title: Get Administration Logs
excerpt: Get a list of the administration logs regarding the organization.
api:
  file: 1nce-os.json
  operationId: get_v1-administrationlogs
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---