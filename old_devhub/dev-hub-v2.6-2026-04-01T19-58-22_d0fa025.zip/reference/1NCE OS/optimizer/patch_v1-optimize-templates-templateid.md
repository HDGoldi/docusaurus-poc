---
title: Update Optimizer Template
excerpt: Update a specific Optimizer Template.
api:
  file: 1nce-os.json
  operationId: patch_v1-optimize-templates-templateid
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---