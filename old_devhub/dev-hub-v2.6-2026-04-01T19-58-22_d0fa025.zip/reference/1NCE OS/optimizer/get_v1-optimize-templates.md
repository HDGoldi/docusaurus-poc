---
title: Get Optimizer Templates
excerpt: Get all Translation Service Templates for the current organization.
api:
  file: 1nce-os.json
  operationId: get_v1-optimize-templates
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---