---
title: Delete Optimizer Template
excerpt: Delete a specific Optimizer Template.
api:
  file: 1nce-os.json
  operationId: delete_v1-optimize-templates-templateid
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---