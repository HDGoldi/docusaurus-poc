---
title: Test template
excerpt: Test a template with a sample input message.
api:
  file: 1nce-os.json
  operationId: post_v1-optimize-messages-test
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---