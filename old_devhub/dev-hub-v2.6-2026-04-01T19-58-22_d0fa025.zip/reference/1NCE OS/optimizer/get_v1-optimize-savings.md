---
title: Get savings
excerpt: Get statistics about the savings by using the optimizer.
api:
  file: 1nce-os.json
  operationId: get_v1-optimize-savings
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---