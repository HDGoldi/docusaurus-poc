---
title: Get customer settings
excerpt: Gets customer settings related to 1NCE OS.
api:
  file: 1nce-os.json
  operationId: get_v1-settings-1nceos
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---