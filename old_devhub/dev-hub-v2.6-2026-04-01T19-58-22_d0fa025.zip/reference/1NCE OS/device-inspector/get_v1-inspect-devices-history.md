---
title: Get Historian Messages
excerpt: >-
  Get a list of historic messages for devices based on the optional filter
  parameters.
api:
  file: 1nce-os.json
  operationId: get_v1-inspect-devices-history
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---