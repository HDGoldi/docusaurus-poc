---
title: Get Single Device
excerpt: Get detailed metadata from one specific Device.
api:
  file: 1nce-os.json
  operationId: get_v1-inspect-devices-deviceid
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---