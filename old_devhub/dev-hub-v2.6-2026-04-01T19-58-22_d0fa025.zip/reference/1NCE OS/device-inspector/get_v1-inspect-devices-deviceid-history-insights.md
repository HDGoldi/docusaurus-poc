---
title: Get Device Historian Insights
excerpt: Get insights of a unique SIM device for the Historian.
api:
  file: 1nce-os.json
  operationId: get_v1-inspect-devices-deviceid-history-insights
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---