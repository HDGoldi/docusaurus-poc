---
title: Get Historian Insights
excerpt: Get insights for all devices from the Historian based on the optional filters.
api:
  file: 1nce-os.json
  operationId: get_v1-inspect-devices-history-insights
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---