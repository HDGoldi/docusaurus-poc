---
title: Get Device Historian Messages
excerpt: Get historic message data for a specific SIM device.
api:
  file: 1nce-os.json
  operationId: get_v1-inspect-devices-deviceid-history
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---