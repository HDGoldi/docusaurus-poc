---
title: Get All Devices
excerpt: >-
  Get a list of all the Customer SIMs/Devices for the current organisation in
  the 1NCE OS.
api:
  file: 1nce-os.json
  operationId: get_v1-inspect-devices
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---