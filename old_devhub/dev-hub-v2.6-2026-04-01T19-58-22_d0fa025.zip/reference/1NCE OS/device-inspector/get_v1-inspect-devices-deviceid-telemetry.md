---
title: Get Device Telemetry
excerpt: >-
  Get the current/last repored Shadow State (telemetry) Data for a specific
  Device.
api:
  file: 1nce-os.json
  operationId: get_v1-inspect-devices-deviceid-telemetry
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---