---
title: Uninstall a specific plugin by ID
excerpt: >-
  Uninstall a specific plugin by ID to remove the functionality provided by the
  plugin.
api:
  file: 1nce-os.json
  operationId: delete_v1-partners-plugins-pluginid
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---