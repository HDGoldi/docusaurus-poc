---
title: Install Tartabit plugin for 1NCE OS
excerpt: >-
  Allows setting up an integration with Tartabit to integrate with Azure, Oracle
  Cloud Infrastructure, Google Cloud and other cloud services via 1NCE OS.
api:
  file: 1nce-os.json
  operationId: post_v1-partners-tartabit-plugins
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---