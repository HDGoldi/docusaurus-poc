---
title: Get details about a specific plugin installation
excerpt: Retrieve details about a specific 1NCE OS plugin by it's installation ID.
api:
  file: 1nce-os.json
  operationId: get_v1-partners-plugins-pluginid
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---