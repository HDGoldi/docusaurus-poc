---
title: Install Datacake plugin for 1NCE OS
excerpt: >-
  Allows setting up an integration with Datacake workspace to allow data
  transfer from 1NCE OS.
api:
  file: 1nce-os.json
  operationId: post_v1-partners-datacake-plugins
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---