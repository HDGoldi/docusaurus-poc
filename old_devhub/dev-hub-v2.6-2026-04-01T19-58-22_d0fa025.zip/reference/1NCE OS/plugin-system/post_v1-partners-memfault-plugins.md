---
title: Install Memfault plugin for 1NCE OS
excerpt: >-
  Allows setting up an integration with Memfault to allow seamless device
  debugging via 1NCE OS CoAP proxy.
api:
  file: 1nce-os.json
  operationId: post_v1-partners-memfault-plugins
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---