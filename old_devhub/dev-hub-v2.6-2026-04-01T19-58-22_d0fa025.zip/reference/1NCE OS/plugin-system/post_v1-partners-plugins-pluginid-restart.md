---
title: Restart a failed plugin by installation ID
excerpt: Attempt to restart a plugin that is in a failed state.
api:
  file: 1nce-os.json
  operationId: post_v1-partners-plugins-pluginid-restart
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---