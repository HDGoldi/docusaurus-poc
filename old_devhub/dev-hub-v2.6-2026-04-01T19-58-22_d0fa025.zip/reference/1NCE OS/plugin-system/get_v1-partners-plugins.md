---
title: Get a list of plugin installations
excerpt: Retrieve a list of all installed plugins.
api:
  file: 1nce-os.json
  operationId: get_v1-partners-plugins
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---