---
title: Install Mender plugin for 1NCE OS
excerpt: >-
  Allows setting up an integration with Mender to allow seamless firmware update
  management via 1NCE OS CoAP proxy. Public and private keys are optional
  fields, but if they are used, both must be provided
api:
  file: 1nce-os.json
  operationId: post_v1-partners-mender-plugins
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---