---
title: Create Pre-Shared Device Key
excerpt: Post a new Custom Pre-Shared Key for a specific Device.
api:
  file: 1nce-os.json
  operationId: post_v1-integrate-devices-deviceid-psk
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---