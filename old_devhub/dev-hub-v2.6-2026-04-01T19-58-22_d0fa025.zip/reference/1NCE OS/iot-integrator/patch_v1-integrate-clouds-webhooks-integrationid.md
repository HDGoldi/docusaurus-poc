---
title: Patch Customer Webhook Integration
excerpt: Patch Customer Webhook Integration
api:
  file: 1nce-os.json
  operationId: patch_v1-integrate-clouds-webhooks-integrationid
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---