---
title: Get archived device action requests
excerpt: Get a list of archived device action requests in the last 7 days.
api:
  file: 1nce-os.json
  operationId: get_v1-integrate-devices-actions-requests-archived
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---