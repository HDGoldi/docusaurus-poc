---
title: Get Pre-Shared Device Key
excerpt: Get the Pre-Shared Key of a specific Device.
api:
  file: 1nce-os.json
  operationId: get_v1-integrate-devices-deviceid-psk-protocol
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---