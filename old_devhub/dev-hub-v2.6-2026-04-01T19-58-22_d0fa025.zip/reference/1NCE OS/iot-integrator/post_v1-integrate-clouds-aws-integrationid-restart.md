---
title: Restart AWS Integration
excerpt: Restart AWS integration by forwarding test message to the integration.
api:
  file: 1nce-os.json
  operationId: post_v1-integrate-clouds-aws-integrationid-restart
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---