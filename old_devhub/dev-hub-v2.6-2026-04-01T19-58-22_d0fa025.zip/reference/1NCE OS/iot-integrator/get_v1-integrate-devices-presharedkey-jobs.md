---
title: Pre-Shared Devices Keys Import Job Status
excerpt: Get status of Pre-Shared Keys Import jobs for the last 30 days.
api:
  file: 1nce-os.json
  operationId: get_v1-integrate-devices-presharedkey-jobs
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---