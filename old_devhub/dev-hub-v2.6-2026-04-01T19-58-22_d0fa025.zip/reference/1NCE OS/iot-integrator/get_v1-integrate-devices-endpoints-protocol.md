---
title: Get single device endpoint
excerpt: Get details about the device endpoint of a specific protocol.
api:
  file: 1nce-os.json
  operationId: get_v1-integrate-devices-endpoints-protocol
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---