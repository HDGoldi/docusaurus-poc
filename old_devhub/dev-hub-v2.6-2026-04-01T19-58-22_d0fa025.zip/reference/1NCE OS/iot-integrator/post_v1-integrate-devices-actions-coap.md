---
title: Create Action Requests for CoAP Devices.
excerpt: Initiate CoAP action on the devices.
api:
  file: 1nce-os.json
  operationId: post_v1-integrate-devices-actions-coap
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---