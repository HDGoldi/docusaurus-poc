---
title: Get CloudFormation Parameters
excerpt: Get the URLs to download/rollout the customer CloudFormation stack templates.
api:
  file: 1nce-os.json
  operationId: get_v1-integrate-clouds-aws-parameters
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---