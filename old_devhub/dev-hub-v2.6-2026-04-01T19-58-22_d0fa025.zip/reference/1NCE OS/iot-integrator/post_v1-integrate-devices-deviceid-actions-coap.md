---
title: Create Action Request On Specific CoAP Device.
excerpt: Initiate CoAP action on specific device.
api:
  file: 1nce-os.json
  operationId: post_v1-integrate-devices-deviceid-actions-coap
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---