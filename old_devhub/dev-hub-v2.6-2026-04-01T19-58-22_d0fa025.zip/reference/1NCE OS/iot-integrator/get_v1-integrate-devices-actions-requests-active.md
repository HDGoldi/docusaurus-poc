---
title: Get active device action requests
excerpt: Get a list of active device action requests in the last 7 days.
api:
  file: 1nce-os.json
  operationId: get_v1-integrate-devices-actions-requests-active
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---