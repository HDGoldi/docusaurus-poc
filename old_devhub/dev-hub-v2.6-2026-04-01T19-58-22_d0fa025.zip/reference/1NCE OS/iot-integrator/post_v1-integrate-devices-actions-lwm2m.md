---
title: Create Action Requests for LwM2M Devices.
excerpt: >-
  Initiate LwM2M actions like read, write, execute on the specified devices. The
  devices have to be connected to 1NCE LwM2M endpoint to invoke this event.
api:
  file: 1nce-os.json
  operationId: post_v1-integrate-devices-actions-lwm2m
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---