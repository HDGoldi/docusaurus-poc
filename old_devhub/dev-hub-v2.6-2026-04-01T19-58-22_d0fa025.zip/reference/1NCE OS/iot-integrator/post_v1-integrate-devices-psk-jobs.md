---
title: Import Pre-Shared Devices Keys
excerpt: Import new Custom Pre-Shared Keys for multiple Devices.
api:
  file: 1nce-os.json
  operationId: post_v1-integrate-devices-psk-jobs
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---