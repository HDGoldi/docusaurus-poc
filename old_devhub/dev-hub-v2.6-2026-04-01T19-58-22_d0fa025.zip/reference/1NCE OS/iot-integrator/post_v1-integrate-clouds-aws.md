---
title: Create AWS Integration
excerpt: >-
  Creates AWS Integration, which becomes active only after customer
  Cloudformation stack is rolled out.
api:
  file: 1nce-os.json
  operationId: post_v1-integrate-clouds-aws
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---