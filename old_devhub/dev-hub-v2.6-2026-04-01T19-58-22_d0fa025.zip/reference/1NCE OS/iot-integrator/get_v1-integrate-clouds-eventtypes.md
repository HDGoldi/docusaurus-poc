---
title: Get Integration Event Types
excerpt: Get Available Integration Event Types.
api:
  file: 1nce-os.json
  operationId: get_v1-integrate-clouds-eventtypes
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---