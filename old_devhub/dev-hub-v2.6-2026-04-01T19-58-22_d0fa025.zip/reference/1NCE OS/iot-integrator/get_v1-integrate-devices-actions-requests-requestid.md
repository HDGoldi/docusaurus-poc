---
title: Get single device action request
excerpt: Get details about the device action request.
api:
  file: 1nce-os.json
  operationId: get_v1-integrate-devices-actions-requests-requestid
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---