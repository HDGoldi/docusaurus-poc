---
title: Patch single device endpoint
excerpt: Update endpoint related settings.
api:
  file: 1nce-os.json
  operationId: patch_v1-integrate-devices-endpoints-protocol
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---