---
title: Create Action Request On Specific UDP Device.
excerpt: Initiate UDP action on specific device.
api:
  file: 1nce-os.json
  operationId: post_v1-integrate-devices-deviceid-actions-udp
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---