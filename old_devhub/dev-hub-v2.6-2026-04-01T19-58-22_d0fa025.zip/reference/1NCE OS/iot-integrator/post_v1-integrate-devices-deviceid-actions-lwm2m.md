---
title: Create Action Request On Specific LwM2M Device.
excerpt: >-
  Initiate LwM2M action like read, write, execute on specific device. It has to
  be connected to 1NCE LwM2M endpoint to invoke this event.
api:
  file: 1nce-os.json
  operationId: post_v1-integrate-devices-deviceid-actions-lwm2m
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---