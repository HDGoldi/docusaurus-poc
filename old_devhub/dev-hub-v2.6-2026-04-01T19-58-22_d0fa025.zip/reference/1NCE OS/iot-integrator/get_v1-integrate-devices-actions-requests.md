---
title: Get device action requests
excerpt: Get a list of device action requests in the last 7 days.
api:
  file: 1nce-os.json
  operationId: get_v1-integrate-devices-actions-requests
deprecated: true
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---