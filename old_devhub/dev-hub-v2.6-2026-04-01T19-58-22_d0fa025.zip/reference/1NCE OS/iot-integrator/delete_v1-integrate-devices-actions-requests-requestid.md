---
title: Cancel single device action request
excerpt: Cancel single device action request.
api:
  file: 1nce-os.json
  operationId: delete_v1-integrate-devices-actions-requests-requestid
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---