---
title: Create Action Requests for UDP Devices.
excerpt: Initiate UDP action on devices.
api:
  file: 1nce-os.json
  operationId: post_v1-integrate-devices-actions-udp
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---