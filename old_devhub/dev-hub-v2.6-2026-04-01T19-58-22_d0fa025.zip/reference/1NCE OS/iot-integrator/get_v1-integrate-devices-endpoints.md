---
title: Get device endpoints
excerpt: Get details about the device endpoints.
api:
  file: 1nce-os.json
  operationId: get_v1-integrate-devices-endpoints
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---