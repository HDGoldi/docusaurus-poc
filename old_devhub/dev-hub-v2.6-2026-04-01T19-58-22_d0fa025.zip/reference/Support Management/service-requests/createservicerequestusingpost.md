---
title: Create Service Request
excerpt: Create a new service request towards 1NCE Support.
api:
  file: support-management.json
  operationId: createServiceRequestUsingPOST
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---