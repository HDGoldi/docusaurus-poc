---
title: Get Service Requests
excerpt: Get a list of all customer service requests.
api:
  file: support-management.json
  operationId: getServiceRequestsUsingGET
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---