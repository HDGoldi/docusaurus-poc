---
title: Get Global Limits
excerpt: >-
  Get currently configured self-set monthly limits (Data, MT-SMS, MO-SMS) for
  all SIMs.
api:
  file: sim-management.json
  operationId: getLimitsUsingGET
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---