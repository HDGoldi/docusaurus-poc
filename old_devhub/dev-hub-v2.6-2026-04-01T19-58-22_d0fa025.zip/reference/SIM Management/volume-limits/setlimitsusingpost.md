---
title: Create Global Limits
excerpt: Configure self-set monthly limits for all SIMs (Data, MT-SMS, MO-SMS).
api:
  file: sim-management.json
  operationId: setLimitsUsingPOST
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---