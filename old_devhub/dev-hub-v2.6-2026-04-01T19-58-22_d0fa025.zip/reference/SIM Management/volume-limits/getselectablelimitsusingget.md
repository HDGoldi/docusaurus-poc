---
title: Get SIM Limits
excerpt: Get a list of slectable limits for a given service.
api:
  file: sim-management.json
  operationId: getSelectableLimitsUsingGET
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---