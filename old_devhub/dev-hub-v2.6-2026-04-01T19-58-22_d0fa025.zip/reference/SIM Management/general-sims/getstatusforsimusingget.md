---
title: Get SIM Status
excerpt: Query the current status of a specific SIM card.
api:
  file: sim-management.json
  operationId: getStatusForSimUsingGET
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---