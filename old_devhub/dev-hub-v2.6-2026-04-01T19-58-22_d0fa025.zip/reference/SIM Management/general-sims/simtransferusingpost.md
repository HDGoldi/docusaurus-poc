---
title: Create SIM Transfer
excerpt: >-
  Trigger a SIM transfer workflow - if possible - for moving SIMs from one
  customer to another.
api:
  file: sim-management.json
  operationId: simTransferUsingPOST
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---