---
title: Create Multiple SIM Configuration
excerpt: >-
  Change a list of SIMS for activate, deactivate, label, IMEI lock, etc. The
  actual change will be done asynchronously. A positive-response only means that
  the SIM changes has been successfully placed into the queue.
api:
  file: sim-management.json
  operationId: updateSimsUsingPOST
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---