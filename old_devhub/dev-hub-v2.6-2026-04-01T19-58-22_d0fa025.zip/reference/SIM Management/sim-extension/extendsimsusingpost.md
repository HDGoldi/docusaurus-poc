---
title: Create SIM Extension
excerpt: >-
  Trigger the SIM extension for one or more SIM cards to extend their activation
  period and renew their quota (data and SMS). An invoice is automatically
  triggered depending on the chosen payment method.
api:
  file: sim-management.json
  operationId: extendSimsUsingPOST
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---