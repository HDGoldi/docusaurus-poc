---
title: Get SIM Connectivity
excerpt: >-
  Retrieve connectivity information and cell tower of a device with a given SIM.
  The API call returns valid information when the 1NCE SIM is attached to a
  2G/3G network only.
api:
  file: sim-management.json
  operationId: getConnectivityInfoForSimUsingGET
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---