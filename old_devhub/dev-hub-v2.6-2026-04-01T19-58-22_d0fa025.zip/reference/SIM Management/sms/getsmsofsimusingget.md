---
title: Get SMS Details
excerpt: Query details about an individual SMS from a specifc SIM card.
api:
  file: sim-management.json
  operationId: getSmsOfSimUsingGET
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---