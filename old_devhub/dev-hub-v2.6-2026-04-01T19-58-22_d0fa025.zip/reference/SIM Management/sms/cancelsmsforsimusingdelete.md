---
title: Delete SMS
excerpt: >-
  Cancel a SMS message that is buffered to be delivered to the device with the
  SIM card but was not yet delivered.
api:
  file: sim-management.json
  operationId: cancelSmsForSimUsingDELETE
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---