---
title: Get SIM Usage
excerpt: >-
  Query the SIM data and SMS usage over a given period of time. The output is
  limited to the last 6 months.
api:
  file: sim-management.json
  operationId: getUsageForSimUsingGET
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---