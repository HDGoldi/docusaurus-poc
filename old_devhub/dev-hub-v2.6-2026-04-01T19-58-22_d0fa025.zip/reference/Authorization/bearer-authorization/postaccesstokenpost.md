---
title: Obtain Access Token
excerpt: >-
  Obtain a token for accessing other 1NCE API resources by using a POST request
  with a valid username and password combination for a 1NCE user account that
  has the permission to use the API.
api:
  file: authorization.json
  operationId: postAccessTokenPOST
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---