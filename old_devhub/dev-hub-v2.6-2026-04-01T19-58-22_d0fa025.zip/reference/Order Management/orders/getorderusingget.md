---
title: Get Single Order
excerpt: Get a single Order, identified by its order_number.
api:
  file: order-management.json
  operationId: getOrderUsingGET
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---