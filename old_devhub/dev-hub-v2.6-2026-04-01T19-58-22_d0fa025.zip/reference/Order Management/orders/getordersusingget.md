---
title: Get All Orders
excerpt: Get a complete list of all 1NCE orders for the given account.
api:
  file: order-management.json
  operationId: getOrdersUsingGET
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---