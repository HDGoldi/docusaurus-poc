---
title: Create Order
excerpt: Trigger an order using a POST request.
api:
  file: order-management.json
  operationId: postOrderUsingPOST
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---