---
title: "SMS Events"
slug: "data-streamer-sms-events"
excerpt: "Stream SMS Events including MT Delivery Reports and MO SMS with detailed event specifications and examples."
hidden: false
metadata: 
  title: "Data Streamer - SMS Events | Bell Developer Hub"
  description: "Stream Updates about the SMS Events."
  image: []
  robots: "index"
createdAt: "Sun Nov 09 2025 17:18:05 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Nov 10 2025 13:50:44 GMT+0000 (Coordinated Universal Time)"
---
# Événements SMS

Le service Bell Data Streamer fournit des événements SMS en temps réel qui offrent une visibilité détaillée sur le trafic SMS de vos appareils IoT. Ce chapitre se concentre sur les deux types d’événements SMS pris en charge par la plateforme.

## Types d’événements SMS

<Cards columns="2">
  <Card title="SMS MT DLR" icon="check-circle">
    Les rapports de livraison MT (Mobile Terminated) fournissent des mises à jour d’état pour les messages SMS envoyés aux appareils, y compris les confirmations de livraison, les échecs et les notifications d’expiration.
  </Card>

  <Card title="SMS MO" icon="mobile-alt">
    Les événements MO (Mobile Originated) représentent les messages SMS envoyés depuis les appareils mobiles vers vos interfaces ou applications spécifiées.
  </Card>
</Cards>

## Spécifications des événements

### SMS MT DLR (Rapport de livraison)

Les rapports de livraison SMS MT sont générés lorsque les messages SMS envoyés aux appareils atteignent un état final. Ces événements fournissent des informations sur l’état de livraison, notamment la livraison réussie, les échecs ou l’expiration.

**Types d’état pris en charge :**

- `DELIVERED` : Message livré avec succès à l’appareil
- `FAILED` : Échec de la livraison du message
- `EXPIRED` : Message expiré avant la livraison

<Accordion title="Exemple de SMS MT DLR" icon="receipt">
  ```json SMS_MT_DLR.json
  {
    "id": 8891889,
    "submit_date": "2024-12-15T16:55:31Z",
    "final_date": "2024-12-15T16:55:35Z",
    "organisation": {
      "id": 103820
    },
    "endpoint": {
      "id": 100001494,
      "name": "8988228530100000216"
    },
    "status": {
      "status": "DELIVERED",
      "id": 4
    },
    "detail": {
      "sms": {
        "id": "551734281731175386"
      }
    }
  }
  ```
</Accordion>

### SMS MO (Mobile Originated)

Les événements SMS MO représentent les messages envoyés depuis des appareils mobiles vers vos interfaces spécifiées par le client. Ces événements capturent le contenu complet du SMS et les informations de routage.

<Accordion title="Exemple de SMS MO" icon="paper-plane">
  ```json SMS_MO.json
  {
    "id": 8901947,
    "submit_date": "2024-12-16 07:01:00",
    "pid": 0,
    "organisation": {
      "id": 103820
    },
    "dest_address": "338",
    "source_address": "882285301000216",
    "dcs": 0,
    "payload": "34178d09-905a-4289-95b6-da61f966d3e1;1734332456",
    "endpoint": {
      "id": 100001494,
      "name": "8988228530100000216"
    }
  }
  ```
</Accordion>

## Propriétés des événements SMS

<Tabs>
  <Tab title="Propriétés communes">
    Propriétés partagées par les deux types d’événements SMS :

```
| Propriété      | Type de données        | Description                                                       |
| :------------- | :--------------------- | :---------------------------------------------------------------- |
| `id`           | LONG (entier 64 bits)  | Identifiant unique pour chaque événement SMS                      |
| `submit_date`  | TIMESTAMP (UTC)        | Horodatage de soumission du SMS au format ISO 8601                |
| `organisation` | Objet JSON             | Informations sur l’organisation contenant l’identifiant d’org     |
| `endpoint`     | Objet JSON             | Informations du point de terminaison incluant ID et nom (ICCID)   |
```

  </Tab>

  <Tab title="Propriétés SMS MT DLR">
    Propriétés spécifiques aux événements de rapports de livraison MT :

```
| Propriété    | Type de données   | Description                                             |
| :----------- | :---------------- | :------------------------------------------------------ |
| `final_date` | TIMESTAMP (UTC)   | Horodatage auquel l’état final de livraison a été atteint |
| `status`     | Objet JSON        | Informations sur l’état de livraison                    |
| `detail`     | Objet JSON        | Détails supplémentaires, y compris l’ID du SMS original |

**Objet Status :**

* `status` : Valeur de chaîne (`DELIVERED`, `FAILED`, `EXPIRED`)
* `id` : Identifiant numérique de l’état (4 = DELIVERED, 5 = FAILED, 6 = EXPIRED)
```

  </Tab>

  <Tab title="Propriétés SMS MO">
    Propriétés spécifiques aux événements SMS Mobile Originated :

```
| Propriété         | Type de données | Description                                        |
| :---------------- | :-------------- | :------------------------------------------------- |
| `dest_address`    | STRING          | Adresse de destination vers laquelle le SMS a été envoyé |
| `source_address`  | STRING          | Adresse source (généralement le MSISDN de l’appareil)    |
| `payload`         | STRING          | Contenu réel du message SMS                        |
| `dcs`             | INTEGER         | Schéma de codage des données (0 = GSM 7 bits par défaut) |
| `pid`             | INTEGER         | Identifiant de protocole (0 = par défaut)          |
```

  </Tab>
</Tabs>

## Détails des objets

### Objet Organisation

Contient des informations sur l’organisation cliente :

| Propriété | Type de données | Description                                       |
| :-------- | :-------------- | :------------------------------------------------ |
| `id`      | INTEGER         | Identifiant unique de l’organisation cliente Bell |

### Objet Point de terminaison

Représente le point de terminaison de l’appareil/la carte SIM :

| Propriété | Type de données | Description                                        |
| :-------- | :-------------- | :------------------------------------------------- |
| `id`      | INTEGER         | Identifiant unique du point de terminaison         |
| `name`    | STRING          | Nom du point de terminaison (généralement l’ICCID) |

### Objet Détail (SMS MT DLR)

Contient des informations supplémentaires spécifiques aux rapports de livraison :

| Propriété | Type de données | Description                            |
| :-------- | :-------------- | :------------------------------------- |
| `sms`     | Objet JSON      | Contient l’identifiant du SMS original |

**Objet Détail SMS :**

- `id` : Identifiant du message SMS original pour la corrélation

## Notes d’intégration

- Les événements SMS sont livrés en temps réel via le Bell Data Streamer
- Chaque événement inclut un ID unique pour gérer d’éventuelles retransmissions
- Les horodatages sont fournis au format UTC selon la norme ISO 8601
- Les codes d’état sont cohérents sur toute la plateforme pour un traitement fiable
