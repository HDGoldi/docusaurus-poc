---
title: "Usage Events"
slug: "data-streamer-usage-events"
excerpt: "Stream Updates about the SMS and Data Volume Usage with detailed usage events and examples."
hidden: false
metadata: 
  title: "Data Streamer - Usage Events | Bell Developer Hub"
  description: "Stream Updates about the SMS and Data Volume Usage."
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:29:12 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Nov 10 2025 13:50:31 GMT+0000 (Coordinated Universal Time)"
---
# Événements d'utilisation

Le service Bell Data Streamer offre un flux d'événements d'utilisation. Ce chapitre se concentre sur la spécification des événements d'utilisation. Dans ce chapitre, l'accent est mis sur le format d'objet JSON. Pour d'autres intégrations, le format peut être différent, mais les champs de données sont comparables. Veuillez vous référer à la configuration des intégrations proposées pour obtenir plus d'informations sur les formats de données spécifiques utilisés.

## Déclencheurs d'événements d'utilisation

<Cards columns="3">
  <Card title="Événements de connexion de données" icon="database">
    Pour une connexion de données PDP en cours, au plus un événement toutes les 15 minutes si plus de 100 kB de données ont été utilisés. Cet événement contient l'utilisation agrégée depuis le début du PDP ou depuis le dernier événement d'utilisation.
  </Card>

  <Card title="Événements de fermeture de connexion" icon="times-circle">
    Un événement à la fermeture d'une connexion de données PDP. Cet événement contient l'utilisation depuis le dernier événement ou l'utilisation agrégée complète s'il n'y a pas eu d'événement préalable pour la connexion de données PDP fermée.
  </Card>

  <Card title="Événements SMS" icon="sms">
    Pour les SMS, un événement d'utilisation est fourni pour chaque envoi individuel de SMS MO/MT.
  </Card>
</Cards>

Le Bell Data Streamer fournit deux types d'événements pour l'utilisation des SMS et le volume de données.

## Événements d'utilisation

### Événement d'utilisation des données

Les événements d'utilisation des données sont envoyés pour chaque point de terminaison pendant que celui-ci consomme le service de données. La fréquence des événements d'utilisation des données dépend des paramètres de configuration de la plateforme, p. ex. un événement toutes les 5 minutes et/ou chaque mégaoctet consommé.

### Événement d'utilisation des SMS

Les événements d'utilisation des SMS sont envoyés pour chaque point de terminaison pendant que celui-ci consomme le service SMS. Un événement d'utilisation des SMS est envoyé pour chaque SMS MO ou SMS MT. Si la soumission du SMS a été rejetée par la plateforme (p. ex. en raison d'un quota dépassé ou d'une limite mensuelle), alors le SMS ne sera pas facturé et, par conséquent, aucun événement d'utilisation des SMS ne sera émis.

## Exemples d'événements d'utilisation

Commençons par quelques exemples d'événements d'utilisation sous forme d'objets JSON provenant du Data Streamer. Veuillez noter que certains champs ne contiennent que des valeurs d'exemple ou des espaces réservés.

<Accordion title="Exemple d'événement d'utilisation des données" icon="chart-line">
  ```json Data_Usage_Event.json
  {
    "id": 819948096,
    "operator": {
      "id": 78,
      "name": "Bite GSM",
      "mnc": "05",
      "country": {
        "id": 110,
        "mcc": "247",
        "name": "Latvia"
      }
    },
    "organisation": {
      "id": 100018,
      "name": "81013181"
    },
    "tariff": {
      "id": 369,
      "name": "MVP Phase 2 Tarriff",
      "ratezone": {
        "id": 4,
        "name": "T369.RZ1"
      }
    },
    "traffic_type": {
      "id": 5,
      "description": "Data"
    },
    "endpoint": {
      "id": 100000519,
      "name": "8988228066605682521",
      "ip_address": "10.0.1.118",
      "imei": "3556200910473501"
    },
    "volume": {
      "total": 1.0049019,
      "rx": 1.0049019,
      "tx": 0
    },
    "sim": {
      "id": 10000299,
      "iccid": "8988228066605682521",
      "msisdn": "882285105682521"
    },
    "start_timestamp": "2024-12-15T06:24:47.000Z",
    "end_timestamp": "2024-12-15T06:25:10.000Z",
    "imsi": "901405105682521",
    "imsi_id": 100000299,
    "detail": {
      "pdp_context": {
        "rat_type": 6,
        "ipcan_session_id": "e17b3179-04e0-40e8-b982-0d5f826cea6e"
      }
    }
  }
  ```
</Accordion>

<Accordion title="Exemple d'événement d'utilisation des SMS" icon="envelope">
  ```json SMS_Usage_Event.json
  {
    "id": 8884551,
    "start_timestamp": "2024-12-15T06:27:26Z",
    "end_timestamp": "2024-12-15T06:27:27Z",
    "organisation": {
      "id": 103820,
      "name": "81023262"
    },
    "operator": {
      "id": 77,
      "name": "LMT",
      "mnc": "01",
      "country": {
        "id": 110,
        "mcc": "247",
        "name": "Latvia"
      }
    },
    "tariff": {
      "id": 2703,
      "name": "Tariff 718916841",
      "ratezone": {
        "id": 11428,
        "name": "IoT Cloud Connect Complete"
      }
    },
    "imsi": "901405301000216",
    "imsi_id": 100003437,
    "traffic_type": {
      "id": 6,
      "description": "SMS"
    },
    "endpoint": {
      "id": 100001494,
      "name": "8988228530100000216",
      "imei": "8643510517167031",
      "ip_address": "10.0.0.1"
    },
    "volume": {
      "total": 1,
      "rx": 0,
      "tx": 1
    },
    "sim": {
      "msisdn": "882285301000216",
      "iccid": "8988228530100000216",
      "id": 10003354
    }
  }
  ```
</Accordion>

## Propriétés des données d'utilisation

Voici les principales propriétés d'un événement d'utilisation qui aident à identifier le point de terminaison et donnent un aperçu du volume utilisé.

| Propriété         | Type de données       | Description                                                                                                                             |
| :---------------- | :-------------------- | :-------------------------------------------------------------------------------------------------------------------------------------- |
| `id`              | LONG (64-bit integer) | ID unique pour chaque événement d'utilisation envoyé. Des ID d'événement dupliqués reçus indiquent de possibles retransmissions.        |
| `cost`            | DECIMAL(14,10)        | Ne reflète pas le coût réel, traduction 1:1 de l'utilisation. (Champ hérité, peut ne pas être présent dans les événements plus récents) |
| `currency`        | JSON Object           | Objet devise avec des informations sur la devise du coût. (Champ hérité, peut ne pas être présent dans les événements plus récents)     |
| `start_timestamp` | TIMESTAMP (UTC)       | Horodatage avec la date et l'heure de début d'utilisation au format ISO 8601.                                                           |
| `end_timestamp`   | TIMESTAMP (UTC)       | Horodatage avec la date et l'heure de fin d'utilisation au format ISO 8601.                                                             |
| `volume`          | JSON Object           | Objet avec le volume exact utilisé dans le cadre de l'événement d'utilisation. Voir [Volume](#volume-object) pour plus d'informations.  |
| `imsi`            | STRING                | L'International Mobile Subscriber Identity sous forme de chaîne de caractères.                                                          |
| `organisation`    | JSON Object           | Objet avec l'ID et le nom de l'organisation. Voir [Organisation de l'événement](#organization-object) pour plus d'informations.         |
| `operator`        | JSON Object           | Informations sur l'opérateur, voir [Opérateur](#operator-object) pour plus d'informations.                                              |
| `sim`             | JSON Object           | Module d'identification de l'abonné, voir [SIM](#sim-object) pour plus d'informations.                                                  |
| `tariff`          | JSON Object           | Détails du tarif, voir [Tarif](#tariff-object) pour plus d'informations.                                                                |
| `traffic_type`    | JSON Object           | Type de trafic de l'événement d'utilisation, voir [Type de trafic](#traffic-type-object) pour plus d'informations.                      |
| `endpoint`        | JSON Object           | Objet d'informations du point de terminaison/appareil, voir [Point de terminaison](#endpoint-object) pour plus d'informations.          |
| `detail`          | JSON Object           | Détails supplémentaires spécifiques au type d'utilisation, voir [Détail](#detail-object) pour plus d'informations.                      |

## Spécifications des objets

<Tabs>
  <Tab title="Objet Devise">
    L'objet de coût est défini comme une relation 1:1 avec le volume utilisé. Il ne reflète pas le coût réel. Il s'agit d'un champ hérité et il peut ne pas être présent dans les événements d'utilisation plus récents.

```
| Propriété | Type de données     | Description                                               |
| :-------- | :------------------ | :-------------------------------------------------------- |
| `id`      | INTEGER             | Identifiant unique de la devise du coût indiqué.         |
| `symbol`  | UTF-8 Char STRING   | Symbole de la devise en caractères UTF-8.                |
| `code`    | ISO 4217 STRING     | Code de la devise au format ISO.                         |
```

  </Tab>

  <Tab title="Objet Organisation">
    Informations sur l'organisation de la SIM qui a généré l'événement d'utilisation du volume.

```
| Propriété | Type de données | Description                              |
| :-------- | :-------------- | :--------------------------------------- |
| `id`      | INTEGER         | Identifiant unique de l'organisation.    |
| `name`    | STRING          | ID client Bell.                          |
```

  </Tab>

  <Tab title="Objet SIM">
    Détails sur la SIM responsable de l'utilisation du volume.

```
| Propriété          | Type de données   | Description                                                                 |
| :----------------- | :---------------- | :-------------------------------------------------------------------------- |
| `id`               | INTEGER           | ID unique de la SIM.                                                        |
| `iccid`            | STRING            | Identifiant de circuit intégré (ICCID) de la SIM.                           |
| `msisdn`           | STRING            | Numéro MSISDN de la carte SIM.                                              |
| `production_date`  | TIMESTAMP (UTC)   | Horodatage de production de la SIM au format ISO 8601. (Champ hérité)       |
```

  </Tab>

  <Tab title="Objet Opérateur">
    Opérateur auquel la SIM était attachée lorsque l'utilisation a été générée.

```
| Propriété | Type de données | Description                                                                        |
| :-------- | :-------------- | :--------------------------------------------------------------------------------- |
| `id`      | INTEGER         | Identifiant unique de l'opérateur visité.                                         |
| `mnc`     | STRING          | Mobile Network Code de l'opérateur en itinérance.                                 |
| `name`    | STRING          | Nom de l'opérateur mobile en itinérance.                                          |
| `country` | JSON Object     | Objet d'information pays, voir [Pays](#country-object) pour plus d'informations.  |
```

  </Tab>

  <Tab title="Objet Pays">
    Pays de l'appareil avec la SIM Bell où l'utilisation a été générée.

```
| Propriété | Type de données | Description                           |
| :-------- | :-------------- | :------------------------------------ |
| `id`      | INTEGER         | Identifiant unique du pays visité.    |
| `mcc`     | STRING          | Mobile Country Code de l'opérateur.   |
| `name`    | STRING          | Nom du pays visité.                   |
```

  </Tab>

  <Tab title="Objet Tarif">
    Tarif spécifique attribué à la SIM Bell.

```
| Propriété  | Type de données | Description                                                                            |
| :--------- | :-------------- | :------------------------------------------------------------------------------------- |
| `id`       | INTEGER         | Identifiant unique du tarif appliqué.                                                 |
| `name`     | STRING          | Nom du tarif appliqué.                                                                |
| `ratezone` | JSON Object     | Objet d'information de zone tarifaire, voir [Ratezone](#ratezone-object) pour plus d'informations. |
```

  </Tab>

  <Tab title="Objet Zone tarifaire">
    La zone tarifaire dans laquelle la SIM a généré l'utilisation indiquée.

```
| Propriété | Type de données | Description                                |
| :-------- | :-------------- | :----------------------------------------- |
| `id`      | INTEGER         | Identifiant unique de la zone tarifaire appliquée. |
| `name`    | STRING          | Nom de la zone tarifaire.                  |
```

  </Tab>

  <Tab title="Objet Type de trafic">
    Identifie le type de trafic utilisé et affiché dans l'événement d'utilisation. Il peut s'agir de données ou de SMS.

```
| Propriété | Type de données | Description                                               |
| :-------- | :-------------- | :-------------------------------------------------------- |
| `id`      | INTEGER         | Identifiant unique du type de trafic. 5 = Data, 6 = SMS  |
| `name`    | STRING          | Nom du type de trafic, soit "Data" soit "SMS".           |
```

  </Tab>

  <Tab title="Objet Point de terminaison">
    Détails sur le point de terminaison/appareil avec la SIM Bell qui a généré l'utilisation.

```
| Propriété     | Type de données | Description                                       |
| :------------ | :-------------- | :------------------------------------------------ |
| `id`          | INTEGER         | Identifiant unique du type de trafic.            |
| `tags`        | STRING          | Étiquettes définies par l'utilisateur pour ce point de terminaison. |
| `ip_address`  | STRING          | Adresse IP attribuée à ce point de terminaison.  |
| `imei`        | STRING          | IMEI du matériel du point de terminaison.        |
| `name`        | STRING          | Nom défini par l'utilisateur pour ce point de terminaison. |
| `balance`     | STRING          | (Champ hérité, peut ne pas être présent)         |
```

  </Tab>

  <Tab title="Objet Volume">
    Volume exact, soit les données en mégaoctets, soit le nombre de SMS utilisés par la SIM.

```
| Propriété | Type de données   | Description                                                                                                                     |
| :-------- | :---------------- | :-------------------------------------------------------------------------------------------------------------------------------- |
| `total`   | DECIMAL(14,6)     | Trafic total consommé, somme de `tx` et `rx`.                                                                                   |
| `tx`      | DECIMAL(14,6)     | **Selon le type de trafic :** Trafic montant (MiB - unité binaire) envoyé par le point de terminaison. **ou** Nombre de SMS MO envoyés |
| `rx`      | DECIMAL(14,6)     | **Selon le type de trafic :** Trafic descendant (MiB - unité binaire) reçu par le point de terminaison. **ou** Nombre de SMS MT envoyés |
```

  </Tab>

  <Tab title="Objet Détail">
    Détails supplémentaires spécifiques au type d'utilisation. Cet objet peut contenir différentes informations selon le type d'événement d'utilisation.

```
**Pour les événements d'utilisation des données :**

| Propriété      | Type de données | Description                                    |
| :------------- | :-------------- | :--------------------------------------------- |
| `pdp_context`  | JSON Object     | Informations de contexte PDP pour les connexions de données. |

**Objet Contexte PDP :**

| Propriété           | Type de données | Description                                               |
| :------------------ | :-------------- | :-------------------------------------------------------- |
| `rat_type`          | INTEGER         | Identifiant du type de technologie d'accès radio.        |
| `ipcan_session_id`  | STRING          | Identifiant de session IP-CAN pour la connexion de données. |
```

  </Tab>
</Tabs>
