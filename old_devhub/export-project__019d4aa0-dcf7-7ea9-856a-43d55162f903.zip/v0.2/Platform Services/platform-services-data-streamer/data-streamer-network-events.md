---
title: "Network Events"
slug: "data-streamer-network-events"
excerpt: "Comprehensive guide to Network Events provided by the Bell Data Streamer, including Network Events, PDP Context Events, Quota Events, and SIM Management Events."
hidden: false
metadata: 
  title: "Data Streamer - Network Events | Bell Developer Hub"
  description: "Get to know the Netowrk Events provided by the Data Streamer."
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:29:04 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Nov 10 2025 13:50:13 GMT+0000 (Coordinated Universal Time)"
---
# Événements réseau

Le service Bell Data Streamer fournit un flux en temps réel d’événements réseau provenant de vos appareils IoT et de votre infrastructure réseau. Ces événements réseau vous offrent une visibilité complète sur la connectivité des appareils, les mises à jour de localisation, l’utilisation des données, la gestion des quotas et les activités système. Le format exact des événements réseau dépend de l’intégration utilisée, mais ce chapitre se concentre sur le format d’objet JSON délivré par le Data Streamer.

Les événements réseau sont classés en plusieurs types :

- [Network Events](#network-events) - Mises à jour de localisation et attachements réseau
- [PDP Context Events](#pdp-context-events) - Cycle de vie des sessions de données
- [SIM Management Events](#sim-management-events) - Activation de SIM et changements d’état
- [Quota Events](#quota-events) - Gestion des quotas de données et SMS
- [System Events](#system-events) - Gestion VPN et points de terminaison

***

## Aperçu de la structure des événements réseau

Tous les événements réseau partagent une structure commune avec les composants principaux suivants :

- [Generic Properties](#generic-properties) - Toujours présentes dans chaque événement réseau
- [Additional Properties](#additional-properties) - Informations SIM, IMSI et point de terminaison (endpoint) optionnelles
- [Detail Properties](#detail-properties) - Informations supplémentaires propres au type d’événement réseau

***

## Exemples d’événements réseau

Voici des exemples d’événements réseau de différentes catégories montrant la structure JSON délivrée par le Data Streamer :

<Tabs>
  <Tab title="Événement réseau">
    ```json
    {
      "id": 12345678,
      "timestamp": "2024-12-13T12:49:57.000Z",
      "event_type": {
        "id": 1,
        "description": "Update location"
      },
      "event_severity": {
        "id": 0,
        "description": "INFO"
      },
      "event_source": {
        "id": 0,
        "description": "Network"
      },
      "organisation": {
        "id": 100018,
        "name": "81013181"
      },
      "alert": false,
      "description": "New location received from VLR for IMSI = '901405105682328', now attached to VLR = '491720215095'",
      "sim": {
        "id": 10000106,
        "iccid": "8988228066605682328",
        "msisdn": "882285105682328"
      },
      "imsi": {
        "id": 100000106,
        "imsi": "901405105682328"
      },
      "endpoint": {
        "id": 100000325,
        "imei": "8697060538230193",
        "name": "8988228066605682328",
        "ip_address": "10.0.0.180"
      },
      "detail": {
        "id": 3,
        "name": "Vodafone",
        "country": {
          "id": 74,
          "mcc": "262",
          "name": "Germany",
          "iso_code": "de",
          "country_code": "49"
        },
        "mnc": [
          {
            "id": 3,
            "mnc": "02"
          }
        ],
        "tapcode": [
          {
            "id": 2,
            "tapcode": "DEUD2"
          }
        ]
      }
    }
    ```
  </Tab>

  <Tab title="Événement de contexte PDP">
    ```json
    {
      "id": 12345679,
      "timestamp": "2024-12-13T12:48:24.000Z",
      "event_type": {
        "id": 3,
        "description": "Create PDP Context"
      },
      "event_severity": {
        "id": 0,
        "description": "INFO"
      },
      "event_source": {
        "id": 0,
        "description": "Network"
      },
      "organisation": {
        "id": 100710,
        "name": "81016541"
      },
      "alert": false,
      "description": "New PDP Context successfully activated with SGSN CP=139.7.133.222, DP=139.7.133.231.",
      "sim": {
        "id": 10000675,
        "iccid": "8988228530100000018",
        "msisdn": "882285301000018"
      },
      "imsi": {
        "id": 100000676,
        "imsi": "901405301000018"
      },
      "endpoint": {
        "id": 100000821,
        "imei": "3500196576514927",
        "name": "8988228530100000018",
        "ip_address": "10.0.0.24"
      },
      "detail": {
        "id": 3,
        "name": "Vodafone",
        "country": {
          "id": 74,
          "mcc": "262",
          "name": "Germany",
          "iso_code": "de",
          "country_code": "49"
        },
        "pdp_context": {
          "pdp_context_id": 2382739057,
          "tunnel_created": "2024-12-13T12:48:24",
          "ue_ip_address": "10.0.0.24",
          "apn": "stg.eu.ng.bell.net",
          "rat_type": 6,
          "mcc": "262",
          "mnc": "02"
        }
      }
    }
    ```
  </Tab>

  <Tab title="Événement de quota">
    ```json
    {
      "id": 17254295,
      "timestamp": "2025-10-06T03:22:07.622Z",
      "event_type": {
        "id": 19,
        "description": "Quota used up"
      },
      "event_severity": {
        "id": 1,
        "description": "WARN"
      },
      "event_source": {
        "id": 1,
        "description": "Policy Control"
      },
      "organisation": {
        "id": 75488,
        "name": "90000004"
      },
      "alert": true,
      "description": "Quota volume is completely used up and data access denied for endpoint.",
      "sim": {
        "id": 10005527,
        "iccid": "8988228066680001098",
        "msisdn": "882285106459880"
      },
      "imsi": {
        "id": 100005527,
        "imsi": "901405180001098"
      },
      "endpoint": {
        "id": 100000489,
        "imei": "8686990578761101",
        "name": "8988228066680001098",
        "ip_address": "10.0.0.21"
      },
      "detail": {
        "quota": {
          "id": 876,
          "volume": -0.6077737808227539,
          "total_volume": 500,
          "threshold": {
            "volume": 100,
            "percentage": 20
          },
          "expiry_date": "2035-12-19T00:00:00Z"
        }
      }
    }
    ```
  </Tab>

  <Tab title="Événement de gestion SIM">
    ```json
    {
      "id": 17369194,
      "timestamp": "2025-10-09T10:52:27Z",
      "event_type": {
        "id": 8,
        "description": "SIM activation"
      },
      "event_severity": {
        "id": 0,
        "description": "INFO"
      },
      "event_source": {
        "id": 2,
        "description": "API"
      },
      "organisation": {
        "id": 99971,
        "name": "81053872"
      },
      "alert": false,
      "description": "Status of SIM changed from 'Suspended' to 'Activated'",
      "endpoint": {
        "id": 100112571,
        "imei": "",
        "ip_address": "10.0.0.2",
        "name": "2234567890000030861"
      },
      "imsi": {
        "id": 100050655,
        "imsi": "223456000032900"
      },
      "sim": {
        "iccid": "2234567890000030861",
        "id": 10050478,
        "msisdn": "223456000032190"
      }
    }
    ```
  </Tab>
</Tabs>

***

## Propriétés génériques

Les propriétés génériques sont des champs toujours inclus dans un message JSON d’événement réseau reçu via le Data Streamer. Ces propriétés fournissent des informations essentielles sur chaque événement réseau.

| Propriété        | Type de données  | Description                                                                                                                                           |
| :--------------- | :--------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------- |
| `id`             | LONG (64 bits)   | ID unique pour chaque événement réseau envoyé. La réception d’ID d’événements réseau dupliqués indique de possibles retransmissions.                  |
| `timestamp`      | HORODATAGE (UTC) | Horodatage avec la date et l’heure de l’occurrence de l’événement réseau au format ISO 8601.                                                          |
| `event_type`     | Objet JSON       | Objet avec un id et une description de l’événement réseau survenu. Voir [Event Types](#event-types) pour la liste de toutes les valeurs possibles.    |
| `event_severity` | Objet JSON       | Objet JSON avec un id et une description du niveau de sévérité de l’événement réseau. Voir [Event Severity](#event-severity) pour toutes les valeurs. |
| `event_source`   | Objet JSON       | Un id et une description de la source de l’événement réseau. Voir [Event Source](#event-source) pour la liste de toutes les valeurs possibles.        |
| `organisation`   | Objet JSON       | Objet contenant l’ID et le nom de l’organisation. Voir [Event Organization](#event-organization) pour plus d’informations.                            |
| `alert`          | BOOLÉEN          | Les événements réseau ayant un fort impact sur le fonctionnement de la connectivité sont signalés comme une alerte.                                   |
| `description`    | CHAÎNE           | Chaîne contenant une description lisible par l’humain de l’événement réseau.                                                                          |

<Accordion title="Event Types" icon="list">
  Les différents types d’événements réseau sont indiqués par l’objet imbriqué Event Type. Cet objet contient un ID et une brève description de l’événement réseau. Le tableau suivant répertorie tous les types d’événements possibles pouvant être reçus via le Data Streamer.

| ID d’événement | Description                                        |
| :------------- | :------------------------------------------------- |
| 1              | Mise à jour de la localisation                     |
| 2              | Mise à jour de la localisation GPRS                |
| 3              | Création de contexte PDP                           |
| 4              | Mise à jour du contexte PDP                        |
| 5              | Suppression du contexte PDP                        |
| 8              | Activation de la SIM                               |
| 9              | Suspension de la SIM                               |
| 11             | Terminal bloqué                                    |
| 15             | Purge de la localisation                           |
| 16             | Purge de la localisation GPRS                      |
| 18             | Seuil de quota atteint                             |
| 19             | Quota épuisé                                       |
| 20             | Seuil de quota SMS atteint                         |
| 21             | Quota SMS épuisé                                   |
| 29             | Déconnexion OpenVPN                                |
| 30             | Authentification OpenVPN                           |
| 42             | Terminal activé                                    |
| 43             | Terminal désactivé                                 |
| 52             | Quota de données activé                            |
| 53             | Quota de données désactivé                         |
| 54             | Quota SMS activé                                   |
| 55             | Quota SMS désactivé                                |
| 56             | Quota de données attribué                          |
| 57             | Quota de données supprimé                          |
| 58             | Quota SMS attribué                                 |
| 59             | Quota SMS supprimé                                 |
| 60             | Quota de données expiré                            |
| 61             | Quota SMS expiré                                   |
| 100            | Quota de données du pool régional épuisé           |
| 101            | Seuil du quota de données du pool régional atteint |
| 102            | Quota SMS du pool régional épuisé                  |
| 103            | Seuil du quota SMS du pool régional atteint        |
| 121            | Terminal supprimé                                  |

</Accordion>

<Accordion title="Event Severity" icon="exclamation-triangle">
  Les niveaux de sévérité d’un événement réseau indiquent l’impact de l’événement sur le bon fonctionnement du système. Les valeurs possibles de sévérité sont listées ci-dessous :

| ID de sévérité | Description   |
| :------------- | :------------ |
| 0              | INFO          |
| 1              | AVERTISSEMENT |
| 2              | AVERTISSEMENT |
| 3              | ERREUR        |
| 4              | CRITIQUE      |

</Accordion>

<Accordion title="Event Source" icon="map-marker-alt">
  En fonction du type d’événement, une source d’origine différente peut être responsable du déclenchement de l’événement réseau. Les sources possibles, composées d’un ID et d’une description, sont listées ci-dessous.

| ID | Description             |
| :- | :---------------------- |
| 0  | Réseau                  |
| 1  | Contrôle des politiques |
| 2  | API                     |

</Accordion>

<Accordion title="Event Organization" icon="building">
  Chaque événement réseau inclut des informations sur l’organisation d’origine. Cela aide à identifier l’organisation dans les cas d’utilisation avec plusieurs Data Streamer pour des sous-organisations. Les champs de propriétés JSON de cet objet sont listés ci-dessous.

| Propriété | Type de données | Description                          |
| :-------- | :-------------- | :----------------------------------- |
| `id`      | ENTIER          | Identifiant unique de l’organisation |
| `name`    | CHAÎNE          | Nom de l’organisation                |

</Accordion>

***

## Propriétés supplémentaires

Les événements réseau liés directement aux SIM, aux terminaux (Endpoints) ou aux utilisateurs peuvent inclure certaines des propriétés optionnelles suivantes.

| Propriété  | Type de données | Description                                                                                           |
| :--------- | :-------------- | :---------------------------------------------------------------------------------------------------- |
| `imsi`     | Objet JSON      | Identité d’abonné mobile international, voir [IMSI Object](#imsi-object) pour plus d’informations.    |
| `sim`      | Objet JSON      | Module d’identification de l’abonné, voir [SIM Object](#sim-object) pour plus d’informations.         |
| `endpoint` | Objet JSON      | Objet d’information du terminal/appareil, voir [Endpoint Object](#endpoint-object) pour plus d’infos. |
| `user`     | CHAÎNE          | Identifiant utilisateur si l’événement réseau a été déclenché par une action utilisateur spécifique.  |

<Accordion title="IMSI Object" icon="id-card">
  L’Identité d’abonné mobile international (IMSI) est utilisée pour identifier chaque appareil avec une SIM. Les paramètres suivants sont inclus dans un événement réseau.

| Propriété     | Type de données  | Description                                                     |
| :------------ | :--------------- | :-------------------------------------------------------------- |
| `id`          | ENTIER           | ID unique de l’IMSI.                                            |
| `imsi`        | CHAÎNE           | L’Identité d’abonné mobile international sous forme de chaîne.  |
| `import_date` | HORODATAGE (UTC) | Horodatage de l’approvisionnement de l’IMSI au format ISO 8601. |

</Accordion>

<Accordion title="SIM Object" icon="sim-card">
  Chaque carte SIM possède des propriétés et paramètres uniques. Ces données sont incluses dans le flux d’événements réseau. La liste des champs disponibles est présentée ci-dessous.

| Propriété         | Type de données  | Description                                                  |
| :---------------- | :--------------- | :----------------------------------------------------------- |
| `id`              | ENTIER           | ID unique de la SIM.                                         |
| `iccid`           | CHAÎNE           | Identifiant de la carte à circuit intégré (ICCID) de la SIM. |
| `msisdn`          | CHAÎNE           | ISDN de l’abonné mobile (MSISDN) de la carte SIM.            |
| `production_date` | HORODATAGE (UTC) | Horodatage de la production de la SIM au format ISO 8601.    |

</Accordion>

<Accordion title="Endpoint Object" icon="mobile-alt">
  Lorsqu’une SIM est insérée dans un appareil, certaines informations sur ce terminal sont transmises via le réseau mobile. Ces informations sont utiles pour identifier le type d’appareil spécifique et certains paramètres de connexion. La liste de tous les champs de l’objet Endpoint est présentée ci-dessous.

| Propriété    | Type de données | Description                                                              |
| :----------- | :-------------- | :----------------------------------------------------------------------- |
| `id`         | ENTIER          | ID unique du terminal (Endpoint).                                        |
| `name`       | CHAÎNE          | Nom de la configuration du terminal.                                     |
| `ip_address` | CHAÎNE          | Adresse IP statique spécifique de la carte SIM/du terminal.              |
| `tags`       | CHAÎNE          | Étiquettes (tags) attribuées au terminal.                                |
| `imei`       | CHAÎNE          | Identité internationale d’équipement mobile (IMEI) du terminal/appareil. |

</Accordion>

***

## Propriétés de détail

Pour certains types d’événements réseau, des paramètres d’information supplémentaires sont ajoutés dans les propriétés de détail. Le contenu varie en fonction du type d’événement réseau et fournit un contexte spécifique à cette catégorie d’événement.

<Accordion title="Network Detail Properties" icon="network-wired">
  Les événements réseau incluent des informations d’opérateur et de pays dans leurs propriétés de détail.

| Propriété | Type de données | Description                                                                                            |
| :-------- | :-------------- | :----------------------------------------------------------------------------------------------------- |
| `id`      | ENTIER          | ID unique de l’opérateur de réseau mobile utilisé.                                                     |
| `name`    | CHAÎNE          | Nom de l’opérateur de réseau mobile.                                                                   |
| `country` | Objet JSON      | Pays de l’opérateur de réseau mobile. Voir [Country Object](#country-object) pour plus d’informations. |
| `mnc`     | TABLEAU         | Tableau d’objets Mobile Network Code avec les champs id et mnc.                                        |
| `tapcode` | TABLEAU         | Tableau d’objets TAP code avec les champs id et tapcode.                                               |

</Accordion>

<Accordion title="PDP Context Detail Properties" icon="server">
  Les événements de contexte PDP incluent des informations détaillées sur la session de données dans leurs propriétés de détail.

| Propriété     | Type de données | Description                                                                                                          |
| :------------ | :-------------- | :------------------------------------------------------------------------------------------------------------------- |
| `id`          | ENTIER          | ID unique de l’opérateur de réseau mobile utilisé.                                                                   |
| `name`        | CHAÎNE          | Nom de l’opérateur de réseau mobile.                                                                                 |
| `country`     | Objet JSON      | Pays de l’opérateur de réseau mobile. Voir [Country Object](#country-object) pour plus d’informations.               |
| `pdp_context` | Objet JSON      | Objet avec des détails sur le contexte PDP. Voir [PDP Context Object](#pdp-context-object) pour plus d’informations. |

</Accordion>

<Accordion title="Quota Detail Properties" icon="chart-bar">
  Les événements de quota incluent des informations de quota et, éventuellement, des détails de pool régional.

| Propriété       | Type de données | Description                                                                                       |
| :-------------- | :-------------- | :------------------------------------------------------------------------------------------------ |
| `quota`         | Objet JSON      | Objet avec des détails sur le quota. Voir [Quota Object](#quota-object) pour plus d’informations. |
| `regional_pool` | Objet JSON      | Objet avec des informations de pool régional (pour les événements réseau de pool régional).       |

</Accordion>

<Accordion title="VPN Detail Properties" icon="shield-alt">
  Les événements VPN incluent des informations sur le client et la connexion.

| Propriété | Type de données | Description                                              |
| :-------- | :-------------- | :------------------------------------------------------- |
| `vpn_id`  | ENTIER          | OSS VPN ID                                               |
| `region`  | CHAÎNE          | Code de région AWS                                       |
| `client`  | Objet JSON      | Objet avec les champs version, private\_ip et public\_ip |

</Accordion>

<Accordion title="Country Object" icon="globe">
  Un objet JSON imbriqué dans les propriétés de détail contient plus d’informations sur le pays où l’événement réseau de la SIM a eu lieu. Les champs de l’objet Pays sont listés ci-dessous.

| Propriété       | Type de données | Description               |
| :-------------- | :-------------- | :------------------------ |
| `id `           | ENTIER          | ID unique d’un pays.      |
| `name `         | CHAÎNE          | Nom du pays.              |
| `country_code ` | CHAÎNE          | Code pays                 |
| `mcc`           | CHAÎNE          | Mobile Country Code (MCC) |
| `iso_code `     | CHAÎNE          | Code pays ISO             |

</Accordion>

<Accordion title="PDP Context Object" icon="network-wired">
  Un événement réseau pour un contexte PDP inclut un large éventail d’informations supplémentaires dans les propriétés de détail. Les champs individuels sont listés ci-dessous.

[block:parameters]
{
  "data": {
    "h-0": "Propriété",
    "h-1": "Type de données",
    "h-2": "Description",
    "0-0": "`pdp_context_id`",
    "0-1": "ENTIER",
    "0-2": "ID du contexte PDP",
    "1-0": "`tunnel_created`",
    "1-1": "HORODATAGE (UTC)",
    "1-2": "Heure de création de la session PDP",
    "2-0": "`gtp_version`",
    "2-1": "ENTIER",
    "2-2": "Version GTP 1/2",
    "3-0": "`ggsn_control_plane_ip_address`",
    "3-1": "CHAÎNE",
    "3-2": "Adresse IP du plan de contrôle GGSN/PGW",
    "4-0": "`ggsn_data_plane_ip_address`",
    "4-1": "CHAÎNE",
    "4-2": "Adresse IP du plan de données GGSN/PGW",
    "5-0": "`sgsn_control_plane_ip_address`",
    "5-1": "CHAÎNE",
    "5-2": "Adresse IP du plan de contrôle SGSN/SGW",
    "6-0": "`sgsn_data_plane_ip_address`",
    "6-1": "CHAÎNE",
    "6-2": "Adresse IP du plan de données SGSN/SGW",
    "7-0": "`region`",
    "7-1": "CHAÎNE",
    "7-2": "Région du plan de données",
    "8-0": "`breakout_ip`",
    "8-1": "CHAÎNE",
    "8-2": "Adresse IP utilisée pour l’Internet Breakout",
    "9-0": "`apn`",
    "9-1": "CHAÎNE",
    "9-2": "Nom du point d’accès (APN)",
    "10-0": "`nsapi`",
    "10-1": "ENTIER",
    "10-2": "Network Service Access Point Identifier (NSAPI)",
    "11-0": "`ue_ip_address`",
    "11-1": "CHAÎNE",
    "11-2": "Adresse IP de l’appareil",
    "12-0": "`imeisv`",
    "12-1": "CHAÎNE",
    "12-2": "Identité internationale d’équipement mobile - Version logicielle",
    "13-0": "`mcc`",
    "13-1": "CHAÎNE",
    "13-2": "Mobile Country Code (MCC)",
    "14-0": "`mnc`",
    "14-1": "CHAÎNE",
    "14-2": "Mobile Network Code (MNC)",
    "15-0": "`lac`",
    "15-1": "ENTIER",
    "15-2": "Location Area Code (LAC)",
    "16-0": "`sac`",
    "16-1": "ENTIER",
    "16-2": "Service Area code (SAC)",
    "17-0": "`rac`",
    "17-1": "ENTIER",
    "17-2": "Routing Area code (RAC)",
    "18-0": "`ci`",
    "18-1": "ENTIER",
    "18-2": "Cell Identification (CI)",
    "19-0": "`rat_type`",
    "19-1": "ENTIER",
    "19-2": "Type d’accès radio (RAT)<br />1 - 3G<br />2 - 2G<br />5 - HSPA+<br />6 - LTE<br />8 - NB-IoT<br />9 - CAT-M",
    "20-0": "`gtp_v1_uli`",
    "20-1": "Objet JSON",
    "20-2": "Informations de localisation utilisateur GTP V1 avec les champs lac, ci, sac, rac",
    "21-0": "`gtp_v2_uli`",
    "21-1": "Objet JSON",
    "21-2": "Informations de localisation utilisateur GTP V2 avec les champs cgi, sai, rai, tac, eci, lac, menbi, emenbi",
    "22-0": "`tx_teid_data_plane`",
    "22-1": "ENTIER",
    "22-2": "TEID PGW/GGSN user\\_plane",
    "23-0": "`tx_teid_control_plane`",
    "23-1": "ENTIER",
    "23-2": "TEID PGW/GGSN control\\_plane",
    "24-0": "`rx_teid`",
    "24-1": "ENTIER",
    "24-2": "Identifiant de point de terminaison de tunnel reçu",
    "25-0": "`tariff_id`",
    "25-1": "CHAÎNE",
    "25-2": "Identifiant du tarif",
    "26-0": "`operator_id`",
    "26-1": "CHAÎNE",
    "26-2": "Identifiant de l’opérateur",
    "27-0": "`ratezone_id`",
    "27-1": "CHAÎNE",
    "27-2": "Identifiant de la zone tarifaire",
    "28-0": "`ipcan_session_id`",
    "28-1": "CHAÎNE",
    "28-2": "Identifiant de session IP-CAN"
  },
  "cols": 3,
  "rows": 29,
  "align": [
    "left",
    "left",
    "left"
  ]
}
[/block]


</Accordion>

<Accordion title="Quota Object" icon="chart-bar">
  Les événements de quota incluent des informations détaillées sur l’état et l’utilisation du quota. La description du contenu des champs est listée ci-dessous.

| Propriété                  | Type de données  | Description                                                             |
| :------------------------- | :--------------- | :---------------------------------------------------------------------- |
| `id`                       | ENTIER           | Identifiant unique du quota                                             |
| `volume`                   | DÉCIMAL          | Volume restant (peut être négatif en cas de dépassement)                |
| `total_volume`             | DÉCIMAL          | Volume total alloué                                                     |
| `accumulated_total_volume` | DÉCIMAL          | Somme de toutes les attributions de quota                               |
| `last_volume_added`        | DÉCIMAL          | Dernier ajout de quota                                                  |
| `service`                  | CHAÎNE           | Type de service : "data" ou "sms"                                       |
| `threshold`                | Objet JSON       | Objet avec les champs volume et percentage pour le paramétrage du seuil |
| `threshold_percentage`     | ENTIER           | Seuil en pourcentage (0-100)                                            |
| `threshold_volume`         | DÉCIMAL          | Volume de seuil calculé                                                 |
| `expiry_date`              | HORODATAGE (UTC) | Date d’expiration du quota                                              |
| `created_at`               | HORODATAGE (UTC) | Date de création du quota                                               |
| `status`                   | Objet JSON       | Objet avec id et description pour l’état du quota                       |

</Accordion>

***

## Catégories d’événements réseau

Les événements réseau sont organisés selon les catégories fonctionnelles suivantes :

<Accordion title="Événements réseau" icon="wifi">
  Les événements réseau suivent les changements de localisation des appareils et les attachements au réseau.

  **Mise à jour de la localisation (ID : 1)**

- Envoyé lorsque le terminal change de localisation sur le réseau CS (circuit commuté)

- Inclut les informations d’attachement au VLR

  **Mise à jour de la localisation GPRS (ID : 2)**

- Envoyé lorsque le terminal change de localisation sur le réseau PS (paquets commutés)

- Inclut les informations d’attachement au SGSN

  **Purge de la localisation (ID : 15)**

- Envoyé lorsque les informations de localisation CS sont nettoyées

  **Purge de la localisation GPRS (ID : 16)**

- Envoyé lorsque les informations de localisation PS sont nettoyées  
  </Accordion>

<Accordion title="Événements de contexte PDP" icon="server">
  Les événements de contexte PDP suivent le cycle de vie des sessions de données.

  **Création de contexte PDP (ID : 3)**

- Envoyé lorsque le terminal établit une session de données

- Inclut des détails complets du contexte PDP

- Également envoyé en cas de violations de verrouillage IMEI

  **Mise à jour du contexte PDP (ID : 4)**

- Envoyé lorsque la session de données est mise à jour

- Inclut des informations de contexte PDP mises à jour

  **Suppression du contexte PDP (ID : 5)**

- Envoyé lorsque la session de données est terminée

- Inclut l’état final du contexte PDP  
  </Accordion>

<Accordion title="Événements de gestion SIM" icon="sim-card">
  Les événements de gestion SIM suivent le cycle de vie de la SIM et les changements d’état.

  **Activation de la SIM (ID : 8)**

- Envoyé lorsque l’état de la SIM passe à activé

  **Suspension de la SIM (ID : 9)**

- Envoyé lorsque l’état de la SIM passe à suspendu/désactivé

  **Terminal activé (ID : 42)**

- Envoyé lorsque l’état du terminal est défini sur activé

  **Terminal désactivé (ID : 43)**

- Envoyé lorsque l’état du terminal est défini sur désactivé

  **Terminal bloqué (ID : 11)**

- Envoyé lorsque le terminal est bloqué (par ex. limite mensuelle dépassée)

  **Terminal supprimé (ID : 121)**

- Envoyé lorsque le terminal est supprimé de l’organisation  
  </Accordion>

<Accordion title="Événements de quota" icon="chart-bar">
  Les événements de quota suivent la gestion et l’utilisation des quotas de données et de SMS.

  **Événements de quota de données**

- Quota de données activé/désactivé (ID : 52/53)

- Quota de données attribué/supprimé (ID : 56/57)

- Quota de données expiré (ID : 60)

- Seuil de quota atteint (ID : 18)

- Quota épuisé (ID : 19)

  **Événements de quota SMS**

- Quota SMS activé/désactivé (ID : 54/55)

- Quota SMS attribué/supprimé (ID : 58/59)

- Quota SMS expiré (ID : 61)

- Seuil de quota SMS atteint (ID : 20)

- Quota SMS épuisé (ID : 21)

  **Événements de pool régional**

- Quota de données/SMS du pool régional épuisé (ID : 100/102)

- Seuil de quota de données/SMS du pool régional atteint (ID : 101/103)  
  </Accordion>

<Accordion title="Événements système" icon="cog">
  Les événements système suivent les activités d’infrastructure et de service.

  **Événements VPN**

- Authentification OpenVPN (ID : 30)
- Déconnexion OpenVPN (ID : 29)

    Ces événements réseau incluent des détails sur le client VPN et des informations de connexion.  
  </Accordion>

***

## Traitement des événements réseau

Lors du traitement des événements réseau provenant du Data Streamer :

1. Vérifiez l’ID de l’événement réseau : utilisez le champ unique `id` pour détecter les retransmissions
2. Surveillez les alertes : prêtez attention aux événements réseau où `alert` vaut `true`
3. Filtrez par sévérité : utilisez `event_severity` pour vous concentrer sur les problèmes critiques
4. Suivez les organisations : utilisez `organisation` pour séparer les scénarios multi-locataires
5. Analysez les propriétés de détail : extrayez les informations spécifiques à l’événement à partir de l’objet `detail` selon le type d’événement réseau
