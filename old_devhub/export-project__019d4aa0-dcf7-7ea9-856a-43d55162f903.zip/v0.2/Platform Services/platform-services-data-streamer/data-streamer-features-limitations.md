---
title: "Features & Limitations"
slug: "data-streamer-features-limitations"
excerpt: "A look into what the Bell Data Streamer can and cannot do."
hidden: false
metadata: 
  title: "Data Streamer - Features and Limitations | Bell Developer Hub"
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:29:08 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Nov 10 2025 13:50:01 GMT+0000 (Coordinated Universal Time)"
---
# Fonctionnalités

## Surveillance des événements réseau, d’utilisation et SMS

Avec le service Bell Data Streamer, les clients peuvent recevoir en diffusion continue des événements réseau, des enregistrements d’utilisation et des événements SMS pour leurs cartes SIM Bell. Cette solution de supervision complète permet aux clients Bell de suivre l’état de connectivité et les schémas d’utilisation de chaque SIM individuellement, en quasi temps réel.

### Événements réseau

Les événements réseau fournissent des informations détaillées sur la connectivité des appareils au réseau mobile, notamment :

- Événements d’établissement et de fin de connexion
- Mises à jour de localisation et attachements au réseau
- Avertissements réseau et informations de débogage des erreurs
- Événements de création et de suppression de contexte PDP
- Modifications de l’état du réseau mobile

Les événements réseau aident à résoudre les problèmes de connectivité et à surveiller les performances globales du réseau de vos appareils IoT.

### Enregistrements d’utilisation

Les enregistrements d’utilisation offrent des informations granulaires sur les schémas de consommation de volumes de données et de SMS, notamment :

- Surveillance du volume de trafic de données (émis et reçu)
- Suivi de l’utilisation des SMS pour les messages d’origine mobile (MO) et à destination mobile (MT)
- Alertes de seuils de volume et de gestion des quotas
- Suivi des coûts et informations de facturation

Les enregistrements d’utilisation sont générés en temps réel, les enregistrements de session de données étant créés après la clôture de la session et les enregistrements SMS étant générés pour chaque message.

### Événements SMS

Les événements SMS offrent une supervision complète de l’activité de messagerie SMS, notamment :

- Suivi du statut de livraison des SMS à destination mobile (MT)
- Surveillance de la réception des SMS d’origine mobile (MO)
- Informations sur la mise en file d’attente des SMS et les tentatives de nouvelle transmission
- Confirmations de livraison et notifications d’échec
- Suivi de la charge utile du message et des métadonnées

Les événements SMS permettent une visibilité totale sur les capacités de messagerie de vos appareils et contribuent à garantir une communication fiable.

## Diffusion multi-cible

Le service Bell Data Streamer permet de configurer plusieurs applications cibles pour les mêmes données diffusées, et ce pour tous les types d’événements. Cela permet aux clients d’intégrer les événements réseau, les enregistrements d’utilisation et les événements SMS dans plusieurs systèmes d’analyse et de supervision simultanément. Chaque récepteur configuré recevra les dernières mises à jour poussées pour les trois types d’événements. Les flux individuels peuvent être configurés dans le Portail Bell, sous l’onglet Configuration, où chaque flux peut également être mis en pause/repris et supprimé.

## Plateformes d’analyse de données

Les trois types d’événements (réseau, utilisation et SMS) peuvent être intégrés aux plateformes les plus courantes d’analyse et de supervision des données. Bell fournit des intégrations prêtes à l’emploi pour certaines plateformes tierces. Actuellement, Bell Data Streamer prend en charge les options d’intégration suivantes :

- <a href="https://aws.amazon.com/kinesis/" target="_blank">AWS Kinesis</a>
- <a href="https://aws.amazon.com/s3/" target="_blank">AWS S3</a>
- DataDog
- Keen.io

## Point de terminaison API personnalisé

En plus des intégrations tierces prêtes à l’emploi, Bell offre la possibilité d’intégrer votre propre point de terminaison HTTP POST, qui peut être configuré pour recevoir les trois types d’enregistrements (événements réseau, enregistrements d’utilisation et événements SMS) depuis le data streamer. Les clients peuvent utiliser cette intégration pour inclure le service Bell Data Streamer dans l’application ou le système de supervision de leur choix.

Le point de terminaison HTTP gère les requêtes POST avec un corps JSON contenant jusqu’à 3 000 enregistrements par requête. Votre point de terminaison doit répondre avec le code d’état HTTP 200 pour accuser bonne réception — les enregistrements accusés réception ne seront pas renvoyés.

## Traitement en temps réel et données historiques

Le Data Streamer offre un traitement en quasi temps réel pour tous les types d’événements, avec la possibilité d’inclure les données historiques des sept derniers jours lors de la configuration initiale. Cela vous permet de commencer la supervision immédiatement tout en assurant la continuité avec l’activité récente.

# Limitations

## Rétention des données

Les données d’événements et d’utilisation dans l’API sont conservées pendant un maximum de sept jours en raison des politiques de rétention des données. Pour le stockage et l’analyse à long terme, utilisez les intégrations du service Data Streamer.

## Limites de débit de l’API

L’API n’est pas recommandée pour de grandes requêtes automatisées régulières. Pour la supervision automatisée de plusieurs SIM, utilisez plutôt le service Data Streamer.

## Limites des messages SMS

- Les messages MT-SMS sont limités à 160 caractères par message
- Des SMS concaténés peuvent être envoyés via l’API pour des messages plus longs
- La durée d’expiration par défaut des SMS est de 24 heures (personnalisable)

## Limites d’intégration

- Jusqu’à 10 flux de données différents peuvent être configurés par compte client
- Les points de terminaison HTTP doivent traiter les requêtes POST et répondre avec le statut HTTP 200
- Maximum de 3 000 enregistrements JSON par requête HTTP POST
