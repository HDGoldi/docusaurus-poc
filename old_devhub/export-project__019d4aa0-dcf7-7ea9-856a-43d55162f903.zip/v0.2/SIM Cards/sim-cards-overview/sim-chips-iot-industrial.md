---
title: "IoT SIM Chip Industrial"
slug: "sim-chips-iot-industrial"
excerpt: "Embedded SIM Card Specifications"
hidden: false
createdAt: "Mon Aug 05 2024 14:30:46 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Dec 01 2025 21:14:21 GMT+0000 (Coordinated Universal Time)"
---
La carte SIM traditionnelle à dos plastique provient de l’usage dans les équipements utilisateur (UE) pour les télécommunications, où les clients devaient échanger les SIM facilement car les appareils n’étaient pas liés à une SIM particulière. À partir de 2016, la SIM embarquée (eSIM) ou carte à circuit intégré universelle embarquée (eUICC) a suscité l’intérêt des développeurs en raison de son empreinte plus réduite et de possibilités d’intégration plus poussées. 

Surtout dans les cas d’applications matérielles embarquées sur mesure M2M (Machine-to-Machine) et IoT, la IoT SIM Chip Industrial offre des avantages uniques par rapport à la IoT SIM Card Business traditionnelle. Dans les appareils IoT conçus à cet effet, il n’est pas nécessaire d’effectuer des remplacements manuels réguliers de carte SIM. Des facteurs clés comme la robustesse, la sécurité et les contraintes d’encombrement sont prioritaires. Pour ces besoins spécifiques, la Bell IoT SIM Chip Industrial offre la solution idéale. Cette section présente le produit Bell IoT SIM Chip Industrial, avec son format standardisé, ses spécifications techniques et un aperçu des cas d’utilisation recommandés.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/91e059b1a1f84c0716d5f6b97361a425aea65ad1979cb092c7cb06600a3dd34e-industrialSIM-FR.png",
        null,
        "Circuit intégré MFF2 1NCE IoT SIM Chip Industrial."
      ],
      "align": "center",
      "sizing": "20% ",
      "caption": "Circuit intégré MFF2 Bell IoT SIM Chip Industrial."
    }
  ]
}
[/block]


***

# Format de la puce SIM IoT industrielle

Comme la puce SIM IoT industrielle est une évolution de la IoT SIM Card Business traditionnelle, elle offre les mêmes fonctionnalités technologiques mais dans un format physique plus compact. Le format de la puce SIM IoT industrielle est communément désigné MFF2. La Bell IoT SIM Chip Industrial est conforme à cette empreinte MFF2 dans un boîtier Circuit Intégré (CI) de type Quad-Flat No-Leads 8 (QFN8). Le boîtier MFF2 est spécifié dans <a href="https://www.etsi.org/deliver/etsi_ts/102600_102699/102671/09.00.00_60/ts_102671v090000p.pdf" target="blank_">ETSI 102 671</a>.

Le boîtier QFN8 de la puce SIM IoT industrielle n’est pas monté dans un adaptateur à support comme la IoT SIM Card Business, il est conçu pour être directement soudé sur le circuit imprimé (PCB) d’un appareil. QFN8 est une empreinte souvent utilisée dans les dispositifs électroniques. Il peut donc être facilement intégré dans des chaînes de production d’assemblage automatisées pour des appareils compatibles IoT. Les spécifications du facteur de forme sont présentées dans la figure ci-dessous.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/8f83e1d-1NCE_eSIM_Dimensions.png",
        "1NCE_eSIM_Dimensions.png",
        1827
      ],
      "align": "center",
      "sizing": "80",
      "caption": "Dimensions du facteur de forme MFF2 de la Bell IoT SIM Chip Industrial"
    }
  ]
}
[/block]


Les SIM embarquées partagent le même brochage de base que les cartes SIM IoT Business mais dans un autre facteur de forme, comme illustré ci-dessus. Le tableau suivant répertorie l’affectation des broches et leurs fonctions respectives.

[block:parameters]
{
  "data": {
    "h-0": "Broche de contact",
    "h-1": "Description de la spécification",
    "h-2": "Brochage de la Bell IoT SIM Chip Industrial",
    "0-0": "C1",
    "0-1": "**VCC**  \nTension d’alimentation",
    "0-2": "VCC",
    "1-0": "C2",
    "1-1": "**RST**  \nBroche de réinitialisation",
    "1-2": "RST",
    "2-0": "C3",
    "2-1": "**CLK**  \nSignal d’horloge",
    "2-2": "CLK",
    "3-0": "C4 and C8",
    "3-1": "**Optionnel**  \nInterface USB selon ETSI TS 102 600",
    "3-2": "N/A",
    "4-0": "C5",
    "4-1": "**GND**  \nConnexion à la masse",
    "4-2": "GND",
    "5-0": "C6",
    "5-1": "**VPP**  \nTension de programmation",
    "5-2": "N/A",
    "6-0": "C7",
    "6-1": "**I/O**  \nDonnées d’entrée/sortie",
    "6-2": "I/O"
  },
  "cols": 3,
  "rows": 7,
  "align": [
    "left",
    "left",
    "left"
  ]
}
[/block]


***

# Expédition et conditionnement pour assemblage

Lors de la commande de Bell IoT SIMs Chip Industrial, les CI QFN8 sont conditionnés sur une bobine standardisée de 100, 500 et 3000 IoT SIMs Chip Industrial. Ces bobines peuvent être utilisées directement sur une ligne de production d’assemblage automatisée.

Les Bell IoT SIMs Chip Industrial sont conditionnées sur une bande de 12 mm de large, d’une épaisseur de 1,2 mm et recouverte d’un film plastique pour maintenir les CI IoT SIM Chip Industrial en place jusqu’à la production. Le processus et les matériaux d’emballage répondent aux exigences définies dans la norme JEDEC J-STD-033, avec des précautions ESD et des procédures de manipulation appropriées. La bande est fournie sur des bobines de 7 pouces (178 mm) et 13 pouces (330 mm). Pour les lots de 100 ou 500 IoT SIMs Chip Industrial, des bobines de 7 pouces sont utilisées, et pour 3000 IoT SIMs Chip Industrial, des bobines de 13 pouces sont utilisées.

**Schéma du boîtier**

![](https://files.readme.io/948f33a84761c2c4213387a79b00b93ada17bd9f27b427c05946effbe0481ca9-image.png)

**Empreinte du boîtier**

![](https://files.readme.io/7b3b41cd125600e0c8d6df30071c4aef89fcb9c1fa54cc4c86b4004f10c08a3e-image.png)

**Conditionnement en bande et en bobine**

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/9fb616e62a74da6e4531c348a40b45daff2e61201909b0af1c8fc4f0b1db682a-image.png",
        null,
        ""
      ],
      "align": "right",
      "sizing": "-3px",
      "border": true
    }
  ]
}
[/block]


_<https://www.infineon.com/dgdl/Infineon-Integration_Guide_SLx16_SLx17-AdditionalTechnicalInformation-v01_00-EN.pdf?fileId=5546d46273a5366f0173e8316de94622>_

Chaque bobine est emballée sous vide séparément avec une carte indicatrice d’humidité, un dessicant et une étiquette à code-barres dans une boîte en carton. L’étiquette à code-barres indique le premier et le dernier ICCID de la bobine IoT SIM Chip Industrial spécifique. Les IoT SIMs Chip Industrial sont produites en séquence dans l’ordre croissant, où le plus petit ICCID est produit en premier et se trouve à l’extrémité de la bande, au milieu de la bobine. Le sens de déroulement pour l’utilisateur est conforme à la norme EIA-481.

***

# Identification eID de la puce SIM IoT industrielle

Un eID est un numéro d’identifiant unique mondial à 32 chiffres, contenant des informations identifiant le fournisseur de la SIM physique. Avec la fonctionnalité eUICC, l’eID est le numéro le plus important pour identifier la SIM. L’ICCID peut changer avec la modification du profil actif, mais l’eID est unique à la SIM IoT et reste toujours le même.

L’eID peut être lu par le modem matériel au moyen d’une commande AT ou d’une requête spécifique au fabricant. Pour une identification physique plus aisée, chaque 1NCE IoT SIM Card Industrial a l’eID de la SIM concernée imprimé sur la carte à puce physique 4FF.

Pour plus d’informations sur l’eID, veuillez consulter la [documentation GSMA officielle](https://www.gsma.com/esim/resources/sgp-29-v1-0-eid-definition-and-assignment-process/) 

***

# Spécifications de la puce SIM IoT industrielle

Les cartes SIM pour les applications sur réseaux mobiles suivent des normes strictes tant pour le facteur de forme physique que pour la technologie et les interfaces. Les 1NCE IoT SIMs Chip Industrial sont conformes à ces spécifications techniques normalisées. Outre les principales conformités aux normes, les puces SIM sont validées pour des plages environnementales spécifiques dans lesquelles elles doivent fonctionner. Le tableau ci-dessous présente les spécifications les plus importantes des 1NCE IoT SIM Chip Industrial pertinentes pour le déploiement de la 1NCE IoT SIM Chip Industrial. En outre, des références aux principales conformités normatives pour les interfaces SIM sont fournies.

[block:html]
{
  "html": "<div class=\"rdmd-table\">\n\t<div class=\"rdmd-table-inner\">\n\t<style type=\"text/css\">.tdc { text-align:center;}</style>\n\t\t<table>\n\t\t\t<thead>\n\t\t\t\t<tr>\n\t\t\t\t\t<th>Paramètre</th>\n\t\t\t\t\t<th>1NCE IoT SIM Chip Industrial</th>\n\t\t\t\t</tr>\n\t\t\t</thead>\n\t\t\t<tbody>\n\t\t\t\t<tr>\n\t\t\t\t\t<td>Facteur de forme (FF)</td>\n\t\t\t\t\t<td class=\"tdc\">MFF2, QFN8 (boîtier CI)</td>\n\t\t\t\t</tr>\n\t\t\t\t<tr>\n\t\t\t\t\t<td>Technologies d’accès radio prises en charge (RAT)</td>\n\t\t\t\t\t<td class=\"tdc\">2G, 3G, 4G, CAT-M1, NB-IoT</td>\n\t\t\t\t</tr>\n\t\t\t\t<tr>\n\t\t\t\t\t<td>Température environnementale</td>\n\t\t\t\t\t<td class=\"tdc\">-40°C to +105°C</td>\n\t\t\t\t</tr>\n\t\t\t\t<tr>\n\t\t\t\t\t<td>Tensions de fonctionnement</td>\n\t\t\t\t\t<td class=\"tdc\">Classe A, B et C (1.62V – 5.5V)</td>\n\t\t\t\t</tr>\n\t\t\t\t<tr>\n\t\t\t\t\t<td>Période de rétention des données</td>\n\t\t\t\t\t<td class=\"tdc\">min. 10 years</td>\n\t\t\t\t</tr>\n         <tr>\n\t\t\t\t\t<td>Nombre de profils</td>\n\t\t\t\t\t<td class=\"tdc\">max. 10 </td>\n\t\t\t\t</tr>\n\t\t\t\t<tr>\n\t\t\t\t\t<td>Cycles de lecture/écriture</td>\n\t\t\t\t\t<td class=\"tdc\">min. 2.000.000 cycles</td>\n\t\t\t\t\t<tr>\n\t\t\t\t\t\t<td>Principales conformités aux normes</td>\n\t\t\t\t\t\t<td class=\"tdc\"><a href=\"https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=1833\" target=\"blank_\">3GPP TR 31.919</a></td>\n\t\t\t\t\t</tr>\n\t\t\t\t\t<tr>\n\t\t\t\t\t\t<td/>\n\t\t\t\t\t\t<td class=\"tdc\"><a href=\"https://www.etsi.org/deliver/etsi_ts/101200_101299/101220/13.01.00_60/ts_101220v130100p.pdf\" target=\"blank_\">ETSI TS 101 220</a></td>\n\t\t\t\t\t</tr>\n\t\t\t\t\t<tr>\n\t\t\t\t\t\t<td/>\n\t\t\t\t\t\t<td class=\"tdc\"><a href=\"https://www.etsi.org/deliver/etsi_ts/102200_102299/102221/15.00.00_60/ts_102221v150000p.pdf\" target=\"blank_\">ETSI TS 102 221</a></td>\n\t\t\t\t\t</tr>\n\t\t\t\t\t<tr>\n\t\t\t\t\t\t<td/>\n\t\t\t\t\t\t<td class=\"tdc\"><a href=\"https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=1802\" target=\"blank_\">3GPP TS 31.101</a></td>\n\t\t\t\t\t</tr>\n\t\t\t\t\t<tr>\n\t\t\t\t\t\t<td/>\n\t\t\t\t\t\t<td class=\"tdc\"><a href=\"https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=1807\" target=\"blank_\">3GPP TS 31.111</a></td>\n\t\t\t\t\t</tr>\n\t\t\t\t\t<tr>\n\t\t\t\t\t\t<td/>\n\t\t\t\t\t\t<td class=\"tdc\"><a href=\"https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=1831\" target=\"blank_\">3GPP TR 31.900</a></td>\n\t\t\t\t\t</tr>\n\t\t\t\t</tbody>\n\t\t\t</table>\n\t\t</div>\n\t</div>"
}
[/block]


***

# Cas d’application de la puce SIM IoT industrielle

Les SIM embarquées réduisent l’empreinte de l’intégration de la SIM et offrent également une connexion plus robuste. De manière générale, le facteur de forme de la puce SIM IoT industrielle est mieux optimisé pour les environnements typiques des appareils IoT, où des facteurs tels que de fortes vibrations, des plages de température plus élevées mais aussi une sécurité accrue jouent un rôle clé. 1NCE recommande l’intégration de IoT SIMs Chip Industrial dans des appareils IoT développés sur mesure et des cas d’usage nécessitant une robustesse environnementale exceptionnelle.  
Étant montées en surface sur le PCB d’un appareil, les IoT SIMs Chip Industrial offrent une sécurité accrue contre les manipulations par l’utilisateur final, la carte SIM ne pouvant pas être retirée facilement. Pour le prototypage et la conception d’appareils IoT sur mesure, des adaptateurs QFN8 spécifiques sont disponibles pour adapter une IoT SIM Chip Industrial à l’empreinte de la IoT SIM Card Industrial.

Pour toute question ouverte concernant le produit 1NCE IoT SIM Chip Industrial ou pour une aide plus approfondie afin de choisir la bonne SIM IoT pour un cas d’application spécifique, n’hésitez pas à nous contacter (<a href="https://1nce.com/en-eu/support" target="_blank">1NCE Contact</a>).
