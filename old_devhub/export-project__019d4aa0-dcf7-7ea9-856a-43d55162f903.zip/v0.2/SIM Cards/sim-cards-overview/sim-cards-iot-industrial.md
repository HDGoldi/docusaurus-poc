---
title: "IoT SIM Card Industrial"
slug: "sim-cards-iot-industrial"
excerpt: "Basics about the Bell IoT SIM Cards Industrial."
hidden: false
metadata: 
  title: "Bell SIM Cards - IoT Industrial | Bell Developer Hub"
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:30:45 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Dec 01 2025 21:14:08 GMT+0000 (Coordinated Universal Time)"
---
Le facteur de forme de la carte SIM IoT industrielle est identique à celui de la carte SIM IoT Business avec le format plastique 3-en-1. Les principales différences résident dans la puce SIM, le logiciel et la robustesse environnementale de la carte SIM.  
Cette section couvrira les notions de base concernant le facteur de forme physique des cartes SIM IoT industrielles, les spécifications techniques ainsi que des recommandations pour les cas d’usage matériels IoT.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/c92c679c7074dd6af2cac56cb94dfbb07e88940b36fcf4fd8725cdac83a749ef-SIM-FR.png",
        null,
        "Vue d’ensemble des cartes SIM IoT industrielles 3-en-1 1NCE, incluant les facteurs de forme 2FF, 3FF et 4FF. "
      ],
      "align": "center",
      "sizing": "30% ",
      "caption": "Vue d’ensemble des cartes SIM IoT industrielles 3-en-1 Bell, incluant les facteurs de forme 2FF, 3FF et 4FF. "
    }
  ]
}
[/block]


***

# Facteur de forme des cartes SIM IoT industrielles

Au fil des années, avec la miniaturisation du matériel et en particulier les cas d’usage IoT pour les réseaux mobiles, le format physique des cartes SIM a été adapté à plusieurs reprises afin de réduire l’empreinte globale. Comme la conception et la disposition de la puce SIM IoT industrielle ont été conservées pour assurer la compatibilité ascendante, le format plastique environnant a été modifié. Il en résulte l’établissement de quatre facteurs de forme courants pour les cartes SIM IoT industrielles (1-4 FF). Les cartes SIM IoT industrielles pleine taille d’origine (1FF) avaient le facteur de forme typique d’une carte de crédit. Comme ce standard est aujourd’hui rarement utilisé, il a été abandonné en production. Les 2FF, 3FF et 4FF restants sont encore couramment utilisés et vendus en cartes 3-en-1 détachables, à dos plastique. Les quatre facteurs de forme des cartes SIM IoT industrielles sont spécifiés dans <a href="https://www.etsi.org/deliver/etsi_ts/102200_102299/102221/15.00.00_60/ts_102221v150000p.pdf" target="blank_">ETSI TS 102 221</a>. Les spécifications dimensionnelles exactes des facteurs de forme sont listées dans le tableau ci-dessous. 

|               | 2FF - Mini SIM | 3FF - Micro SIM | 4FF - Nano SIM           |
| :------------ | :------------- | :-------------- | :----------------------- |
| **Hauteur**   | 25mm           | 15mm            | 12.3mm ± 0.1 mm          |
| **Largeur**   | 15mm           | 12mm            | 8.8mm                    |
| **Épaisseur** | 0.76mm         | 0.76mm          | 0.67mm +0.03 mm/-0.07 mm |

Les cartes SIM IoT industrielles Bell sont des SIM 3-en-1 à dos plastique qui intègrent les facteurs de forme standardisés 2FF Mini, 3FF Micro et 4FF Nano. Les cartes SIM IoT industrielles Bell sont expédiées sur un support demi-format pour faciliter la manipulation et l’expédition des SIM détachables. Selon les besoins du client, les cartes SIM IoT industrielles peuvent être soigneusement détachées au facteur de forme requis et également réassemblées jusqu’au 2FF Mini à l’aide des adaptateurs fournis.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/20aeb83-1NCE_4FF_SIM_Dimensions.png",
        "1NCE_4FF_SIM_Dimensions.png",
        1064
      ],
      "align": "center",
      "sizing": "smart",
      "caption": "Dimensions de référence et affectation des broches (pinout) des cartes SIM IoT industrielles Bell 4FF selon ETSI TS 102 221."
    }
  ]
}
[/block]


Comme le 4FF est le plus petit facteur de forme qui réduit la carte SIM à dos plastique à la simple puce, nous l’utiliserons comme référence pour le brochage. Le brochage est identique pour toutes les cartes SIM IoT industrielles puisque le circuit intégré (IC) de la SIM est identique. Ci-dessus est montré le brochage de référence et les dimensions de la SIM 4FF conformément à <a href="https://www.etsi.org/deliver/etsi_ts/102200_102299/102221/15.00.00_60/ts_102221v150000p.pdf" target="blank_">ETSI TS 102 221</a>. Bien que les cartes SIM IoT Bell 4FF et le facteur de forme eSIM MFF2 soient différents, le brochage des circuits intégrés est le même. Le tableau de brochage se réfère au brochage de la figure de référence dimensionnelle pour les cartes SIM IoT industrielles 4FF.

[block:parameters]
{
  "data": {
    "h-0": "Broche de contact",
    "h-1": "Description spéc.",
    "h-2": "Brochage des cartes SIM IoT industrielles Bell",
    "0-0": "C1",
    "0-1": "**VCC**  \nTension d'alimentation",
    "0-2": "VCC",
    "1-0": "C2",
    "1-1": "**RST**  \nBroche de réinitialisation",
    "1-2": "RST",
    "2-0": "C3",
    "2-1": "**CLK**  \nSignal d’horloge",
    "2-2": "CLK",
    "3-0": "C4 et C8",
    "3-1": "**Optionnel**  \nInterface USB conformément à ETSI TS 102 600",
    "3-2": "N/A",
    "4-0": "C5",
    "4-1": "**GND**  \nConnexion à la masse",
    "4-2": "GND",
    "5-0": "C6",
    "5-1": "**VPP**  \nTension de programmation",
    "5-2": "N/A",
    "6-0": "C7",
    "6-1": "**I/O**  \nDonnées d’entrée/sortie",
    "6-2": "I/O"
  },
  "cols": 3,
  "rows": 7,
  "align": [
    "left",
    "left",
    "left"
  ]
}
[/block]


***

# Expédition et emballage

Les cartes SIM IoT industrielles Bell 3-en-1 sont conditionnées sur une carte détachable demi-format pour réduire le gaspillage de plastique. Cela facilite la manipulation et l’expédition des différents facteurs de forme SIM. Chacune de ces cartes détachables, illustrées ci-dessous, contient une SIM 3-en-1. Pour une identification plus simple, un code-barres ainsi que la représentation numérique du code EAN et de l’ICCID sont imprimés au dos des cartes. Pour les petites quantités de commandes de cartes SIM IoT industrielles, les cartes seront conditionnées et expédiées dans de petits paquets sous film plastique. Les commandes plus importantes seront expédiées en boîtes de 100 ou 500 SIM respectivement. Ces boîtes sont conditionnées dans l’ordre, de l’ICCID le plus bas au plus élevé, avec une étiquette indiquant le premier et le dernier ICCID de la boîte.

***

# Identification eID des cartes SIM IoT industrielles

Un eID est un identifiant unique mondial à 32 chiffres, contenant des informations permettant d’identifier de manière unique la carte SIM physique. Grâce à la fonctionnalité eUICC, l’eID est le numéro le plus important pour identifier la SIM, car l’ICCID peut changer en fonction du profil actif. L’eID est unique à la carte SIM IoT et reste toujours identique.

L’eID peut être lu par le modem matériel à l’aide d’une commande AT ou d’une requête spécifique au fabricant. Pour une identification physique plus simple, chaque carte SIM IoT industrielle Bell a l’eID de la SIM en question imprimé sur la carte puce physique 4FF.

Pour plus d’informations sur l’eID, veuillez vous référer à la [documentation officielle de la GSMA](https://www.gsma.com/esim/resources/sgp-29-v1-0-eid-definition-and-assignment-process/)

***

# Spécifications des cartes SIM IoT industrielles

Les cartes SIM destinées aux applications de réseaux mobiles suivent des normes strictes pour le facteur de forme physique ainsi que pour la technologie et les interfaces. Les cartes SIM IoT industrielles Bell sont conformes à ces spécifications techniques standard. Outre les principales conformités aux normes, les cartes SIM sont validées pour des plages environnementales spécifiques dans lesquelles elles doivent fonctionner. Le tableau ci-dessous présente les spécifications les plus importantes des cartes SIM IoT industrielles Bell, pertinentes pour le déploiement des cartes SIM IoT industrielles Bell. En outre, des références aux principales conformités aux normes pour les interfaces SIM sont listées.

[block:html]
{
  "html": "<div class=\\\"rdmd-table\\\">\\n\\t<div class=\\\"rdmd-table-inner\\\">\\n\\t<style type=\\\"text/css\\\">.tdc { text-align:center;}</style>\\n\\t\\t<table>\\n\\t\\t\\t<thead>\\n\\t\\t\\t\\t<tr>\\n\\t\\t\\t\\t\\t<th>Paramètre</th>\\n\\t\\t\\t\\t\\t<th>Carte SIM IoT industrielle 1NCE (3-en-1)</th>\\n\\t\\t\\t\\t</tr>\\n\\t\\t\\t</thead>\\n\\t\\t\\t<tbody>\\n\\t\\t\\t\\t<tr>\\n\\t\\t\\t\\t\\t<td>Facteurs de forme (FF)</td>\\n\\t\\t\\t\\t\\t<td class=\\\"tdc\\\">2FF - Mini, 3FF - Micro, 4FF - Nano</td>\\n\\t\\t\\t\\t</tr>\\n\\t\\t\\t\\t<tr>\\n\\t\\t\\t\\t\\t<td>Technologies d'accès radio (RAT) prises en charge</td>\\n\\t\\t\\t\\t\\t<td class=\\\"tdc\\\">2G, 3G, 4G, CAT-M1, NB-IoT</td>\\n\\t\\t\\t\\t</tr>\\n\\t\\t\\t\\t<tr>\\n\\t\\t\\t\\t\\t<td>Température environnementale</td>\\n\\t\\t\\t\\t\\t<td class=\\\"tdc\\\">-40°C to +105°C</td>\\n\\t\\t\\t\\t</tr>\\n\\t\\t\\t\\t<tr>\\n\\t\\t\\t\\t\\t<td>Tensions de fonctionnement</td>\\n\\t\\t\\t\\t\\t<td class=\\\"tdc\\\">Classes A, B et C (1.62V – 5.5V)</td>\\n\\t\\t\\t\\t</tr>\\n\\t\\t\\t\\t<tr>\\n\\t\\t\\t\\t\\t<td>Période de rétention des données</td>\\n\\t\\t\\t\\t\\t<td class=\\\"tdc\\\">min. 10 ans</td>\\n\\t\\t\\t\\t</tr>\\n        <tr>\\n\\t\\t\\t\\t\\t<td>Nombre de profils</td>\\n\\t\\t\\t\\t\\t<td class=\\\"tdc\\\">max. 10 </td>\\n\\t\\t\\t\\t</tr>\\n\\t\\t\\t\\t<tr>\\n\\t\\t\\t\\t\\t<td>Cycles de lecture/écriture</td>\\n\\t\\t\\t\\t\\t<td class=\\\"tdc\\\">min. 2.000.000 cycles</td>\\n\\t\\t\\t\\t\\t<tr>\\n\\t\\t\\t\\t\\t\\t<td>Conformités aux normes clés</td>\\n\\t\\t\\t\\t\\t\\t<td class=\\\"tdc\\\"><a href=\\\"https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=1833\\\" target=\\\"blank_\\\">3GPP TR 31.919</a></td>\\n\\t\\t\\t\\t\\t</tr>\\n\\t\\t\\t\\t\\t<tr>\\n\\t\\t\\t\\t\\t\\t<td/>\\n\\t\\t\\t\\t\\t\\t<td class=\\\"tdc\\\"><a href=\\\"https://www.etsi.org/deliver/etsi_ts/101200_101299/101220/13.01.00_60/ts_101220v130100p.pdf\\\" target=\\\"blank_\\\">ETSI TS 101 220</a></td>\\n\\t\\t\\t\\t\\t</tr>\\n\\t\\t\\t\\t\\t<tr>\\n\\t\\t\\t\\t\\t\\t<td/>\\n\\t\\t\\t\\t\\t\\t<td class=\\\"tdc\\\"><a href=\\\"https://www.etsi.org/deliver/etsi_ts/102200_102299/102221/15.00.00_60/ts_102221v150000p.pdf\\\" target=\\\"blank_\\\">ETSI TS 102 221</a></td>\\n\\t\\t\\t\\t\\t</tr>\\n\\t\\t\\t\\t\\t<tr>\\n\\t\\t\\t\\t\\t\\t<td/>\\n\\t\\t\\t\\t\\t\\t<td class=\\\"tdc\\\"><a href=\\\"https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=1802\\\" target=\\\"blank_\\\">3GPP TS 31.101</a></td>\\n\\t\\t\\t\\t\\t</tr>\\n\\t\\t\\t\\t\\t<tr>\\n\\t\\t\\t\\t\\t\\t<td/>\\n\\t\\t\\t\\t\\t\\t<td class=\\\"tdc\\\"><a href=\\\"https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=1807\\\" target=\\\"blank_\\\">3GPP TS 31.111</a></td>\\n\\t\\t\\t\\t\\t</tr>\\n\\t\\t\\t\\t\\t<tr>\\n\\t\\t\\t\\t\\t\\t<td/>\\n\\t\\t\\t\\t\\t\\t<td class=\\\"tdc\\\"><a href=\\\"https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=1831\\\" target=\\\"blank_\\\">3GPP TR 31.900</a></td>\\n\\t\\t\\t\\t\\t</tr>\\n\\t\\t\\t\\t</tbody>\\n\\t\\t\\t</table>\\n\\t\\t</div>\\n\\t</div>"
}
[/block]


***

# Cas d’usage des cartes SIM IoT industrielles

Comme la carte SIM IoT industrielle à dos plastique est actuellement encore le facteur de forme le plus couramment utilisé dans le domaine des communications mobiles, elle convient parfaitement comme SIM polyvalente pour la plupart des appareils IoT prêts à l’emploi. Le facteur de forme 3-en-1 des cartes SIM IoT industrielles Bell est compatible avec un large éventail d’appareils qui acceptent ce facteur de forme standardisé. Ce facteur de forme de SIM est facile à installer, à échanger, interchangeable entre appareils et prêt pour l’environnement de production IoT. Ces caractéristiques clés rendent les cartes SIM IoT industrielles Bell idéales pour chaque étape du cycle de vie des appareils IoT, depuis le prototypage flexible initial jusqu’au déploiement de milliers d’appareils sur le terrain. En outre, les cartes SIM IoT industrielles Bell sont idéales pour des environnements plus exigeants grâce à leurs caractéristiques physiques renforcées, par exemple la température de fonctionnement.

Pour toute question ouverte concernant le produit détaillé de cartes SIM IoT industrielles 1NCE ou pour une aide plus complète dans la sélection de la bonne SIM IoT pour le cas d’application spécifique, n’hésitez pas à nous contacter (<a href="https://1nce.com/en-eu/support" target="_blank">Contact 1NCE</a>).
