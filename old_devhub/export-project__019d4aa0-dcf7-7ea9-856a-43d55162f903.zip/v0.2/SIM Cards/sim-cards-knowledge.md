---
title: "SIM Knowledge"
slug: "sim-cards-knowledge"
excerpt: "The foundations about IoT SIM Cards."
hidden: false
createdAt: "Mon Aug 05 2024 14:30:48 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Nov 10 2025 13:52:18 GMT+0000 (Coordinated Universal Time)"
---
Beaucoup associent le terme carte SIM à un petit morceau de plastique comportant une puce intégrée. Une puce qui est insérée dans un téléphone mobile ou un autre modem pour permettre à un appareil spécifique de se connecter à un réseau mobile afin d’accéder à Internet et à la messagerie. Comme souvent, les détails d’une carte SIM recèlent plus qu’il n’y paraît. D’un point de vue de base, un Subscriber Identity Module (SIM) est un circuit intégré (IC) doté d’un système d’exploitation de carte (COS) qui stocke des fonctions de sécurité utilisées pour authentifier les appareils abonnés dans un réseau mobile. 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0b742fa-sim.png",
        "Developer_Hub_SIM_Cards.png",
        854
      ],
      "align": "center",
      "sizing": "50% ",
      "caption": "Vue d’ensemble des différents formats de carte SIM IoT Bell."
    }
  ]
}
[/block]


Ces données incluent un numéro de série unique (ICCID), l’International Mobile Subscriber Identity (IMSI), des informations d’authentification de sécurité et de chiffrement pour authentifier la SIM comme abonné valide d’un réseau mobile. En outre, des informations locales temporaires du réseau, une liste des services d’accès, un code PIN (Personal Identification Number) et une clé de déblocage personnelle (PUK) sont stockées sur une SIM.  
Les sections suivantes couvrent les notions de base de certains paramètres SIM qui apparaissent dans le cadre des services Bell. Il est important de comprendre leur rôle dans l’écosystème Bell, car ces paramètres sont utiles pour l’information générale, l’identification des appareils, le dépannage et la sécurité.

***

# Personal Identification Number (PIN)

Toutes les cartes SIM Bell se voient attribuer un code PIN (Personal Identification Number) à 6 chiffres, désactivé par défaut. Les cartes SIM sont prêtes à l’emploi et aucune validation de PIN n’est donc nécessaire. Pour les appareils contrôlés par des commandes AT, il est recommandé d’utiliser la commande AT générale « AT+CPIN? » pour vérifier si la carte SIM Bell est prête à fonctionner. Cela teste si la carte SIM est prête au démarrage d’un modem avec une SIM Bell insérée. La commande AT doit renvoyer « READY », indiquant que la SIM est reconnue et prête à fonctionner.

***

# Integrated Circuit Card Identifier (ICCID)

Les cartes SIM sont principalement identifiées par leur ICCID (Integrated Circuit Card Identifier), un identifiant de la puce de la carte SIM elle-même. Les ICCID sont également utilisés pour identifier les profils eSIM (embedded SIM). Cet identifiant peut comporter jusqu’à 23 chiffres, dont un chiffre de contrôle calculé à l’aide de l’algorithme de Luhn. L’ICCID est conforme à la norme de numérotation <a target="_blank" href="https://www.itu.int/rec/T-REC-E.118/en">ITU E.118</a>.  
Notez qu’un chiffre supplémentaire est parfois renvoyé via des commandes AT, mais il ne fait pas officiellement partie de l’ICCID. L’ICCID est utilisé dans tout l’écosystème Bell (Portail Bell, API, Data Streamer, etc.) comme paramètre commun pour identifier chaque SIM fournie par Bell. Le tableau suivant présente les composants structurels de l’ICCID pour les SIM Bell.

<div class="rdmd-table">
	<div class="rdmd-table-inner">
		<table>
			<thead>
				<tr>
					<th colspan="2">Composant</th>
					<th>Longueur et exemple</th>
				</tr>
</thead>
<tbody>
				<tr>
					<td colspan="2"><b>ICCID</b><br>Identifiant de carte à circuit intégré</td>
					<td>16 - 23 chiffres:<br><i>89 88 280 666xxxxxxxx x</i><br><i>89 88 228 0666xxxxxxx x</i></td>
				</tr>
				<tr>
					<td colspan="2"><b>IIN</b><br>Numéro d’identification de l’émetteur</td>
					<td>4 - 9 chiffres:<br><i>89 88 228</i><br><i>89 88 280</i></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td><b>MII</b><br>Identifiant de catégorie d’industrie</td>
					<td>2 chiffres:<br><i>89</i> - Télécommunications</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td><b>CC</b><br>Code pays</td>
					<td>1 - 3 chiffres:<br><i>88</i> - Aucune géolocalisation (application IoT)</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td><b>II</b><br>Identifiant d’émetteur</td>
					<td>1 - 4 chiffres:<br><i>228</i> - Bell<br><i>280</i> - Bell</td>
				</tr>
				<tr>
					<td colspan="2"><b>SIM - ID</b><br>Numéro d’identification</td>
					<td>11 - 13 chiffres:<br><i>666xxxxxxxx</i><br><i>0666xxxxxxx</i></td>
				</tr>
				<tr>
					<td colspan="2"><b>C</b><br>Somme de contrôle</td>
					<td>1 chiffre:<br><i>x</i> - Algorithme de Luhn</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>

***

# International Mobile Subscriber Identity (IMSI)

L’International Mobile Subscriber Identity (IMSI) identifie de manière unique les cartes SIM par leur opérateur dans un réseau cellulaire. L’IMSI est stocké en tant que champ de 64 bits et est communiqué au réseau cellulaire connecté. Au cœur du réseau d’un opérateur mobile, l’IMSI est utilisé comme identifiant principal pour obtenir d’autres données spécifiques au client et à l’appareil. L’IMSI est utilisé dans tous les réseaux mobiles mondiaux. L’IMSI est conforme à la norme de numérotation <a target="_blank" href="https://www.itu.int/rec/T-REC-E.212/en">ITU E.212</a>.  
À ne pas confondre avec l’ICCID : l’ICCID est l’identifiant de la SIM physique, tandis que l’IMSI fait partie d’un profil placé sur la SIM. Pour le tarif Bell IoT Flat Rate China+, les clients disposent d’une carte SIM qui stocke un second profil IMSI, spécifiquement pour la région Chine. Dans l’écosystème Bell, l’IMSI se trouve souvent aux côtés de l’ICCID. Le tableau suivant présente les composants structurels de l’IMSI pour les SIM Bell.

<div class="rdmd-table">
	<div class="rdmd-table-inner">
		<table>
			<thead>
				<tr>
					<th colspan="2">Composant</th>
					<th>Longueur et exemple</th>
				</tr>
</thead>
<tbody>
				<tr>
					<td colspan="2"><b>IMSI</b><br>International Mobile Subscriber Identity</td>
					<td>13 - 15 chiffres:<br><i>901 40 51000xxxxx</i></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td><b>MCC</b><br>Code pays mobile</td>
					<td>3 chiffres:<br><i>901</i> - Code pays mobile partagé mondialement<br><i>454</i> - Hong Kong</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td><b>MNC</b><br>Code réseau mobile</td>
					<td>2 - 3 chiffres:<br><i>40</i> - MNC Bell<br><i>31</i> - China Telecom Global Limited</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td><b>MSISN</b><br>Mobile Subscriber ISDN Number</td>
					<td>8 - 9 chiffres:<br><i>51000xxxxx</i> - Mobile Subscriber ISDN Number</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>

## MCC et MNC

Le Mobile Country Code (MCC) et le Mobile Network Code (MNC) identifient un pays de domiciliation et un opérateur de ce réseau dans ce pays. Ensemble, ils donnent le code du réseau mobile terrestre public (PLMN) de l’abonné mobile. Étant donné que les cartes SIM Bell ne sont pas liées à un pays ou à un réseau réel, ces valeurs sont définies comme suit : MCC-901 et MNC-40.  
Le MCC-901 a une signification particulière, à savoir qu’il s’agit d’un code pays mobile partagé, utilisé dans le monde entier au lieu d’identifier un pays spécifique. Ainsi, Bell, en tant que MNO IoT, a réservé le PLMN 901-40 pour ses besoins et l’utilise pour le produit standard Bell.

## Multi-IMSI

Le tarif Bell IoT Flat Rate China+ offre, en plus de la couverture normale, une couverture supplémentaire en Chine (continentale), à Hong Kong, Macao et Taïwan. Multi-IMSI signifie que les clients disposent d’une carte SIM qui stocke un second IMSI commençant par le PLMN 454-31. Le client n’a pas besoin d’apporter de changements manuels à la carte SIM pour utiliser cet IMSI. Contrairement à la SIM standard Bell, la carte China+ appartient à un pays et à un opérateur : China Telecom Global Limited/Hong Kong.

***

# Mobile Station International Subscriber Directory Number (MSISDN)

Le Mobile Station International Subscriber Directory Number (MSISDN) est utilisé conjointement avec l’IMSI pour identifier de manière unique un abonnement SIM dans le réseau mobile mondial. Un opérateur classique non IoT utilise le MSISDN pour acheminer les appels vocaux vers une SIM abonnée. Alors que l’IMSI d’un profil spécifique sur une SIM ne change pas dans le temps, le MSISDN peut changer. Le format MSISDN est défini dans la norme <a target="_blank" href="https://www.itu.int/rec/T-REC-E.164/en">ITU-T E.164</a>. Dans l’écosystème Bell, le MSISDN se trouve dans les propriétés détaillées d’une SIM via l’API ou le service Data Streamer. Comparé à l’ICCID, l’IMSI ou l’IMEI, le MSISDN joue un rôle moins important pour les cas d’usage IoT de Bell.

***

# International Mobile Equipment Identity (IMEI)

Certains paramètres signalés dans l’écosystème Bell ne proviennent pas de la carte SIM Bell mais se rapportent plutôt à l’appareil spécifique utilisé avec la carte SIM. C’est le cas de l’International Mobile Equipment Identity (IMEI). Il s’agit d’un numéro unique permettant d’identifier le modem de l’appareil mobile utilisant une SIM. Chaque modem standardisé qui utilise un type de SIM pour se connecter à un opérateur de réseau mobile possède un IMEI unique.  
L’IMEI, 15 chiffres : 14 + chiffre de contrôle, ou l’IMEISV, 16 chiffres : 14 + deux (version logicielle), contient des informations sur l’origine, le modèle et le numéro de série de l’appareil. La structure de l’IMEI/SV est spécifiée dans le document <a target="_blank" href="https://www.etsi.org/deliver/etsi_ts/123000_123099/123003/16.06.00_60/ts_123003v160600p.pdf">3GPP TS 23.003</a>. Dans l’écosystème Bell, l’IMEI/SV est utilisé pour identifier les appareils et les fabricants individuellement. Dans Bell Data Streamer et l’API, l’IMEI/SV de certains opérateurs en itinérance peut comporter un « f » supplémentaire à la fin de l’IMEI.

<div class="rdmd-table">
	<div class="rdmd-table-inner">
		<table>
			<thead>
				<tr>
					<th colspan="2">Composant</th>
					<th>Longueur et exemple</th>
				</tr>
</thead>
<tbody>
				<tr>
					<td colspan="2"><b>IMEI</b><br>Identité internationale d’équipement mobile</td>
					<td>15 - 16 chiffres:<br><i>86 995103 xxxxxx x</i> - IMEI<br><i>86 995103 xxxxxx xx</i> - IMEISV</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td><b>TAC</b><br>Code d’allocation de type</td>
					<td>8 chiffres:<br><i>86 995103</i> - Exemple de SIM 7000G</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td><b>SNR</b><br>Numéro de série</td>
					<td>6 chiffres:<br><i>xxxxxx</i> - Unique par appareil</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td><b>CD/SVN</b><br>Chiffre de contrôle ou version logicielle</td>
					<td>1 - 2 chiffres:<br><i>x</i> - Chiffre de contrôle<br><i>xx</i> - Numéro de version logicielle</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>

## IMEI Lock

Chaque appareil d’un réseau mobile possède un numéro IMEI qui identifie le matériel de manière unique lors de la connexion au réseau. Bell offre la fonctionnalité de verrouiller un appareil donné sur la carte SIM en utilisant l’IMEI. 

Si l’IMEI Lock est activé pendant une session de données PDP active, la session en cours sera interrompue et l’appareil sera forcé de se reconnecter immédiatement. Cela garantit que l’appareil actuellement utilisé est verrouillé à la SIM et qu’il n’est pas possible de changer la carte SIM vers un autre appareil après l’activation de la fonction IMEI Lock. 

Une fois l’option IMEI Lock activée, le réseau liera l’IMEI à la carte SIM spécifique. Les tentatives de connexion ultérieures avec cette carte SIM à l’aide d’un autre appareil ayant un IMEI différent sont bloquées. Cette fonctionnalité peut être désactivée et activée par le client pour chaque carte SIM individuellement, soit via le Portail Bell, soit via l’API Bell. Pour la fonctionnalité IMEI Lock, l’IMEISV est utilisé. L’IMEISV est dérivé de l’IMEI et inclut le paramètre supplémentaire de version logicielle.
