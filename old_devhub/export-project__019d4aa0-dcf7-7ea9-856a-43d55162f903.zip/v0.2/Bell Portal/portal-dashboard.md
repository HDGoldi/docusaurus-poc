---
title: "Dashboard"
slug: "portal-dashboard"
excerpt: "SIM Status Overview of the Bell Organization."
hidden: false
metadata: 
  title: "Bell Portal - Dashboard | Bell Developer Hub"
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:30:56 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Nov 10 2025 14:22:01 GMT+0000 (Coordinated Universal Time)"
---
Après vous être connecté au portail client Bell, un tableau de bord récapitulatif s'affiche. La page montre l'état actuel des SIM, l'utilisation du volume et un aperçu des commandes en cours de l'organisation.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/c24444d31b23009c4953099654918836bf54bb2e0e987f7dcfddb4b9ac6b1525-CleanShot_2025-11-10_at_16.20.55.png",
        "",
        "Aperçu du tableau de bord du portail client Bell."
      ],
      "align": "center",
      "caption": "Aperçu du tableau de bord du portail client Bell."
    }
  ]
}
[/block]


***

# Statut des SIM

La tuile "Statut des SIM" affiche le pourcentage actuel de cartes SIM Bell qui sont activées et désactivées. Les SIM peuvent être (dés)activées par le client pour désactiver/activer la connectivité spécifique à la SIM. Ce processus peut être effectué via le portail Bell ou l'API Bell.

***

# Volume de données et utilisation

Concernant le volume de données et l'utilisation, deux tuiles sont présentées dans le tableau de bord. Les détails concernant le quota et l'utilisation spécifiques à chaque SIM peuvent être consultés dans l'onglet "Mes cartes SIM".

La tuile "Volume de données" indique le nombre de SIM avec un volume suffisant (supérieur à 20 %), un volume faible (inférieur à 20 %) et aucun volume. Les cartes SIM avec un volume suffisant ou faible fonctionnent toujours comme prévu, mais il convient de surveiller celles dont le volume est faible. Les SIM avec le statut "Aucun volume" ont dépassé le volume acheté et ont été bloquées pour l'accès à la connexion de données. Ces SIM doivent être rechargées pour obtenir de nouveaux crédits de volume de données. Elles peuvent encore se connecter au réseau et envoyer/recevoir des SMS si un volume SMS suffisant est présent.

L'utilisation globale des données de l'organisation est affichée dans le graphique "Utilisation des données". Ce graphique montre le volume hebdomadaire cumulé en mégaoctets utilisé au cours des huit dernières semaines. Pour des relevés d'utilisation plus détaillés, l'API Bell ou l'intégration Bell Data Streamer peut être utilisée.

***

# Volume SMS et utilisation

De la même manière que pour le volume de données et l'utilisation, deux tuiles pour le volume et l'utilisation des SMS sont présentées dans le tableau de bord. Les détails pour des SIM spécifiques sont accessibles via la page "Mes cartes SIM".

La tuile de volume SMS montre le nombre de SIM avec un volume suffisant (plus de 20 %), un volume faible (moins de 20 %) et aucun volume. Lorsqu'une SIM n'a plus de volume SMS, les services de données peuvent toujours être utilisés, mais aucun SMS supplémentaire ne peut être envoyé ni reçu. La SIM doit être rechargée pour obtenir de nouveaux crédits SMS.

L'utilisation des SMS est affichée dans un graphique, cumulée chaque semaine pour les huit dernières semaines. Pour des relevés d'utilisation plus détaillés, l'API Bell ou l'intégration Bell Data Streamer peut être utilisée.
