---
title: "My SIMs & SMS Console"
slug: "portal-sims-sms"
excerpt: "Management of the Bell SIMs"
hidden: false
metadata: 
  title: "Bell Portal - SIMs and SMS | Bell Developer Hub"
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:30:55 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Nov 10 2025 14:27:04 GMT+0000 (Coordinated Universal Time)"
---
L’onglet « Mes cartes SIM » offre une vue d’ensemble de toutes les SIM actuellement associées à l’organisation spécifiée. Cette page sert d’aperçu et permet de configurer toutes les fonctionnalités des SIM depuis le Portail Bell.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/856103c8d11cdf049d6347cf31ee24506e94bb649de4095839ae00c6037b7b25-CleanShot_2025-11-10_at_16.22.18.png",
        "",
        "Aperçu de la page Mes cartes SIM, affichant toutes les SIM de l’organisation."
      ],
      "align": "center",
      "caption": "Aperçu de la page Mes cartes SIM, affichant toutes les SIM de l’organisation."
    }
  ]
}
[/block]


***

# Aperçu des SIM

L’affichage de toutes les SIM peut être personnalisé en modifiant les options de filtre ou en utilisant la fonction de recherche pour filtrer selon des paramètres spécifiques. L’option de recherche permet de chercher une SIM donnée par IMSI, Label, ICCID ou MSISDN. La recherche partielle est également prise en charge. Des filtres globaux de base sur le volume de données et de SMS ainsi que sur l’état de la carte SIM peuvent être appliqués. Les valeurs des colonnes peuvent être triées par ordre croissant ou décroissant. Par défaut, le tableau est trié par ICCID.  
Le tableau peut être trié et filtré via les titres de colonnes. Lorsqu’une colonne est triée ou filtrée, une icône devient visible.  
En outre, les colonnes affichées peuvent être activées/désactivées pour ne conserver que celles d’intérêt en utilisant la fonctionnalité « Ajuster les colonnes ». Notez que pour un grand nombre de cartes SIM, la vue liste peut comporter plusieurs pages. Le nombre de SIM par page peut être défini manuellement et est limité à un maximum de 500. Ci‑dessous, une explication de toutes les colonnes disponibles à sélectionner :

## Statut

| Paramètre     | Description                                                                                                                       |
| :------------ | :-------------------------------------------------------------------------------------------------------------------------------- |
| `Activated`   | Coche verte, indiquant que l’ensemble des fonctionnalités de la SIM est activé et que la SIM peut se connecter aux services Bell. |
| `Deactivated` | Croix noire, indiquant que la SIM est désactivée. La SIM ne peut pas se connecter au réseau Bell.                                 |

## Session

| Paramètre  | Description                                                                                                                                                                                                                       |
| :--------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `Online`   | Voyant vert : la SIM a établi une session de données. Lorsqu’un appareil SIM ne ferme pas correctement la session de données PDP, ce statut persiste jusqu’à ce que l’appareil soit purgé du réseau.                              |
| `Offline`  | Voyant gris : l’appareil SIM n’est pas connecté au réseau Bell.                                                                                                                                                                   |
| `Attached` | Voyant orange : la SIM est attachée à un réseau mobile, mais n’a pas de session de données active. Lorsqu’une SIM n’est pas correctement détachée d’un réseau, ce statut persiste jusqu’à ce que l’appareil soit purgé du réseau. |

## Détails de la SIM

<Table align={["left","left"]}>
  <thead>
    <tr>
      <th>
        Paramètre
      </th>

```
  <th>
    Description
  </th>
</tr>
```

  </thead>

  <tbody>
    <tr>
      <td>
        `ICCID`
      </td>

```
  <td>
    Numéro de série unique de la carte SIM.
  </td>
</tr>

<tr>
  <td>
    `MSISDN`
  </td>

  <td>
    Numéro de téléphone de la carte SIM. La SIM ne peut pas être utilisée pour les services vocaux ni pour recevoir/envoyer des SMS à des parties externes. Les chapitres [Services SMS](https://help.1nce.com/dev-hub/docs/connectivity-services-sms-services) et [Service de redirection SMS](https://help.1nce.com/dev-hub/docs/platform-services-sms-forwarder) fournissent plus d’informations.
  </td>
</tr>

<tr>
  <td>
    `IMEI(SV)`
  </td>

  <td>
    Identifiant de l’appareil dans lequel la SIM est insérée. L’IMEI affiché dans le Portail Bell est récupéré depuis le réseau lors de l’activation du contexte PDP ; le format est le suivant : IMEI + SV (version logicielle), selon la spécification 3GPP TS23.003.  
    Voir la <a href="/dev-hub/docs/sim-cards-knowledge#international-mobile-equipment-identity-imei">Référence IMEI</a> pour plus d’informations.
  </td>
</tr>

<tr>
  <td>
    `IMEI Lock`
  </td>

  <td>
    Statut du verrouillage IMEI pour cette SIM spécifique. S’il est activé, la SIM est liée à l’appareil actuel.  
    Voir la <a href="/dev-hub/docs/sim-cards-knowledge#imei-lock">Référence du verrouillage IMEI</a> pour plus d’informations.
  </td>
</tr>

<tr>
  <td>
    `IP Address`
  </td>

  <td>
    Adresse IP statique de la SIM. Utilisée pour accéder à la SIM via les services VPN 1NCE.
  </td>
</tr>

<tr>
  <td>
    `SIM Type`
  </td>

  <td>
    Type spécifique de carte SIM, FlexSIM ou eSIM.
  </td>
</tr>

<tr>
  <td>
    `Tariff`
  </td>

  <td>
    Détails du tarif de la SIM indiquant le volume de données et de SMS.
  </td>
</tr>

<tr>
  <td>
    `Label`
  </td>

  <td>
    Texte d’étiquette défini par l’utilisateur pour cette carte SIM.
  </td>
</tr>

<tr>
  <td>
    `Data Usage`
  </td>

  <td>
    Indicateur coloré du quota de données restant. Vert > 20 % restants, Jaune \< 20 % disponibles, Rouge = 0 % restant.
  </td>
</tr>

<tr>
  <td>
    `SMS Usage`
  </td>

  <td>
    Indicateur coloré du quota de SMS restant. Vert > 20 % restants, Jaune \< 20 % disponibles, Rouge = 0 % restant.
  </td>
</tr>
```

  </tbody>
</Table>

## Export des SIM

Le tableau complet et personnalisé des cartes SIM peut être exporté au format CSV si nécessaire en utilisant le bouton « Exporter les SIM ». Comme l’export d’une liste volumineuse de SIM peut prendre du temps, l’utilisateur reçoit une notification par e‑mail dès que l’export est terminé et peut le télécharger depuis la section Export SIM située sous le tableau des cartes SIM. Cet export inclut également le PIN et le PUK de chaque SIM, qui peuvent être nécessaires pour certains appareils.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/351c8ad70c6f94beb05c400769a56e0d42637db48b4f929c4a6576a4f622e349-CleanShot_2025-11-10_at_16.23.23.png",
        "",
        "Section d’export SIM sous le tableau des SIM"
      ],
      "align": "center",
      "caption": "Section d’export SIM sous le tableau des SIM"
    }
  ]
}
[/block]


***

## Rechargement des SIM

Il est possible de réserver manuellement un volume supplémentaire de données et de SMS pour une ou plusieurs cartes SIM sélectionnées. À chaque rechargement, 500 Mo et 250 SMS sont ajoutés au volume restant. Les rechargements pour une carte SIM unique peuvent être commandés dans la vue détaillée de la carte. Davantage de volume peut être ajouté en commandant plusieurs rechargements à la suite. Le volume commandé est disponible dès réception du paiement :

| Méthode de paiement | Délai              |
| :------------------ | :----------------- |
| Virement bancaire   | Deux à trois jours |
| Carte de crédit     | Immédiatement      |

## Désactivation de la SIM

La SIM sélectionnée peut être désactivée afin d’empêcher un attachement au réseau Bell. Cette fonctionnalité est utile pour désactiver des SIM pendant l’expédition d’appareils ou pour forcer une réinitialisation de la connexion. Cette fonction peut également être utilisée via l’API Bell. Les attachements actifs des SIM seront purgés et les appareils immédiatement déconnectés.

Les tentatives ultérieures de l’appareil de se réenregistrer seront refusées par le réseau jusqu’à ce que la SIM soit réactivée.  
Selon la logique de l’appareil, ce blocage peut forcer certains appareils à passer en état d’erreur et les empêcher de se reconnecter à un réseau, même si la SIM a été réactivée. Il est recommandé d’implémenter un redémarrage logiciel ou matériel avec une temporisation de reprise progressive (**temporisation exponentielle**) dans la procédure de connectivité du firmware de l’appareil. Cette procédure devrait contourner le retard potentiel d’attachement après une réactivation de SIM lorsque l’appareil est resté bloqué en état d’erreur. Veuillez implémenter un algorithme de back‑off avec au moins 5 à 20 minutes entre les nouvelles tentatives pour ne pas surcharger le réseau avec des demandes d’attachement non désirées pendant les désactivations de SIM. Après la réactivation des SIM, le réseau permettra de nouveau à la SIM de s’attacher au réseau Bell et d’utiliser tous les services comme d’habitude.

## Verrouillage IMEI

Le verrouillage IMEI ne sera appliqué qu’aux SIM sélectionnées. Il fonctionne en enregistrant l’IMEI de l’appareil dans lequel la SIM est installée. Lorsque la fonctionnalité est activée, le réseau Bell n’acceptera que la combinaison IMEI d’appareil enregistrée – carte SIM pour accéder aux ressources du réseau. Toute autre combinaison IMEI – SIM sera refusée. Si cette fonctionnalité est activée, le verrouillage IMEI sera appliqué lors du prochain attachement au réseau. En conséquence, la carte SIM ne pourra être utilisée qu’avec l’appareil actuel. Pour modifier le réglage pour toutes les cartes SIM (futures), veuillez naviguer vers l’onglet [Configuration](https://help.1nce.com/dev-hub/docs/portal-configuration#global-imei-lock).

## Extension de la SIM

Si vos cartes SIM approchent de leur expiration, une colonne supplémentaire « Extendable » apparaît dans votre tableau de SIM. Trois mois avant la fin de votre période d’activation, vous serez averti par e‑mail et il sera visible dans votre tableau de SIM quelles cartes SIM peuvent être prolongées. Vous pouvez prolonger une carte SIM individuelle ou filtrer toutes les cartes SIM prolongeables. Après avoir sélectionné toutes les cartes SIM pertinentes, cliquez sur « Extend SIMs ». Vous pourrez revoir vos SIM sélectionnées et les détails du tarif pour la prolongation dans le panier. L’ensemble des données, SMS et temps restants seront transférés. La nouvelle période d’activation commence le jour de la commande (lorsqu’un virement bancaire est utilisé, elle commence dès que le paiement est reçu.

Après l’atteinte de votre date d’expiration, vous disposez de 18 mois pour prolonger vos cartes SIM. Les SIM ne seront pas utilisables durant cette période de transition, mais vous pourrez les prolonger à tout moment. Après 18 mois, les cartes SIM seront supprimées de manière irréversible.

***

# Page de détail de la SIM

En cliquant sur l’une des SIM de la liste, une vue détaillée du statut et de la configuration de la SIM s’affiche. La section supérieure de cette vue inclut des statistiques de base de la SIM sélectionnée. Dans la première colonne, l’ICCID, l’IMSI, le MSISDN et le LABEL sont affichés. Le champ LABEL est modifiable et peut aider à trier les SIM. La deuxième colonne présente toutes les données de durée de vie, comme le temps écoulé en %, le temps restant et la date de fin du contrat. La troisième colonne à droite affiche toutes les données réseau pertinentes, comme l’adresse IP statique, l’IMEI de l’appareil connecté, l’état de la session, l’emplacement de l’appareil, l’opérateur et le mode d’accès réseau auquel la SIM est actuellement attachée.

## Configuration de la SIM

Sur la page de détail de la SIM, la SIM spécifique peut être activée/désactivée, le verrouillage IMEI défini, l’Auto‑Top‑Up activé/désactivé et, en outre, la connexion de la SIM peut être réinitialisée.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/abc4561e1849d603ab7eda546742fbca0c6cd7eeb50c8e78259117879d590960-CleanShot_2025-11-10_at_16.25.01.png",
        "",
        "Page de détail d’un exemple de carte SIM."
      ],
      "align": "center",
      "caption": "Page de détail d’un exemple de carte SIM."
    }
  ]
}
[/block]


## Réinitialiser la connexion

En utilisant « Réinitialiser la connexion », la SIM est automatiquement désactivée puis réactivée. Cela forcera la SIM à se déconnecter de l’opérateur réseau actuel et à se rattacher. Cette fonctionnalité est utile si la SIM est bloquée sur une connexion indésirable.

Dans la section inférieure, des journaux détaillés des événements et de l’utilisation sont présentés dans l’ordre chronologique. Veuillez noter que ces données ne sont conservées que pendant sept jours conformément à la politique de conservation des données de Bell. Les données de l’onglet Événements sont identiques aux données disponibles dans le Bell Data Streamer. Ces événements sont très utiles pour déboguer les appareils et visualiser les événements réseau en cours d’un appareil.

L’onglet Utilisation affiche à la fois l’usage SMS et l’usage des données des huit dernières semaines, le quota disponible et le volume restant pour les SMS et les données de cette SIM particulière.

***

# Console SMS

L’onglet SMS de la page détaillée de la SIM peut être utilisé pour échanger des messages SMS avec l’appareil utilisant la SIM concernée. Avec les champs Source Address et Payload, un SMS peut être préparé et envoyé à l’appareil. Veuillez noter que l’appareil doit être attaché à un réseau pour pouvoir recevoir le message.

Dans la vue tableau sous le formulaire d’envoi de SMS, un aperçu des messages SMS Mobile Originated (MO) et Mobile Terminated (MT) des sept derniers jours est visible. Outre les messages eux‑mêmes, l’état actuel des MO/MT‑SMS, la charge utile (payload) et le type sont listés.  
La liste affiche le type de SMS (MT ou MO), l’état actuel (Pending, OK, Failed), l’horodatage de soumission du message et, enfin, l’adresse source et la charge utile. Veuillez noter que les MT‑SMS restent à l’état Pending jusqu’à ce que l’appareil se soit attaché au réseau et que le message ait été livré. Pour les MO‑SMS, l’état reste « pending » si aucun Service de redirection SMS n’est configuré, car seul ce service consomme les messages SMS et les accuse correctement réception. Si un message SMS échoue, c’est très probablement dû à l’expiration du délai de nouvelle tentative de livraison. Après un certain temps de tentative de livraison, le service placera le SMS à l’état failed.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0043f919f0181c84e5faa397f103b19f1c4233dbadbe66a8bc9e58e8bc30c265-CleanShot_2025-11-10_at_16.26.16.png",
        "",
        "Aperçu de la console SMS."
      ],
      "align": "center",
      "caption": "Aperçu de la console SMS."
    }
  ]
}
[/block]
