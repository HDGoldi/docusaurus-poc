---
title: "Configuration"
slug: "portal-configuration"
excerpt: "Bell Services Configuration and Setup"
hidden: false
metadata: 
  title: "Bell Portal - Configuration | Bell Developer Hub"
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:30:53 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Nov 10 2025 14:34:52 GMT+0000 (Coordinated Universal Time)"
---
# Paramètres réseau

Les paramètres réseau contiennent les informations de base permettant de connecter les cartes SIM au réseau Bell.

| Paramètre           |                                                                                                                                                                                                                                                                                                         |
| :------------------ | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `APN`               | Doit être défini dès la toute première étape pour établir une connexion au réseau.                                                                                                                                                                                                                      |
| `SMSC Number`       | Est généralement nécessaire pour diriger tous les SMS émis (MO) dans le réseau, bien que ce paramètre soit rarement requis lors d’une configuration manuelle.                                                                                                                                           |
| `Internet Breakout` | Affiche les adresses IP utilisées par toutes les SIM Bell pour accéder à l’internet public via un NAT. Consultez toutes les [adresses IP d’Internet Breakout disponibles](https://help.1nce.com/dev-hub/docs/network-services-internet-breakout)                                                        |
| `IP Address Space`  | Affiche les espaces d’adresses IP attribués aux SIM de l’organisation. Chaque SIM dispose d’une adresse IP statique qui peut être utilisée pour un accès direct via le service VPN. Des espaces IP supplémentaires seront attribués pour de nouvelles commandes si l’espace IP restant est insuffisant. |
| `IP Addresses`      | Indique la disponibilité des espaces d’adresses IP attribués à l’organisation.                                                                                                                                                                                                                          |

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/5604462911f298868fcf0670b125568dc9a3c96b2717ee37c7f0417fc4f7fa6a-CleanShot_2025-11-10_at_16.32.14.png",
        "",
        ""
      ],
      "align": "center"
    }
  ]
}
[/block]


***

<br />

# Limites mensuelles

Grâce à "Monthly Limits", un client peut définir une limite mensuelle individuelle de données et de SMS. La limite SMS peut être configurée séparément pour les SMS émis (MO) et reçus (MT). Ces limites s’appliquent à toutes les SIM du client. En cochant ou décochant les cases, ces options peuvent être activées ou annulées facilement à tout moment. Les limites s’appliquent à la période du mois calendaire. Définir une nouvelle limite au cours du même mois ne réinitialise pas le quota déjà consommé.  
Exemple : La première limite est de 100 Mo. Après l’avoir atteinte, vous définissez 200 Mo comme nouvelle limite. Seuls 100 Mo supplémentaires peuvent alors être consommés, car les 100 Mo déjà consommés sont pris en compte.

## Dépassement des limites

Lorsque les limites auto‑définies sont dépassées, des messages d’erreur ou d’avertissement sont déclenchés selon le type de limite.

### Session de données

Lorsque la limite est atteinte, les nouvelles sessions de données PDP seront rejetées : **PDP Context Request rejected, because endpoint is currently blocked due to exceeded traffic limit.** Cependant, certains appareils peuvent réessayer indéfiniment de se reconnecter dans ce cas. Bell recommande fortement d’utiliser une stratégie de back‑off dans ce cas de rejet afin de ne pas saturer le réseau avec des demandes de session PDP.

### MT-SMS

Avec l’API Bell, si la limite auto‑définie pour les MT‑SMS est atteinte, **Traffic limit of X SMS per month exceeded** est renvoyé comme erreur.  
Dans le portail Bell, **Set monthly limit of SMS exceeded** est affiché lorsque la limite MT‑SMS est atteinte et qu’un nouveau SMS est émis.

### MO-SMS

Pour les **MO‑SMS**, aucune notification n’apparaît dans le portail Bell ni dans le flux de données. Le SMS sera rejeté par le réseau, ce qui entraînera un code d’erreur renvoyé par le modem de l’appareil.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/f2c6c9d6cc8d548a9169948ca85f3a1df7b55031b653d72da65dfaa262a443f9-CleanShot_2025-11-10_at_16.31.48.png",
        "",
        "Configuration des limites mensuelles pour les données et les MO-/MT‑SMS."
      ],
      "align": "center",
      "caption": "Configuration des limites mensuelles pour les données et les MO-/MT‑SMS."
    }
  ]
}
[/block]


***

# Verrouillage IMEI global

Un verrouillage IMEI global peut être défini pour toutes les cartes SIM de l’organisation. Le verrouillage IMEI fonctionne en enregistrant l’IMEI de l’appareil dans lequel la SIM est installée. Lorsque la fonctionnalité est activée, le réseau Bell n’accepte que la combinaison IMEI de l’appareil – carte SIM enregistrée pour accéder aux ressources du réseau. Toute autre combinaison IMEI – SIM sera refusée. Si cette fonctionnalité est activée, le verrouillage IMEI sera défini lors du prochain attachement au réseau. La carte SIM ne pourra donc être utilisée qu’avec l’appareil actuel. Pour les nouvelles commandes de cartes SIM, une case à cocher permet d’activer le verrouillage IMEI par défaut. Ainsi, les SIM nouvellement commandées auront le verrouillage IMEI activé automatiquement. Un verrouillage IMEI séparé pour des cartes individuelles de l’organisation peut être défini soit via l’API Bell, soit dans l’onglet "My SIMs".

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/d84921f788e511c6c5511383e297aaa4795c76833af6213da51ff196412bfcb2-CleanShot_2025-11-10_at_16.31.40.png",
        "",
        "Paramètres du verrouillage IMEI global des SIM."
      ],
      "align": "center",
      "caption": "Paramètres du verrouillage IMEI global des SIM."
    }
  ]
}
[/block]


***

# Flux de données

Le service de diffusion de données de Bell permet aux clients de s’abonner à des événements en temps réel et à des données d’usage pour toutes les cartes SIM, en envoyant les données directement vers le serveur du client ou vers un service cloud déjà intégré tel qu’AWS Kinesis.

La configuration des Flux de données affiche la liste de tous les flux actuellement configurés, notamment le nom, le type d’API, le type de flux, l’URL, l’indicateur d’état et les commandes pour chaque flux. Chaque flux peut être contrôlé individuellement. Outre les actions de base arrêter, démarrer et supprimer, l’intégration d’un flux peut être redémarrée. Un redémarrage doit être effectué si le flux passe en état d’erreur et doit être restauré.

Pour créer une nouvelle intégration de flux de données, cliquez sur le bouton New Data Stream. Vous trouverez plus de détails sur la configuration d’une intégration de flux dans la section [Guides de configuration du Data Streamer](doc:streamer-setup) du Developer Hub.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/7f051788d6241633d53bf27d58c9b3ab60d4925c73240d3b32bc15fbd21e3529-CleanShot_2025-11-10_at_16.31.57.png",
        "",
        "Vue d’ensemble des intégrations Data Streamer actuelles."
      ],
      "align": "center",
      "caption": "Vue d’ensemble des intégrations Data Streamer actuelles."
    }
  ]
}
[/block]


***

# Configuration OpenVPN

OpenVPN est la solution recommandée par Bell pour établir une connexion de données sécurisée et bidirectionnelle entre le réseau Bell et le serveur du client.

Lors de la première utilisation d’OpenVPN, l’inscription au service doit être lancée sur le compte.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/674fd9f8fa211c5589e0e5d3cd8e6bacc619a4f6b6304d4cf332e5ee87104a42-CleanShot_2025-11-10_at_16.31.28.png",
        "",
        "Configuration spécifique pour le breakout en mode manuel (Europe)."
      ],
      "align": "center",
      "caption": "Configuration spécifique pour le breakout en mode manuel (Europe)."
    }
  ]
}
[/block]


Le client OpenVPN doit être installé sur le serveur du client auquel les SIM doivent accéder via l’adresse IP du client VPN. Pour la connexion OpenVPN au réseau Bell, un fichier de configuration et un fichier d’identifiants sont nécessaires. Ces fichiers peuvent être téléchargés dans cette section du portail client Bell. Deux versions sont disponibles : pour Windows et pour Linux/MacOS. Pour plus de détails sur le service VPN, sa configuration et son fonctionnement, les utilisateurs peuvent consulter la section [Service VPN](doc:network-services-vpn-service) du Developer Hub.
