---
title: "Account"
slug: "portal-accounts-orders"
excerpt: "Account Management"
hidden: false
metadata: 
  title: "Bell Portal - Accounts and Orders | Bell Developer Hub"
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:30:57 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Nov 10 2025 14:30:36 GMT+0000 (Coordinated Universal Time)"
---
# Compte

L’onglet "Account" permet au client d’afficher et de modifier ses données personnelles/entreprise, les adresses de facturation et de livraison, ainsi que de gérer le paiement Auto-Top-Up.

> ❗️ Champs de données non modifiables
> 
> Pour des raisons légales, nous ne pouvons pas autoriser la modification du nom de l’entreprise ni du pays de facturation de l’adresse de facturation. Pour obtenir de l’aide, veuillez contacter notre support.

Dans la liste déroulante Données client et utilisateur, les informations de contact et les détails du compte pour l’organisation racine ainsi que pour l’utilisateur connecté peuvent être consultés et modifiés. Notez que l’adresse e‑mail affichée dans la colonne Données client est le contact principal auquel toutes les factures sont envoyées sous forme numérique. Une adresse e‑mail supplémentaire peut être enregistrée pour recevoir les factures en copie, par exemple le service comptabilité. Pour cela, veuillez sélectionner la catégorie "Invoice".  
En outre, la catégorie "Volume Notifications" peut être sélectionnée. Elle inclut tous les e‑mails relatifs aux notifications de volume pour les données/SMS ainsi que l’atteinte de la limite de volume mensuelle définie.  
La sélection de la langue définit la langue de contact, à savoir les e‑mails, les factures et les notifications de service.

Dans la colonne Données utilisateur, les informations relatives à l’utilisateur actuellement connecté peuvent être consultées et modifiées. L’utilisateur connecté (quelle que soit sa fonction) peut modifier ses informations personnelles telles que le nom, l’adresse e‑mail ainsi que le mot de passe. Ces informations peuvent également être modifiées par un Admin ou un Propriétaire via l’onglet "Users", à l’exception du mot de passe pour les rôles Owner, Admin et User.

La liste déroulante Adresses de facturation et de livraison affiche toutes les adresses de facturation et de livraison enregistrées. Les entrées existantes peuvent être modifiées et de nouvelles adresses peuvent être ajoutées par le client pour de futures commandes. Les adresses sont conservées et apparaîtront chaque fois que l’utilisateur commandera des cartes SIM supplémentaires ou des rechargements.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/117d1f5b1d597d89c4adc4ed3fc2c4f7f6076fd17e186ac32c2e7b96d7035dd3-CleanShot_2025-11-10_at_16.28.12.png",
        "",
        ""
      ],
      "align": "center"
    }
  ]
}
[/block]


***

# Commandes

Dans l’onglet "Orders", toutes les commandes du compte Bell de l’organisation sont répertoriées. Le tableau offre un aperçu des paramètres importants de commande ainsi que de l’état actuel d’une commande. L’indicateur d’état (terminée, en préparation ou annulée) peut être utilisé pour suivre les commandes en attente.  
Sur cette page, les factures précédentes de commandes spécifiques peuvent être téléchargées. De plus, une liste CSV de toutes les SIM d’une commande particulière peut être téléchargée via le lien dans la colonne "Affected SIMs". Cette liste pour une commande dédiée se compose de l’ICCID, du libellé, de l’IMSI et du MSISDN des SIM. En cas de correction de la commande, les factures corrigées ou mises à jour peuvent être téléchargées dans la colonne "Additional Documents".

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/f24fcc8363c7925db94fa18061ac94a124eb2da3e144c9c72c77e8c02698a9f3-CleanShot_2025-11-10_at_16.29.11.png",
        "",
        ""
      ],
      "align": "center"
    }
  ]
}
[/block]


# Accès à l’API de gestion

Nous proposons des API RESTful pour une gestion fluide des appareils. Pour y accéder, générez des identifiants API dans la section ci-dessous. La communication avec l’API s’effectue via des requêtes HTTP(S) avec un corps JSON de type de contenu "application/json" et une autorisation de type oauth2 (OAuth2, application) requise pour chaque appel d’API.
