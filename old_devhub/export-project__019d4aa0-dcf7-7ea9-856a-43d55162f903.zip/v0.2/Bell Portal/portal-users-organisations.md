---
title: "Users"
slug: "portal-users-organisations"
excerpt: "Managing Users."
hidden: false
metadata: 
  title: "Bell Portal - Users and Organisation | Bell Developer Hub"
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:30:58 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Nov 10 2025 13:48:40 GMT+0000 (Coordinated Universal Time)"
---
# Gestion des utilisateurs

Le portail client Bell offre la possibilité de créer plusieurs comptes utilisateur, ce qui permet de définir différents rôles et droits d’accès. Dans l’onglet "User", le propriétaire principal (root) du compte peut créer et modifier de nouveaux comptes utilisateur. Une vue d’ensemble de tous les utilisateurs actuels de l’organisation Bell est fournie sous forme de liste.

<Image align="center" alt={1255} border={false} caption="Vue en liste de tous les comptes utilisateurs actifs actuels de l’organisation." title="1NCE_User_List.PNG" src="https://files.readme.io/a0afaf01e6360e71b0042c05b6eef736863c01482f7ebff05b2bf74e29994ea9-CleanShot_2025-09-26_at_13.13.532x.png" width="80%" />

## Rôles utilisateur

Les rôles suivants sont disponibles pour les comptes utilisateurs supplémentaires :

| Rôle           | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| :------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Propriétaire   | Utilisateur initial de l’organisation qui ne peut pas être modifié. Inclut toutes les fonctionnalités et l’accès à l’ensemble de l’organisation. De nouveaux utilisateurs peuvent également se voir attribuer le rôle Propriétaire. Le propriétaire a aussi accès à l’API de gestion. Peut administrer les utilisateurs avec les rôles Admin, Utilisateur, Utilisateur API, Lecture seule. _Pour administrer le rôle Propriétaire, veuillez soumettre une demande de service._ |
| Administrateur | Inclut toutes les fonctionnalités et l’accès à l’ensemble de l’organisation. Peut administrer les utilisateurs avec les rôles Utilisateur, Utilisateur API, Lecture seule et Accès tiers. Ce rôle n’a pas accès à l’API de gestion.                                                                                                                                                                                                                                            |
| Utilisateur    | Peut gérer les cartes SIM dans le portail, mais n’a pas accès aux commandes ni aux recharges, et ne peut pas passer de nouvelles commandes ni gérer des utilisateurs. Ce rôle n’a pas accès à l’API de gestion.                                                                                                                                                                                                                                                                |
| Lecture seule  | Rôle conçu pour offrir un accès en lecture seule au portail. Ce rôle n’a pas accès à l’API de gestion.                                                                                                                                                                                                                                                                                                                                                                         |

### Détails des rôles utilisateur

Voir le tableau suivant pour un aperçu précis des rôles et des autorisations pour chaque composant du portail Bell.

<HTMLBlock>{\`

<style type="text/css">
.tg  {border-collapse:collapse;border-spacing:0;}
.tg td{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:14px;
  overflow:hidden;padding:10px 5px;word-break:normal;}
.tg th{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:14px;
  font-weight:normal;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg .tg-cly1{text-align:left;vertical-align:middle}
.tg .tg-0lax{text-align:left;vertical-align:top}
</style>

<table class="tg">
<thead>
  <tr>
    <th class="tg-0lax" colspan="2">Zones du portail</th>
    <th class="tg-0lax">Propriétaire</th>
    <th class="tg-0lax">Admin</th>
    <th class="tg-0lax">Utilisateur</th>
    <th class="tg-0lax">Lecture seule</th>
    <th class="tg-0lax">Accès tiers</th>
    <th class="tg-0lax">Utilisateur API</th>
  </tr>
</thead>
<tbody>
  <tr>
    <td class="tg-cly1" rowspan="3">Tableau de bord</td>
    <td class="tg-0lax">Voir tout</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax" rowspan="42"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Bouton Commander à nouveau</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Widget Dernière commande</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-cly1" rowspan="8">Mes SIM</td>
    <td class="tg-0lax">Voir tout</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">État de la SIM</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Verrouillage IMEI</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Recharge automatique</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Réinitialiser la connectivité</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Exporter la liste des SIM</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Nouvelle commande / Recharge</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Envoyer un SMS</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-cly1" rowspan="9">Configuration</td>
    <td class="tg-0lax">Paramètres réseau</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Paramètres Breakout</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Limite mensuelle</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Verrouillage IMEI</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Recharge automatique</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Flux de données</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Redirection SMS</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">OpenVPN</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">API de gestion</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">1NCE OS</td>
    <td class="tg-0lax">Onglet disponible</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-cly1" rowspan="6">Compte</td>
    <td class="tg-0lax">Voir tout</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Données client</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Données utilisateur</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Ajouter un nouvel e-mail</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Adresse de facturation et de livraison</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Informations de paiement</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-cly1" rowspan="4">Commandes</td>
    <td class="tg-0lax">Voir tout</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Télécharger les factures</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Passer une nouvelle commande</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Télécharger les SIM concernées</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-cly1" rowspan="5">Utilisateurs</td>
    <td class="tg-0lax">Voir tout</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">Gérer son propre compte utilisateur</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">Gérer le propriétaire</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">Gérer l’administrateur</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">Gérer l’utilisateur</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">Gérer l’utilisateur API</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">Gérer l’utilisateur en lecture seule</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">Gérer l’accès tiers</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-cly1" rowspan="3">Organisation</td>
    <td class="tg-0lax">Voir tout</td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400;font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Ajouter une organisation</td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Transfert de SIM</td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Performances</td>
    <td class="tg-0lax">Voir tout</td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">✅</span></td>
  </tr>
  <tr>
    <td class="tg-cly1" rowspan="2">Assistance</td>
    <td class="tg-0lax">Voir tout</td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Nouvelle demande de service</td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">❌</span></td>
  </tr>
  <tr>
    <td class="tg-0lax">Accès API</td>
    <td class="tg-0lax"></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">✅</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">❌</span></td>
    <td class="tg-0lax"><span style="font-weight:400,font-style:normal">✅</span></td>
  </tr>
</tbody>
</table>
`}</HTMLBlock>

## Création d’un utilisateur

Un nouvel utilisateur peut être créé via le bouton "New User" en haut à droite. Les informations obligatoires dépendent du type d’utilisateur à créer. L’adresse e-mail est utilisée pour la confirmation du compte ainsi que comme identifiant de connexion aux services Bell. Les clients doivent s’assurer que l’adresse e-mail saisie est valide et peut recevoir des messages. Après la création d’un nouvel utilisateur, un e-mail est envoyé à la nouvelle adresse pour demander la définition d’un mot de passe initial pour le portail client Bell.

<Image align="center" alt={1131} border={false} caption="Fenêtre contextuelle New User pour créer un nouvel utilisateur et lui attribuer un rôle." title="1NCE_Add_User.png" src="https://files.readme.io/3b8d1a9fb7e070e40e352faf3df0bef8980257ae245cb24fa4ce5c8ad41fc9aa-CleanShot_2025-09-26_at_13.14.542x.png" width="80%" />

## Modification du compte utilisateur

En cliquant sur un utilisateur affiché dans la liste des utilisateurs actuels, les détails de ce compte peuvent être modifiés ou supprimés. Les modifications peuvent être appliquées en éditant les champs du formulaire et en enregistrant les nouvelles données. Un utilisateur peut être supprimé en cliquant sur le bouton "Delete" dans la fenêtre contextuelle d’édition de l’utilisateur.

<Image align="center" alt={1132} border={false} caption="Fenêtre contextuelle d’édition de l’utilisateur utilisée pour modifier les détails ou supprimer un utilisateur." title="1NCE_User_Edit.png" src="https://files.readme.io/694845b9eafe7f8c1f050e820684b02ecd6a09bced9070761895fdd636cbbf0a-CleanShot_2025-09-26_at_13.15.152x.png" width="80%" />
