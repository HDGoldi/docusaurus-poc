---
title: "Support"
slug: "portal-performance-support"
excerpt: "Getting Support"
hidden: false
metadata: 
  title: "Bell Portal - Performance and Support | Bell Developer Hub"
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:30:52 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Nov 10 2025 14:37:32 GMT+0000 (Coordinated Universal Time)"
---
# Assistance

Via l’onglet "Assistance", les clients Bell peuvent accéder rapidement aux ressources de documentation ainsi qu’au support technique et au service client. Sur la page, des liens vers le Bell Developer Hub, la référence de l’API et une intégration de recherche pour la documentation sont proposés.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/e2e9c12a7ac7cfca192de870e580ad49c315d339e10211c311d43bdf0f86c2d6-CleanShot_2025-11-10_at_16.36.15.png",
        "",
        "Page Assistance, avec des références vers le Developer Hub, la référence API et le service client."
      ],
      "align": "center",
      "caption": "Page Assistance, avec des références vers le Developer Hub, la référence API et le service client."
    }
  ]
}
[/block]


Le support technique et le service client sont fournis soit directement par téléphone, soit en ouvrant un nouveau ticket de demande de service. L’accès au support technique est réservé aux clients existants. Le service client est assuré en allemand ou en anglais. L’assistance téléphonique est disponible du lundi au vendredi de 9 h à 18 h (CET/CEST) (sauf jours fériés nationaux). Les tickets sont principalement traités pendant les heures de service.
