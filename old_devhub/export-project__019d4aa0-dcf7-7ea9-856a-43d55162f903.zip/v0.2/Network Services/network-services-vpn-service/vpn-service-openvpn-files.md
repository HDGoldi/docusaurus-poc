---
title: "OpenVPN Files"
slug: "vpn-service-openvpn-files"
excerpt: "Configuration of the Bell VPN Service."
hidden: false
metadata: 
  title: "VPN Service - OpenVPN Files | Bell Developer Hub"
  description: "Detailed description of the OpenVPN Files for the Bell VPN Service."
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:28:56 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Nov 10 2025 13:51:53 GMT+0000 (Coordinated Universal Time)"
---
> 📘 Téléchargement des fichiers OpenVPN
> 
> Le fichier de configuration et le fichier d'identifiants peuvent être téléchargés depuis la page de configuration du <a href="https://portal.1nce.com/portal/customer/configuration" target="_blank">Bell Portal</a>.

Cette section fournit une description générale de l'interface de tunnel du service VPN ainsi qu'un aperçu des fichiers de configuration et d'identifiants. Pour des guides d'installation et de test pour différents systèmes d'exploitation, veuillez consulter le <a href="examples-vpn">Guide de configuration VPN</a>.

***

# Interface de tunnel

La connexion du client VPN sur un PC ou un serveur crée une interface réseau de tunnel distincte. Tout le trafic de données émis par le mobile (MO) et reçu par le mobile (MT) est envoyé via cette interface de tunnel et sera routé selon l'adresse IP de destination. Avec le service VPN Bell, l'appareil doté de la SIM Bell peut atteindre le point de terminaison VPN du client en adressant l'IP statique de l'application cliente. Inversement, le serveur d'applications peut joindre chaque appareil individuellement en adressant l'IP statique de la SIM. Pour ouvrir ou tester par ping une connexion du serveur vers l'appareil (SIM), il est important que la SIM soit attachée au réseau et que le modem de l'appareil ait une session de données PDP active.

***

# Fichiers de configuration OpenVPN

## Fichier client VPN

Lors du téléchargement du fichier de configuration VPN (voir extrait ci-dessous), deux formats de fichier différents pour Windows et Linux sont disponibles. Le contenu des deux fichiers est presque identique. La seule différence est l'entrée `auth-user-pass` dans le fichier. Cette ligne indique au client VPN le fichier `credentials.txt` à utiliser pour authentifier l'utilisateur sur le serveur VPN. Le chemin par défaut diffère selon les deux systèmes d'exploitation, mais peut être adapté aux spécificités du système d'exploitation ou du client VPN. L'adresse et le port `remote` du serveur VPN ne doivent pas être modifiés. Il faut s'assurer que le nom de domaine et le port indiqués sont autorisés dans tout pare-feu ou système d'accès afin de permettre une connexion vers le serveur VPN Bell. Le tableau ci-dessous présente la configuration par défaut fournie par Bell. Certains paramètres peuvent être **adaptés** (✔) tandis que d'autres ne doivent **pas être modifiés** (❌). Bell ne recommande pas de modifier la configuration par défaut et ne garantit pas que des changements de configuration fourniront la connectivité attendue.

| Paramètre de configuration                                                                                                                                                                                                                                                                                                                                                                  |        Valeur par défaut        | Personnalisable |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :-----------------------------: | :-------------: |
| **client** </br> Indique que le fichier `xx-region-x-client.ovpn` est une configuration client.                                                                                                                                                                                                                                                                                             |                                 |        ❌        |
| **dev** </br> Périphérique réseau virtuel défini sur Tunnel (TUN), simule un périphérique de couche réseau et fonctionne avec des paquets IPv4 et IPv6 de couche 3. Le nom de l'interface de tunnel peut être modifié en `tun<x>` où `<x>` est un nombre entier.                                                                                                                            |              `tun`              |        ✔        |
| **proto** </br> Paramètre de protocole pour communiquer avec l'hôte distant.                                                                                                                                                                                                                                                                                                                |              `udp`              |        ❌        |
| **remote** </br> Nom d'hôte distant ou adresse IP.                                                                                                                                                                                                                                                                                                                                          |          `<url> <port>`         |        ❌        |
| **resolv-retry** </br> Si la résolution du nom d'hôte pour –remote échoue, réessayer la résolution pendant n secondes avant d'échouer.                                                                                                                                                                                                                                                      |            `infinite`           |        ✔        |
| **nobind** </br> Ne pas lier à l'adresse et au port locaux. La pile IP allouera un port dynamique pour les paquets de retour.                                                                                                                                                                                                                                                               |                                 |        ❌        |
| **explicit-exit-notify** </br> Envoyer au serveur une notification de sortie si le tunnel est redémarré ou si le processus OpenVPN se termine. Nombre de tentatives au cours desquelles le client essaiera de renvoyer la notification de sortie.                                                                                                                                           |               `3`               |        ❌        |
| **keepalive** </br> Simplification de –ping et –ping-restart. Vérifie l'état de la connexion actuelle par un PING ICMP. Paramètres : `<Interval Timeout>`.                                                                                                                                                                                                                                  |              `5 30`             |        ✔        |
| **(user)** </br> Modifier l'ID utilisateur du processus OpenVPN après l'initialisation, en abandonnant les privilèges du processus. Cette option est utile pour protéger le système au cas où une partie hostile parviendrait à prendre le contrôle d'une session OpenVPN. Cette option n'est incluse que dans le fichier `xx-region-x-client.conf` pour les systèmes d'exploitation Linux. |              `root`             |        ✔        |
| **(group)** </br> Groupe facultatif propriétaire de ce tunnel. Cette option n'est incluse que dans le fichier `xx-region-x-client.conf` pour les systèmes d'exploitation Linux.                                                                                                                                                                                                             |            `nogroup`            |        ✔        |
| **persist-key** </br> Ne pas relire les fichiers de clés lors d'un SIGUSR1 ou d'un redémarrage --ping-restart.                                                                                                                                                                                                                                                                              |                                 |        ❌        |
| **persist-tun** </br> Ne pas fermer et rouvrir le périphérique TUN/TAP ni exécuter les scripts up/down lors des redémarrages SIGUSR1 ou --ping-restart.                                                                                                                                                                                                                                     |                                 |        ❌        |
| **remote-cert-tls** </br> Exiger que le certificat du pair soit signé avec un usage de clé explicite et un usage étendu de clé conformément aux règles TLS de la RFC3280.                                                                                                                                                                                                                   |             `server`            |        ❌        |
| **verb** </br> Définir le niveau de verbosité de la sortie. Le niveau 3 est recommandé si vous voulez un bon résumé de ce qui se passe sans être submergé par la sortie.                                                                                                                                                                                                                    |               `3`               |        ✔        |
| **auth-nocache** </br> Le client VPN ne mettra pas en cache dans la mémoire virtuelle le nom d'utilisateur et le mot de passe nécessaires à l'authentification. Cela évitera l'entrée de journal "WARNING: this configuration may cache passwords in memory -- use the auth-nocache option to prevent this" lors de l'établissement de la connexion.                                        |                                 |        ✔        |
| **auth-user-pass** </br> S'authentifier auprès du serveur en utilisant le nom d'utilisateur/mot de passe depuis un fichier contenant le nom d'utilisateur et le mot de passe sur 2 lignes.                                                                                                                                                                                                  | ` /etc/openvpn/credentials.txt` |        ✔        |
| **auth-retry** </br> Contrôle la manière dont OpenVPN réagit aux erreurs de vérification du nom d'utilisateur/mot de passe, telles que la réponse côté client à un message AUTH_FAILED provenant du serveur ou un échec de vérification du mot de passe de la clé privée.                                                                                                                   |           `nointeract`          |        ✔        |
| **tun-mtu** </br> Paramètre optionnel de MTU (Maximum Transmission Units). Dans la plupart des cas, laissez ce paramètre à sa valeur par défaut. En cas de problèmes avec les connexions HTTPS ou SSH, essayez de diminuer cette valeur.                                                                                                                                                    |              `1500`             |        ✔        |
| **certificates** </br> Certificats inclus dans le fichier de configuration.                                                                                                                                                                                                                                                                                                                 |                                 |        ❌        |

Plus d'informations sur les options de configuration se trouvent dans le <a href="https://openvpn.net/community-resources/reference-manual-for-openvpn-2-4/" target="_blank">manuel de référence OpenVPN</a>.

## Avertissement concernant la mise en cache des mots de passe

Si une journalisation détaillée est configurée pour le client OpenVPN, l'avertissement suivant peut apparaître au démarrage du client OpenVPN :

 _WARNING: this configuration may cache passwords in memory -- use the auth-nocache option to prevent this._

Cet avertissement peut être évité en ajoutant le paramètre `auth-nocache` dans le fichier de configuration du client OpenVPN. Cela ne devrait généralement pas avoir d'effets secondaires ; néanmoins, la [documentation officielle](https://community.openvpn.net) indique :  
“Si cette directive est spécifiée, OpenVPN oubliera immédiatement les saisies du nom d'utilisateur et du mot de passe après leur utilisation. Par conséquent, lorsque OpenVPN a besoin d'un nom d'utilisateur/mot de passe, il demandera une saisie via `stdin`, ce qui peut se produire plusieurs fois pendant la durée d'une session OpenVPN.“

## Fichier d'identifiants VPN

Le fichier `credentials.txt` téléchargé depuis le CMP (voir extrait ci-dessous) contient un identifiant utilisateur comme nom d'utilisateur et un jeton d'accès comme mot de passe pour le serveur VPN Bell. Le contenu de ce fichier n'a pas besoin d'être modifié. L'emplacement de ce fichier doit être défini dans le fichier de configuration VPN `xx-region-x-client.ovpn`.

```text credentials.txt
<customer_id>
<vpn_access_token>

 
```
