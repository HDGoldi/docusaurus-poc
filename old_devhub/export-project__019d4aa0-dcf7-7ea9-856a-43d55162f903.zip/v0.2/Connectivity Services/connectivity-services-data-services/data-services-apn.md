---
title: "APN Setup"
slug: "data-services-apn"
excerpt: "Configuring the APN to access the Data Service."
hidden: false
metadata: 
  title: "Data Services - APN Setup | Bell Developer Hub"
  description: "Configuring the APN to access the Data Service."
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:30:17 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Nov 10 2025 14:15:15 GMT+0000 (Coordinated Universal Time)"
---
Un nom de point d’accès (APN) est le nom de la passerelle entre un réseau mobile et un cœur de réseau. L’APN précise vers quel réseau, et quel type exact de réseau, une connexion doit et peut être établie. Dans les réseaux mobiles courants, l’APN définit le nom de la passerelle qui permet la connexion à l’internet ouvert. Ce paramètre doit être configuré pour chaque appareil qui souhaite communiquer avec un service internet.

***

# Configuration de l’APN Bell

> ❗️ Paramétrage de l’APN requis !
> 
> Comme Bell fournit plusieurs APN, il est obligatoire qu’un APN soit configuré. Sans un APN correctement défini, il n’est pas garanti qu’un appareil dispose d’une connexion de données. La configuration automatique de l’APN n’est PAS prise en charge.

La manière de configurer l’APN dépend de l’appareil spécifique utilisé avec une carte SIM Bell. Alors que la plupart des appareils ne nécessitent que l’APN au format URL, certains appareils spécifiques exigent des paramètres supplémentaires.

Les paramètres à définir sont listés dans le tableau ci-dessous. Veuillez noter que l’APN est obligatoire et que certains autres paramètres sont facultatifs ou ne peuvent pas être définis manuellement.

| Paramètre                  | Valeur                                 |
| :------------------------- | :------------------------------------- |
| APN                        | **sensor.net**                         |
| Nom d’utilisateur          | Non requis, laisser vide               |
| Mot de passe               | Non requis, laisser vide               |
| Méthode d’authentification | Password Authentication Protocol (PAP) |
| Protocole Internet         | Version 4 du protocole Internet (IPv4) |

## Nom du point d’accès Bell

Ce paramètre doit être défini sur les appareils utilisant une SIM Bell. Veuillez vous référer au guide du fabricant de l’appareil pour savoir comment définir un APN. Dans la plupart des cas, cela peut être fait via une commande AT spécifique, en envoyant un SMS à l’appareil ou via l’interface utilisateur de l’appareil.

## Authentification

Certains appareils peuvent exiger la définition de la méthode d’authentification, du nom d’utilisateur et du mot de passe. Cette procédure d’authentification peut être demandée par chacune des parties de la connexion lors du processus d’établissement. Les deux procédures d’authentification les plus courantes sont le Password Authentication Protocol (PAP) et le Challenge Handshake Authentication Protocol (CHAP). PAP est l’ancien protocole et repose sur une simple authentification par nom d’utilisateur et mot de passe. CHAP est une méthode plus élaborée et plus sécurisée, basée sur des défis générés aléatoirement.  
Pour l’APN Bell, aucun nom d’utilisateur ni mot de passe n’est nécessaire. Ces paramètres peuvent être laissés vides dans la configuration. La méthode d’authentification PAP doit être sélectionnée par défaut si l’appareil exige ce paramètre.

## Protocole Internet

Certains appareils prennent en charge les versions IPv4 et IPv6 du protocole Internet. Le cœur de réseau de Bell ne prend actuellement en charge qu’IPv4. Par conséquent, IPv4 doit être utilisé.
