---
title: "Data Monitoring"
slug: "data-services-data-monitoring"
excerpt: "Monitoring the Bell Data Service."
hidden: false
metadata: 
  title: "Data Services - Monitoring | Bell Developer Hub"
  description: "Monitoring the Bell Data Service."
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:30:19 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Nov 10 2025 14:15:29 GMT+0000 (Coordinated Universal Time)"
---
Lors de la surveillance du service de données fourni par la connectivité SIM de Bell, il y a plus à explorer que le simple suivi du volume d’utilisation. Grâce à différents moyens tels que le portail Bell, le [service Data Streamer](doc:platform-services-data-streamer) et l’[API 1NCE](https://help.1nce.com/dev-hub/reference/api-welcome), il est possible de surveiller le volume d’utilisation, l’état de connexion des sessions de données et la connectivité des appareils. Les sections suivantes présentent les fonctionnalités et les avantages de chaque interface disponible.

***

# Portail Bell

Le portail web est une interface prête à l’emploi pour surveiller tous les services Bell. Pour chaque SIM, il est possible de consulter l’état actuel de la session de données (contexte PDP), le volume d’utilisation global et les messages d’état. Les enregistrements d’événements du Data Streamer sont répertoriés dans l’interface web. Cela offre une vue d’ensemble de l’état de la SIM Bell. Le portail en ligne constitue un point de départ pour la surveillance non automatisée de petits lots de SIM ou pour le débogage rapide des connexions. Cette plateforme n’offre aucune possibilité d’intégration, et les données de journalisation sont supprimées après sept jours conformément à la politique de conservation des données. Pour plus de détails sur l’utilisation du portail Bell, veuillez consulter le [guide du portail](doc:portal-dashboard).

***

# Data Streamer

Le [service Data Streamer](doc:platform-services-data-streamer) fournit un flux d’enregistrements d’événements et/ou d’utilisation via un large éventail d’applications de connectivité cloud. Le cas d’usage principal est la surveillance automatisée à long terme d’un grand nombre de SIM connectées. Pour le service de données, le volume d’utilisation et les enregistrements d’événements font partie du flux. Les enregistrements d’utilisation sont générés à intervalles réguliers et à la fin d’une session de données. Les enregistrements d’événements indiquent la connectivité générale de l’appareil au réseau mobile ainsi que la création et la suppression d’une session de données. Dans les événements, des avertissements et des erreurs provenant du cœur de réseau sont inclus afin de faciliter le débogage. Davantage de détails sont présentés dans la section [Service Data Streamer](doc:platform-services-data-streamer) de ce guide.

***

# API Bell

L’API Bell est un outil puissant pour interroger à la demande certains paramètres d’information. Un exemple pour le service de données est la récupération des enregistrements de volume d’utilisation cumulés pour chaque carte SIM à différentes échelles temporelles. Les limites d’utilisation des données peuvent être consultées et définies via l’API. En outre, l’état actuel du volume total disponible et du quota utilisé peut être interrogé et, si nécessaire, des recharges de volume peuvent être initiées. Veuillez noter que certaines données ne sont conservées que pendant une durée déterminée en raison de la politique de conservation des données. L’API Bell est idéale pour demander des informations spécifiques à la demande. Il n’est pas recommandé d’utiliser cette interface pour des requêtes volumineuses et automatisées de manière régulière ; veuillez utiliser le service Data Streamer pour ce type d’automatisation. Des détails sur l’API sont disponibles dans la section [guide de l’API](https://help.1nce.com/dev-hub/reference) de la documentation.
