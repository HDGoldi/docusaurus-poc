---
title: "SMS Monitoring"
slug: "sms-services-sms-monitoring"
excerpt: "Monitoring, to keeping your SMS messages on track."
hidden: false
metadata: 
  title: "SMS Services - Monitoring | Bell Developer Hub"
  description: "Monitoring, to keeping your SMS messages on track."
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:30:35 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Nov 10 2025 13:55:05 GMT+0000 (Coordinated Universal Time)"
---
Outre l’envoi et la réception de messages MT‑SMS et MO‑SMS, Bell propose des moyens supplémentaires de surveiller le flux de messages et de récupérer des données de journalisation. Trois options sont disponibles pour explorer et collecter des données à des fins de surveillance : Bell Portal, Bell Data Streamer Service et Bell API. Les sections suivantes présentent les capacités et les avantages de chaque interface disponible.

***

# Bell Portal

Le Bell Portal propose une interface utilisateur simple et prête à l’emploi pour la surveillance des services Bell. Concernant les services SMS, l’utilisation globale du volume et l’état des messages pour chaque SIM sont présentés dans le portail. En outre, la SMS Console offre la fonctionnalité d’envoyer et de recevoir des messages via l’interface web. Les Event Records du Data Streamer sont listés dans l’interface utilisateur. Cela fournit un aperçu rapide des événements en cours de la SIM Bell. Globalement, le portail constitue un bon point de départ pour une surveillance manuelle d’un petit nombre de SIM ou pour un débogage simple. Le portail ne propose pas d’intégration pour l’automatisation et les données de journalisation sont supprimées après sept jours en raison de la politique de rétention des données. Pour plus de détails sur l’utilisation du Bell Portal, veuillez vous référer au guide [My SIMs & SMS Console](doc:portal-sims-sms).

***

# Data Streamer

Le Data Streamer offre un flux d’Event Records et/ou d’Usage Records via un large choix d’applications de connectivité cloud. Ce service est idéal pour une surveillance automatisée à long terme d’un grand nombre de SIM connectées. Concernant les services SMS, le volume d’utilisation des messages et les Event Records pour le SMS Forwarding Service sont inclus dans le Data Streamer. Lors de l’envoi ou de la réception d’un message, une entrée d’Usage Record est envoyée via le service de streaming, indiquant le volume utilisé pour l’envoi d’un message. Les Event Records consignent également les erreurs du SMS Forwarding Service. Si le point de terminaison REST fourni n’est pas joignable ou ne respecte pas la configuration requise, un événement d’erreur HTTP 500 sera enregistré dans le Data Streamer. Dans ce cas, veuillez vérifier la configuration et la disponibilité du point de terminaison HTTP fourni. Davantage de détails sont présentés dans la section [Data Streamer Service](doc:platform-services-data-streamer).

***

# SMS API

L’API Bell ne permet pas seulement d’envoyer des messages SMS via des requêtes HTTP, elle propose également des points de terminaison pour interroger à la demande des informations sur la SIM et le service SMS, et configurer certains paramètres supplémentaires. Cela inclut l’utilisation et les limites de volume SMS, les messages d’état, d’anciens messages avec contenu, etc. Veuillez noter que ces données accessibles via l’API sont conservées au maximum sept jours, conformément à la politique de rétention des données. L’API est idéale pour obtenir, à la demande, des informations de débogage spécifiques. Il n’est pas recommandé d’utiliser l’API pour de larges requêtes automatisées régulières ; veuillez utiliser le Data Streaming Service pour cette automatisation. Des informations détaillées sur l’API sont disponibles dans la section [API](https://help.1nce.com/dev-hub/reference) de la documentation.
