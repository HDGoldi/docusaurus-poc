---
title: "SMS Volume"
slug: "sms-services-sms-volume"
excerpt: "How SMS messages are counted towards the used volume."
hidden: false
metadata: 
  title: "SMS Services - Volume | Bell Developer Hub"
  description: "How SMS messages are counted towards the used volume."
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:30:31 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Nov 10 2025 13:55:20 GMT+0000 (Coordinated Universal Time)"
---
Selon le tarif de la carte SIM Bell, un certain volume de SMS est inclus. L’état actuel du volume pour chacune des SIM peut être consulté dans le Portail Bell ou interrogé via l’API Bell (<https://help.1nce.com/dev-hub/reference>). Les sections suivantes expliquent ce qui est comptabilisé dans l’utilisation du volume SMS et présentent quelques exemples.

***

# Utilisation du volume SMS

Avec une SIM Bell et le service SMS, chaque message MT-SMS et MO-SMS est comptabilisé dans le volume utilisé. Il est important de noter que, du point de vue d’une carte SIM Bell, l’« envoi » et la « réception » de SMS sont tous deux considérés comme une utilisation. Les nouvelles tentatives de livraison, les rapports de livraison, le service de transfert de SMS et les requêtes de l’API SMS ne sont pas comptabilisés dans le volume. 

Les MT-SMS qui ne sont pas délivrés avec succès à un appareil ne seront pas facturés au titre du volume de SMS utilisé.

Pour les MO-SMS, l’utilisation est comptabilisée même si le service de transfert de SMS n’est pas configuré, car le SMS est tout de même acheminé vers le backend de Bell et affiché dans le Portail Bell pour plus de commodité. Une fois le volume de SMS épuisé, aucun autre message ne peut être envoyé tant que le volume n’a pas été rechargé. Tenter d’envoyer un message lorsque le volume est épuisé générera un événement d’avertissement dans le Data Streamer.

***

# Limites de volume SMS définies par le client

Une limite, définie par le client, pour le volume de messages MO-/MT-SMS peut être configurée dans l’onglet Configuration du Portail Bell ou via l’API Bell. Cette limite s’applique au volume de SMS de toutes les SIM de l’organisation. Ces limites peuvent être utilisées pour restreindre, côté réseau, l’utilisation mensuelle du volume de messages pour les SIM. Les limites peuvent être définies par paliers prédéterminés et sont réinitialisées le premier jour de chaque nouveau mois.

## Atteindre et réinitialiser la limite

Si une SIM atteint cette limitation, un message d’erreur sera émis lors de l’envoi d’un nouveau SMS via l’API **Traffic limit of X SMS per month exceeded** ou via le Portail Bell **Set monthly limit of SMS exceeded**. Pour réactiver une SIM, veuillez soit attendre que le volume soit réinitialisé au début du mois, soit augmenter manuellement la limite via l’onglet Configuration du Portail Bell ou l’API Bell. L’envoi d’un MO-SMS alors que la limite de messages MO-SMS est dépassée entraînera le rejet du SMS par le réseau Bell. Ce rejet se traduira par un code d’erreur retourné par le modem de l’appareil.

> ❗️ Avertissement d’erreur : limite dépassée
> 
> Lors de l’utilisation de l’API Bell, si la limite auto-définie est atteinte, **Traffic limit of X SMS per month exceeded** est renvoyé en tant qu’erreur. Dans le Portail Bell, **Set monthly limit of SMS exceeded** s’affiche lorsque la limite de SMS est atteinte et qu’un nouveau SMS est envoyé.  
> Pour les **MO-SMS**, aucune notification ne s’affiche dans le Portail Bell ou le Data Stream. Le SMS sera rejeté par le réseau, ce qui entraînera un code d’erreur renvoyé par le modem de l’appareil.

***

# Exemples de scénarios d’utilisation des SMS

## Un MT/MO-SMS

L’envoi d’**un** MT-SMS ou MO-SMS débitera **un** SMS du volume inclus.

## MT-SMS avec réponse MO-SMS

Le client envoie un MT-SMS via l’API Bell à destination de l’appareil, et l’appareil répond par un MO-SMS au client. Dans ce cas, **un** MT-SMS et **un** MO-SMS sont envoyés, ce qui entraîne une déduction de volume de **deux** SMS.
