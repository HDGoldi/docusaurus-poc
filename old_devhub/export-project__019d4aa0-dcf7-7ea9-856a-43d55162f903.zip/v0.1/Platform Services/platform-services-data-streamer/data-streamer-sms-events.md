---
title: "SMS Events"
slug: "data-streamer-sms-events"
excerpt: "Stream SMS Events including MT Delivery Reports and MO SMS with detailed event specifications and examples."
hidden: false
metadata: 
  title: "Data Streamer - SMS Events | Bell Developer Hub"
  description: "Stream Updates about the SMS Events."
  image: []
  robots: "index"
createdAt: "Sun Nov 09 2025 17:18:05 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Sun Nov 09 2025 19:17:01 GMT+0000 (Coordinated Universal Time)"
---
# SMS Events

The Bell Data Streamer Service provides real-time SMS Events that give you detailed insights into SMS traffic for your IoT devices. This chapter focuses on the two types of SMS Events supported by the platform.

## SMS Event Types

<Cards columns="2">
  <Card title="SMS MT DLR" icon="check-circle">
    MT (Mobile Terminated) Delivery Reports provide status updates for SMS messages sent to devices, including delivery confirmations, failures, and expiry notifications.
  </Card>

  <Card title="SMS MO" icon="mobile-alt">
    MO (Mobile Originated) events represent SMS messages sent from mobile devices to your specified interfaces or applications.
  </Card>
</Cards>

## Event Specifications

### SMS MT DLR (Delivery Report)

SMS MT Delivery Reports are generated when SMS messages sent to devices reach a final state. These events provide delivery status information including successful delivery, failures, or expiration.

**Supported Status Types:**

- `DELIVERED`: Message successfully delivered to the device
- `FAILED`: Message delivery failed
- `EXPIRED`: Message expired before delivery

<Accordion title="SMS MT DLR Example" icon="receipt">
  ```json SMS_MT_DLR.json
  {
    "id": 8891889,
    "submit_date": "2024-12-15T16:55:31Z",
    "final_date": "2024-12-15T16:55:35Z",
    "organisation": {
      "id": 103820
    },
    "endpoint": {
      "id": 100001494,
      "name": "8988228530100000216"
    },
    "status": {
      "status": "DELIVERED",
      "id": 4
    },
    "detail": {
      "sms": {
        "id": "551734281731175386"
      }
    }
  }
  ```
</Accordion>

### SMS MO (Mobile Originated)

SMS MO events represent messages sent from mobile devices to your customer-specified interfaces. These events capture the complete SMS content and routing information.

<Accordion title="SMS MO Example" icon="paper-plane">
  ```json SMS_MO.json
  {
    "id": 8901947,
    "submit_date": "2024-12-16 07:01:00",
    "pid": 0,
    "organisation": {
      "id": 103820
    },
    "dest_address": "338",
    "source_address": "882285301000216",
    "dcs": 0,
    "payload": "34178d09-905a-4289-95b6-da61f966d3e1;1734332456",
    "endpoint": {
      "id": 100001494,
      "name": "8988228530100000216"
    }
  }
  ```
</Accordion>

## SMS Event Properties

<Tabs>
  <Tab title="Common Properties">
    Properties shared across both SMS event types:

```
| Property       | Data Type             | Description                                                  |
| :------------- | :-------------------- | :----------------------------------------------------------- |
| `id`           | LONG (64-bit integer) | Unique identifier for each SMS event                         |
| `submit_date`  | TIMESTAMP (UTC)       | Timestamp when the SMS was submitted in ISO 8601 format      |
| `organisation` | JSON Object           | Organization information containing the organization ID      |
| `endpoint`     | JSON Object           | Endpoint information including ID and name (typically ICCID) |
```

  </Tab>

  <Tab title="SMS MT DLR Properties">
    Specific properties for MT Delivery Report events:

```
| Property     | Data Type       | Description                                          |
| :----------- | :-------------- | :--------------------------------------------------- |
| `final_date` | TIMESTAMP (UTC) | Timestamp when the final delivery status was reached |
| `status`     | JSON Object     | Delivery status information                          |
| `detail`     | JSON Object     | Additional details including original SMS ID         |

**Status Object:**

* `status`: String value (`DELIVERED`, `FAILED`, `EXPIRED`)
* `id`: Numeric status identifier (4 = DELIVERED, 5 = FAILED, 6 = EXPIRED)
```

  </Tab>

  <Tab title="SMS MO Properties">
    Specific properties for Mobile Originated SMS events:

```
| Property         | Data Type | Description                                    |
| :--------------- | :-------- | :--------------------------------------------- |
| `dest_address`   | STRING    | Destination address where the SMS was sent     |
| `source_address` | STRING    | Source address (typically the device's MSISDN) |
| `payload`        | STRING    | The actual SMS message content                 |
| `dcs`            | INTEGER   | Data Coding Scheme (0 = default GSM 7-bit)     |
| `pid`            | INTEGER   | Protocol Identifier (0 = default)              |
```

  </Tab>
</Tabs>

## Object Details

### Organisation Object

Contains information about the customer organization:

| Property | Data Type | Description                                  |
| :------- | :-------- | :------------------------------------------- |
| `id`     | INTEGER   | Unique Bell customer organization identifier |

### Endpoint Object

Represents the device/SIM endpoint:

| Property | Data Type | Description                         |
| :------- | :-------- | :---------------------------------- |
| `id`     | INTEGER   | Unique endpoint identifier          |
| `name`   | STRING    | Endpoint name (typically the ICCID) |

### Detail Object (SMS MT DLR)

Contains additional information specific to delivery reports:

| Property | Data Type   | Description                          |
| :------- | :---------- | :----------------------------------- |
| `sms`    | JSON Object | Contains the original SMS identifier |

**SMS Detail Object:**

- `id`: Original SMS message identifier for correlation

## Integration Notes

- SMS Events are delivered in real-time through the Bell Data Streamer
- Each event includes a unique ID to handle potential retransmissions
- Timestamps are provided in UTC format following ISO 8601 standard
- Status codes are consistent across the platform for reliable processing
