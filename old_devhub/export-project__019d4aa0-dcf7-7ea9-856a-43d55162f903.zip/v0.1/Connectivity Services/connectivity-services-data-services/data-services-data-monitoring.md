---
title: "Data Monitoring"
slug: "data-services-data-monitoring"
excerpt: "Monitoring the Bell Data Service."
hidden: false
metadata: 
  title: "Data Services - Monitoring | Bell Developer Hub"
  description: "Monitoring the Bell Data Service."
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:30:19 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Sun Nov 09 2025 19:15:30 GMT+0000 (Coordinated Universal Time)"
---
When monitoring the data service offered by the Bell SIM connectivity, there is more to explore than just tracking the usage volume. Through different means of the Bell Portal, [Data Streamer Service](doc:platform-services-data-streamer) and [1NCE API](https://help.1nce.com/dev-hub/reference/api-welcome), the usage volume, data session connection state and device connectivity can be monitored. In the following sections, the capabilities and benefits of each available interface is presented.

***

# Bell Portal

The web portal is a ready-to-use interface for monitoring all Bell services. The current status of the data session (PDP context), the overall volume usage, and status messages can be viewed for each SIM. Event records from the data streamer are listed in the web interface. This provides an overview of the state of the Bell SIM. The online portal offers a starting point for non-automated monitoring of small batches of SIM or fast debugging of connections. This platform offers no integration possibilities and the logging data is deleted after seven days due to the data retention policy. For more details on how to use the Bell Portal, please refer to the [Portal Guide](doc:portal-dashboard).

***

# Data Streamer

The [Data Streamer Service](doc:platform-services-data-streamer) delivers a stream of the event and/or usage records via a wide selection of cloud connectivity applications. The main application case is long-term, automated monitoring of large amount of connected SIM. For the data service, usage volume and event records are part of the stream. Usage records are generated at regular intervals and the end of a data session. The event records show the general connectivity of the device to the mobile network and the creation and deletion of a data session. In the events warnings and errors from the network core are included to ease debugging possibilities. More details are covered in the [Data Streamer Service](doc:platform-services-data-streamer) of this guide.

***

# Bell API

The Bell API is a powerful tool for querying certain information parameters on demand. An example for the data service is accumulated volume usage records for each SIM card on different time scales. The data usage limits can be requested and set via the API. Furthermore, the current state of the overall available volume and used quota can be queried, and if needed volume top-ups initiated. Please note that certain data will be retained only a fixed amount of time due to the data retention policy. The Bell API is ideal for requesting specific information on demand. It is not recommended to use this interface for large, automated queries regularly, please use the data streaming service for this kind of automation. Details about the API can be found in the [API guide](https://help.1nce.com/dev-hub/reference) section of the documentation.
