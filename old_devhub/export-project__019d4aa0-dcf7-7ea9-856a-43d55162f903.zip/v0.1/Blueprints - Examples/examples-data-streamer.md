---
title: "Data Streamer Service"
slug: "examples-data-streamer"
excerpt: "Setup Guides and Examples for all Data Streamer Integrations."
hidden: false
metadata: 
  title: "Examples - Data Streamer Service | Bell Developer Hub"
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:29:43 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Sun Nov 09 2025 19:17:59 GMT+0000 (Coordinated Universal Time)"
---
The Bell Data Streamer offers multiple integration possibilities. For each of the available integrations Bell provides a setup guide and examples for testing. Please click on one of the icons to get to the setup guide for the selected integration.

[block:html]
{
  "html": "<div class=\"button-flex-container\">\n\t<div class=\"button-flex-item\">\n    <a href=\"examples-data-streamer-http\">\n      \t<img src=\"https://files.readme.io/d47972b-rest_api.svg\"></img> \n    </a>\n\t</div>\n<div class=\"button-flex-item\">\n  <a href=\"examples-data-streamer-keen\">\n\t\t<img src=\"https://files.readme.io/29d6339-keen_io.svg\"> </img>\n  </a>\n\t</div>\n<div class=\"button-flex-item\">\n  <a href=\"examples-data-streamer-datadog\">\n\t\t<img src=\"https://files.readme.io/720424d-data_dog.svg\"> </img>\n  </a>\n\t</div>\n<div class=\"button-flex-item\">\n  <a href=\"examples-data-streamer-s3\">\n\t\t<img src=\"https://files.readme.io/7f8d984-aws_s3.svg\"> </img>\n  </a>\n\t</div>\n<div class=\"button-flex-item\">\n  <a href=\"examples-data-streamer-kinesis\">\n\t\t<img src=\"https://files.readme.io/c2c9384-aws_kinesis.svg\"> </img>\n  </a>\n\t</div>\n</div>\n\n"
}
[/block]
