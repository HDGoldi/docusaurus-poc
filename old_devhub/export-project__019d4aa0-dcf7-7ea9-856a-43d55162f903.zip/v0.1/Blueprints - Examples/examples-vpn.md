---
title: "VPN Service"
slug: "examples-vpn"
excerpt: "Setting up and using the Bell VPN Service."
hidden: false
metadata: 
  title: "Examples - VPN Service | Bell Developer Hub"
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:29:55 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Sun Nov 09 2025 19:18:18 GMT+0000 (Coordinated Universal Time)"
---
Each Bell SIM has a private IP and is connected via the Internet Breakout using Network Address Translation to the open internet. By default the connection establishment is unidirectional from the SIM device to a server/service in the internet. The Bell VPN Service enables Bell customers to connect and transmit data bidirectional with their SIM devices via a Virtual Private Network (VPN) connection.

This section covers the setup of the Bell VPN client for Windows, Linux and Mac OS to establish a connection with the Bell Network Service. For custom OpenVPN installs, advanced routing or specific application setups refer to the <a href="https://openvpn.net/community-resources/" target="_blank">OpenVPN Documentation</a>.

***

# Setup Guides

For a detailed guide on how to install the VPN Client click on one of the following Operating Systems:

[block:html]
{
  "html": "<div class=\"button-flex-container\">\n\t<div class=\"button-flex-item\">\n    <a href=\"examples-vpn-windows\">\n      \t<img src=\"https://files.readme.io/13f2388-windows.svg\"></img> \n    </a>\n\t</div>\n<div class=\"button-flex-item\">\n  <a href=\"examples-vpn-linux\">\n\t\t<img src=\"https://files.readme.io/193df98-linux.svg\"> </img>\n  </a>\n\t</div>\n<div class=\"button-flex-item\">\n  <a href=\"examples-vpn-macos\">\n\t\t<img src=\"https://files.readme.io/1916674-macos.svg\"> </img>\n  </a>\n\t</div>\n</div>"
}
[/block]
