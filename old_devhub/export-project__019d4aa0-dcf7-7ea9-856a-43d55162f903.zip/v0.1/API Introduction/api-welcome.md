---
title: "Welcome to the API"
slug: "api-welcome"
excerpt: "Getting to know the Bell API."
hidden: false
createdAt: "Mon Aug 05 2024 14:28:31 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Sun Nov 09 2025 19:19:22 GMT+0000 (Coordinated Universal Time)"
---
> 📘 Download YAML Files
> 
> To download the latest OpenAPI files for the Bell API please visit: <https://help.1nce.com/dev-hub/openapi>.

> ❗️ 'Try Out' Feature
> 
> Please note that the 'Try Out' function can be used only with a valid Bell customer account. All queries are made towards the customer account. Be careful with trying out features like orders, top ups, etc. as these API calls will trigger the actual process.

Welcome to the Bell API documentation. This documentation covers the in and outs of the API for managing, controlling, and monitoring the Bell SIM cards and the related services.  This guide is divided into chapters, which group individual, logical topics together.  
As the Bell API requires the users to authorize in order to use the interface, we strongly suggest to start reading the authorization chapters first. 

The API is structured into different categories:

- Authorization
- SIM Management
- Order Management
- Product Information
- Support Management
- Bell OS

These groups are created according to the features of the Bell products.

Besides, documenting the functionality of the possible API requests, this guide offers the opportunity for existing customers to try out the calls with their personal Bell account. As an additional feature, the guide offers ready-to-use code snippets for each query in a wide variety of programming languages. These samples ease the transition from testing out the API to integrating the interfaces into an automated production environment.

If there are any issues or questions regarding the Bell services, feel free to contact our technical support (<a href="[https://1nce.com/en/help-center/support/](https://1nce.com/en-eu/support/contact)" target="_blank">Bell Contact</a>). In case of unclear information or improvement requests, feel free to suggest an edit to the specific page by clicking on the _Suggest Edit_ button. We are thankful for suggestions and feedback from our customers as we continue to improve and develop our services.
