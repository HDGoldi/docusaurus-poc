---
title: "API Rate Limits"
slug: "api-rate-limits"
excerpt: "Know the Limits of the API."
hidden: false
createdAt: "Mon Aug 05 2024 14:28:35 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Sun Nov 09 2025 19:23:11 GMT+0000 (Coordinated Universal Time)"
---
The Bell API can be used by any customer to query and configure settings of Bell SIMs, products and related services. To protect the API from misusage and overloading, certain rate limits for the endpoints are set. The rate limits are derived from analyzing the existing application case patterns of Bell customers. Therefore, the API rate limits should not interfere with common use cases for monitoring or controlling Bell services.  
Listed below are the current rate limits for all endpoints available through the Bell Management API.

[block:parameters]
{
  "data": {
    "h-0": "Endpoint",
    "h-1": "API Rate Limit",
    "0-0": "_Authorization:_  \n/oauth",
    "0-1": "3000 requests per IP address per 5 minutes",
    "1-0": "_SIM Management:_  \n/sims",
    "1-1": "10 requests per second per Customer",
    "2-0": "_Order Management:_  \n/orders",
    "2-1": "100 requests per IP address per 5 minutes",
    "3-0": "_Product Information:_  \n/products",
    "3-1": "100 requests per IP address per 5 minutes"
  },
  "cols": 2,
  "rows": 4,
  "align": [
    "left",
    "left"
  ]
}
[/block]


***

# Large SIM Batch Monitoring

Despite the SIM Management endpoints not having any rate limit set, it is advised to be gentle with the SIM Management API usage. Bell recommends to avoid very regular, high frequency API access with large number of requests for monitoring. The Bell API is a great tool for monitoring and querying data, but for regular monitoring of large SIM batches Bell recommends to use the Data Streamer Service. The streaming service allows to monitor SIM Events and Usages as it offers near real-time monitoring without the need to query the API regularly.

If there are any issues or questions regarding the API integration, feel free to contact our <a href="[https://1nce.com/en/help-center/support/]([https://1nce.com/en-eu/support](https://1nce.com/en-eu/support/contact))" target="_blank">Bell Support</a> for technical guidance.
