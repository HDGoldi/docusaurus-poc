---
title: "API Authorization"
slug: "api-authorization"
excerpt: "Using the Access Token for API Queries."
hidden: false
createdAt: "Mon Aug 05 2024 14:28:33 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Sun Nov 09 2025 19:19:58 GMT+0000 (Coordinated Universal Time)"
---
The Bell API uses the commonly applied Open Authorization (OAuth) to manage access to the general API resources. Please note that this API reference uses the actual provided Bell user account to execute the requests.

**Auth Request:**

- Use Bell Connectivity Management Platform (CMP) or API user credentials.
- Base64 encoded username/password using basic authentication in the request header.

**Auth Response:**

- Response contains the status code, token, type, validity timer, user id and scope.
- Returned token is of type String with a length of about 3000 characters.
- Use the token for any following Bell API requests.
- Token needs to be renewed after token timer expires. Default validity of a token is 3600 seconds (one hour).

To give the Auth authentication a try, go to the [Create Access Token](ref:postaccesstokenpost) API Explorer page. Insert the Bell user credentials (username/password) into the API Explorer on the right side of the documentation. Afterwards, by clicking the _Try It_ button, the API request is send and the response with the Access Token will be shown.

Copy the response token for future usage of the following API requests.

***

# Bell API Bearer Access Token

Besides, the initial OAuth requests, every other Bell API call requires authorization with the obtained Bearer Access Token. 

**Bell API Requests:**

- Use Authorization Bearer Header with the obtained OAuth token.
- The token needs to be valid and not expired.
- Renew expired token with [Create Access Token](ref:postaccesstokenpost).
- Request Body and Parameters according to API Explorer documentation.

**Bell API Responses:**

- Bell API returns valid JSON objects.
- API Explorer shows examples of JSON and return codes.

To give the API Explorer a try and to complete the code samples, insert the Access Bearer Token obtained from the [Create Access Token](ref:postaccesstokenpost) API call in the _OAuth2 Auth Bearer_ field. Afterwards, any API requests in the API Explorer as well as the code samples can be used to try the functionality.

![](https://files.readme.io/31edaa2-api_explorer_bearer_auth.png "api_explorer_bearer_auth.png")
