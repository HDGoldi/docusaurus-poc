---
title: "Get SIM Data Quota"
slug: "getdataquotaforsimusingget"
excerpt: "Get the current data quota of a particular SIM."
hidden: false
createdAt: "Mon Aug 05 2024 14:32:26 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Sun Nov 09 2025 19:26:13 GMT+0000 (Coordinated Universal Time)"
---
