---
title: "Create Connectivity Reset"
slug: "resetconnectivityusingpost"
excerpt: "Trigger a connectivity reset for a given SIM. The actual reset will be done asynchronously. A positive-response only means that the connectivity-reset has been successfully placed into the queue."
hidden: false
createdAt: "Mon Aug 05 2024 14:32:26 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Sun Nov 09 2025 19:26:13 GMT+0000 (Coordinated Universal Time)"
---
