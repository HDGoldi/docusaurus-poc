---
title: "Get SIM Events"
slug: "geteventsforsimusingget"
excerpt: "Get diagnostic/event information for a SIM card."
hidden: false
createdAt: "Mon Aug 05 2024 14:32:26 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Sun Nov 09 2025 19:26:13 GMT+0000 (Coordinated Universal Time)"
---
