---
title: "Cancel SMS"
slug: "cancelsmsofsimusingdelete"
excerpt: "Cancel a SMS message that is buffered to be delivered to the device with the SIM card but was not yet delivered."
hidden: false
createdAt: "Sun Nov 09 2025 19:26:13 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Sun Nov 09 2025 19:26:14 GMT+0000 (Coordinated Universal Time)"
---
