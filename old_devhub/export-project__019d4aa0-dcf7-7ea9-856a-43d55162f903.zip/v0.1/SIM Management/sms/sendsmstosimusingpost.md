---
title: "Create SMS"
slug: "sendsmstosimusingpost"
excerpt: "Create and send an MT-SMS to a device."
hidden: false
createdAt: "Mon Aug 05 2024 14:32:26 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Sun Nov 09 2025 19:26:14 GMT+0000 (Coordinated Universal Time)"
---
