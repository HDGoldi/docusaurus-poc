---
title: "Get SMS Details"
slug: "getsmsofsimusingget"
excerpt: "Query details about an individual SMS from a specific SIM card."
hidden: false
createdAt: "Mon Aug 05 2024 14:32:26 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Sun Nov 09 2025 19:26:14 GMT+0000 (Coordinated Universal Time)"
---
