---
title: "Obtain Access Token"
slug: "postaccesstokenpost"
excerpt: "Obtain a token for accessing other 1NCE API resources by using a POST request with a valid username and password combination for a 1NCE user account that has the permission to use the API."
hidden: false
createdAt: "Mon Aug 05 2024 14:32:24 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Aug 05 2024 14:32:24 GMT+0000 (Coordinated Universal Time)"
---
