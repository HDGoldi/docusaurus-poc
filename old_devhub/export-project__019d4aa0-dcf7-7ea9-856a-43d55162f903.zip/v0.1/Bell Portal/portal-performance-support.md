---
title: "Support"
slug: "portal-performance-support"
excerpt: "Getting Support"
hidden: false
metadata: 
  title: "Bell Portal - Performance and Support | Bell Developer Hub"
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:30:52 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Nov 10 2025 14:43:18 GMT+0000 (Coordinated Universal Time)"
---
***

# Support

Through the "Support" tab, Bell customers can quickly access documentation resources as well as technical support and customer service. On the page, links to the Bell Developer Hub, API Reference and a search integration for the documentation is given.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/e2e9c12a7ac7cfca192de870e580ad49c315d339e10211c311d43bdf0f86c2d6-CleanShot_2025-11-10_at_16.36.15.png",
        "",
        "Page Assistance, avec des références vers le Developer Hub, la référence API et le service client."
      ],
      "align": "center"
    }
  ]
}
[/block]


Technical support and customer service is provided either directly via phone or by placing a new service request ticket. The access to technical support is only available for existing customers. Customer service is provided either in German or English language. Telephone support is available from Monday to Friday from 9 a.m. to 6 p.m. (CET/CEST) (except for national public holidays). Tickets are mainly processed within the service hours.
