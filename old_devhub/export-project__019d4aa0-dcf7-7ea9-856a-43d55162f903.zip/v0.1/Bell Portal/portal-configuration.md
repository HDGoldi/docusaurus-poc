---
title: "Configuration"
slug: "portal-configuration"
excerpt: "Bell Services Configuration and Setup"
hidden: false
metadata: 
  title: "Bell Portal - Configuration | Bell Developer Hub"
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:30:53 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Nov 10 2025 14:42:13 GMT+0000 (Coordinated Universal Time)"
---
# Network Settings

The network settings contain the basic information to get the SIM Cards connected to the Bell network.

| Parameter           |                                                                                                                                                                                                                                                                      |
| :------------------ | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `APN`               | Needs to be set in the very first step to set up a connection to the network.                                                                                                                                                                                        |
| `SMSC Number`       | Is generally needed to aim all Mobile Originated SMS in the network, although this setting is rarely needed for manual configuration.                                                                                                                                |
| `Internet Breakout` | Shows the IP addresses used for all Bell SIMs to access the public internet through a NAT. Get all available [Internet Breakout IPs](https://help.1nce.com/dev-hub/docs/network-services-internet-breakout)                                                          |
| `IP Address Space`  | Shows the IP spaces assigned to SIMs in the given organization. Each SIM has a static IP address which can to be used for direct access via the VPN Service. Additional IP spaces will be assigned for new SIM orders if the remaining IP space is not large enough. |
| `IP Addresses`      | Shows the availability of the IP address spaces assigned to the organization.                                                                                                                                                                                        |

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/5604462911f298868fcf0670b125568dc9a3c96b2717ee37c7f0417fc4f7fa6a-CleanShot_2025-11-10_at_16.32.14.png",
        "",
        ""
      ],
      "align": "center"
    }
  ]
}
[/block]


***

# Monthly Limits

By using "Monthly Limits" a customer can set an individual monthly data and SMS limit. The SMS limit can be configured separately for Mobile Originated (MO) and Mobile Terminated (MT) SMS. These limits will be applied to all of the customer's SIMs. By checking or unchecking the boxes these options can be set or cancelled easily at any time. The limits apply to the period of the calendar month. Putting another limit in the same month will not reset the previously consumed quota.  
Example: The first limit is 100 MB. After reaching it you put in 200 MB as a new limit. Now only 100 additional MB can be consumed because the previously consumed 100 MB are considered.

## Exceeding the Limits

When the self-set limits are exceeded, error or warning messages are triggered based on the type of limit.

### Data Session

When the limit is reached, new PDP data sessions will be rejected: **PDP Context Request rejected, because endpoint is currently blocked due to exceeded traffic limit.**  However, some devices might retry indefinitely to reconnect in such a case. Bell strongly advices to use a back-off approach in this rejection case to not flood the network with PDP session requests.

### MT-SMS

Using the Bell API, if the self-set limit for MT-SMS is reached, **Traffic limit of X SMS per month exceeded** is returned as error.  
In the Bell Portal **Set monthly limit of SMS exceeded** is shown, when the MT-SMS limit was reached and a new SMS is issued.

### MO-SMS

For **MO-SMS** no notification will be shown in the Bell Portal or Data Stream. The SMS will be rejected by the network resulting in an error return code from the device modem.

<br />

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/f2c6c9d6cc8d548a9169948ca85f3a1df7b55031b653d72da65dfaa262a443f9-CleanShot_2025-11-10_at_16.31.48.png",
        "",
        "Configuration des limites mensuelles pour les données et les MO-/MT‑SMS."
      ],
      "align": "center"
    }
  ]
}
[/block]


***

# Global IMEI Lock

A global IMEI Lock can be set for all SIM Cards of the organization. The IMEI lock works by saving the IMEI of the device the SIM is installed in. With the feature enabled, the Bell network will only accept the saved device IMEI - SIM card combination to access the network resource. Any other IMEI - SIM combination will be refused. If this feature is activated, the IMEI lock will be set during the next network attach. Consequently the SIM card can only be used with the current device. For new SIM Card orders a checkbox can be selected to enable the IMEI lock by default. This way newly ordered SIMs will have the IMEI Lock set automatically. A separate IMEI lock for individual cards of the organization can be set either via the Bell API or in the "My SIMs" tab.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/d84921f788e511c6c5511383e297aaa4795c76833af6213da51ff196412bfcb2-CleanShot_2025-11-10_at_16.31.40.png",
        "",
        "Paramètres du verrouillage IMEI global des SIM."
      ],
      "align": "center"
    }
  ]
}
[/block]


***

# Data Streams

The Bell Data Streaming Service allows customers to subscribe to real-time events and usage data for all SIM Cards by pushing data directly to the customer's server or an already integrated cloud service such as AWS Kinesis.

The Data Streams configuration shows a list of all currently configured streams including the name, API type, stream type, URL, status indicator and controls for each stream. Each stream can be controlled individually. Besides basic stop, start and delete, a stream integration can be restarted. A restart needs to be performed if the stream enters a error state and needs to be recovered.

To create a new data stream integration click on the New Data Stream button. Further details on how to setup a stream integration can be found in the [Data Streamer Setup Guides](doc:streamer-setup) section of the Developer Hub.

<br />

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/7f051788d6241633d53bf27d58c9b3ab60d4925c73240d3b32bc15fbd21e3529-CleanShot_2025-11-10_at_16.31.57.png",
        "",
        "Vue d’ensemble des intégrations Data Streamer actuelles."
      ],
      "align": "center"
    }
  ]
}
[/block]


***

# OpenVPN Configuration

OpenVPN is the recommended application setup by Bell to establish a secure, bidirectional data connection between the Bell network and the customer server.

When the should OpenVPN be used first, on the account the enrollement to the service needs to be starte.

<br />

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/674fd9f8fa211c5589e0e5d3cd8e6bacc619a4f6b6304d4cf332e5ee87104a42-CleanShot_2025-11-10_at_16.31.28.png",
        "",
        "Configuration spécifique pour le breakout en mode manuel (Europe)."
      ],
      "align": "center"
    }
  ]
}
[/block]


The OpenVPN client needs to be installed on the customer server to which the SIMs should access via the VPN client IP. For the OpenVPN connection to the Bell network a configuration file and credentials file is needed. These files can be downloaded in this section of the Bell Customer Portal. There are two different versions for Windows and for Linux/MacOS available. For more details about the VPN Service, its setup and operation users can proceed to the [VPN Service](doc:network-services-vpn-service) section of the Developer Hub.
