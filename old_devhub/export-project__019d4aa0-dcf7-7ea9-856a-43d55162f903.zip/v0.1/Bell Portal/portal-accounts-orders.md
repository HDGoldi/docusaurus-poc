---
title: "Account"
slug: "portal-accounts-orders"
excerpt: "Account Management"
hidden: false
metadata: 
  title: "Bell Portal - Accounts and Orders | Bell Developer Hub"
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:30:57 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Nov 10 2025 14:42:45 GMT+0000 (Coordinated Universal Time)"
---
# Account

The "Account" tab allows the customer to view and edit their personal/company data, billing and shipping addresses as well as to manage the Auto-Top-Up payment.

> ❗️ Non-Changeable Data Fields
> 
> Due to legal reasons we cannot allow to change the company name or billing country of the billing address. For assistance please contact our support.

In the Customer and User Data dropdown, the contact information and account details for the root organization and for the logged-in user can be viewed and changed. Note that the e-mail address shown in the Customer Data column is the main contact where all invoices are being sent to digitally. An additional e-mail address can be stored which receives the invoices in copy, for example the accounting department. Please select the category "Invoice" for that.  
Furthermore the category "Volume Notifications" can be selected. This includes all e-mails on volume notifications for data/SMS as well as reaching the monthly set volume limit.  
The language selection defines the contact language meaning e-mails, invoices and service notifications.

In the User Data column information regarding the currently logged-in user data can be viewed and changed. The logged-in user (no matter which role) can change their personal details like name and e-mail address as well as password. These details can also be changed by an Admin or Owner via the "Users" tab except the password for the roles Owner, Admin and User.

The Billing and Shipping Addresses dropdown shows all saved billing and shipping addresses. Existing entries can be changed and new addresses can be added by the customer for future orders. The addresses are stored and will appear each time the user orders additional SIM cards or Top-Ups.

<br />

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/117d1f5b1d597d89c4adc4ed3fc2c4f7f6076fd17e186ac32c2e7b96d7035dd3-CleanShot_2025-11-10_at_16.28.12.png",
        "",
        ""
      ],
      "align": "center"
    }
  ]
}
[/block]


***

# Orders

In the "Orders" tab, all orders from the organization's Bell account are listed. The table provides an overview of the important order parameters as well as the current status of an order. The status indicator (completed, in preparation or cancelled) can be used to monitor pending orders.  
On this page, previous invoices of specific orders can be downloaded. Additionally, a CSV list of all SIMs of a particular order can be downloaded using the link in the "Affected SIMs" column. This list for a dedicated order consists of ICCID, label, IMSI and MSISDN of the SIMs. In case there has been any correction to the order, the corrected or updated invoices can be downloaded in the column "Additional Documents".

<br />

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/f24fcc8363c7925db94fa18061ac94a124eb2da3e144c9c72c77e8c02698a9f3-CleanShot_2025-11-10_at_16.29.11.png",
        "",
        ""
      ],
      "align": "center"
    }
  ]
}
[/block]


# Management API Access

We offer RESTful APIs for seamless device management. To access them, generate API credentials in the section below. Communication with the API is done over HTTP(S) requests with JSON body content of content-type "application/json" and authorization type oauth2 (OAuth2, application) required for every API call.
