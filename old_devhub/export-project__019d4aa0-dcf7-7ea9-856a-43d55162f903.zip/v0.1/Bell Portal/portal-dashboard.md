---
title: "Dashboard"
slug: "portal-dashboard"
excerpt: "SIM Status Overview of the Bell Organization."
hidden: false
metadata: 
  title: "Bell Portal - Dashboard | Bell Developer Hub"
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:30:56 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Nov 10 2025 14:38:59 GMT+0000 (Coordinated Universal Time)"
---
After logging into to the Bell Customer Portal, an overview Dashboard is presented. The page shows the current SIM status, volume usage and a current order overview from the organization.

<br />

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/c24444d31b23009c4953099654918836bf54bb2e0e987f7dcfddb4b9ac6b1525-CleanShot_2025-11-10_at_16.20.55.png",
        "",
        "Aperçu du tableau de bord du portail client Bell."
      ],
      "align": "center",
      "caption": "Aperçu du tableau de bord du portail client Bell."
    }
  ]
}
[/block]


***

# SIM Status

The "SIM Status" tile shows the current percentage of Bell SIMs that are activated and deactivated. SIMs can be (de-)activated by the customer to disable/enable the SIM specific connectivity. This process can be done via the Bell Portal or the Bell API.

***

# Data Volume & Usage

Regarding the data volume and usage, two tiles are presented in the dashboard. Details about the SIM specific quota and usage can be viewed in the "My SIMs" tab.

The "Data Volume" tile shows the amount of SIMs with sufficient volume (greater 20%), low volume (less than 20%), and no volume. SIM Cards with sufficient or low volume still operate as expected, but an eye should be kept on SIMs with low volume. SIMs with the status "No Volume" have exceeded the purchased volume and have been blocked from accessing the data connection. These SIMs need to be topped up to receive new data volume credits. They can still connect to the network and send/receive SMS if sufficient SMS volume is present.

The overall data usage of the organization is shown in the "Data Usage" plot. This plot shows the accumulated weekly volume in megabytes used over the last eight weeks. For more detailed usage records, the Bell API or Bell Data Streamer integration can be used.

***

# SMS Volume & Usage

Similar to the data volume and usage, two tiles for the SMS volume and usage are presented in the dashboard. Details for specific SIMs can be accessed via the "My SIMs" page.

The SMS volume tile shows the amount of SIMs with sufficient volume (more than 20%), low volume (less than 20%), and no volume. Once a SIM has no SMS volume left, the data services can still be used but no further SMS can be sent or received. The SIM needs to be topped up to receive new SMS credits.

The SMS usage is shown in a plot accumulated weekly for the last eight weeks. For more detailed usage records, the Bell API or Bell Data Streamer integration can be used.
