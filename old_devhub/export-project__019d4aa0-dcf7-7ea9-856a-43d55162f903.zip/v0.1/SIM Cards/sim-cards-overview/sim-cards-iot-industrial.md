---
title: "IoT SIM Card Industrial"
slug: "sim-cards-iot-industrial"
excerpt: "Basics about the Bell IoT SIM Cards Industrial."
hidden: false
metadata: 
  title: "Bell SIM Cards - IoT Industrial | Bell Developer Hub"
  image: []
  robots: "index"
createdAt: "Mon Aug 05 2024 14:30:45 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Dec 01 2025 21:12:58 GMT+0000 (Coordinated Universal Time)"
---
The form factor of the IoT SIM Card Industrial is identical to the IoT SIM Card Business with the plastic 3in1 format. The main differences are within the SIM chip, software and environmental ruggedness of the SIM card.  
This section will cover the basics about the physical IoT SIM Cards Industrial form factor, technical specifications as well as recommendations for IoT hardware application cases.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/adc55b48364a2342b968cd2c557d5102daf848e7cb2e0988b787ce54d7872f30-SIM-EN.png",
        null,
        "Overview of the 1NCE 3in1 IoT SIM Cards Industrial, which includes the 2FF, 3FF and 4FF form factors. "
      ],
      "align": "center",
      "sizing": "30% ",
      "caption": "Overview of the Bell 3in1 IoT SIM Cards Industrial, which includes the 2FF, 3FF and 4FF form factors. "
    }
  ]
}
[/block]


***

# IoT SIM Cards Industrial Form Factor

Over the years, with the hardware miniaturization and especially IoT use cases for mobile networks, the physical SIM Card format was adapted multiple times to make the overall footprint smaller. As the IoT SIM Chip Industrial design and layout was retained to provide backwards combability, the surrounding plastic format was changed. As a result, four common IoT SIM Cards Industrial form factors (1-4 FF) were established. Original full-size IoT SIM Cards Industrial (1FF) had the typical credit card form factor. As this standard is used only rarely today, it has been phased out of production. The remainder 2FF, 3FF and 4FF are still commonly used and sold as 3in1 breakout, plastic-backed SIM Cards. The four IoT SIM Cards Industrial form factors are specified in <a href="https://www.etsi.org/deliver/etsi_ts/102200_102299/102221/15.00.00_60/ts_102221v150000p.pdf" target="blank_">ETSI TS 102 221</a>. The exact dimension specifications of the form factors are listed in the table below. 

|               | 2FF - Mini SIM | 3FF - Micro SIM | 4FF - Nano SIM           |
| :------------ | :------------- | :-------------- | :----------------------- |
| **Height**    | 25mm           | 15mm            | 12.3mm ± 0.1 mm          |
| **Width**     | 15mm           | 12mm            | 8.8mm                    |
| **Thickness** | 0.76mm         | 0.76mm          | 0.67mm +0.03 mm/-0.07 mm |

Bell IoT SIM Cards Industrial are 3in1 plastic-backed SIMs which incorporate the standardized 2FF Mini, 3FF Micro and 4FF Nano form factors. The Bell IoT SIM Cards Industrial are shipped in a half-size carrier to make handling and shipping of the breakout SIMs easier. Depending on the customer needs the IoT SIM Cards Industrial can be carefully broken down into the needed form factor and also reassembled back up to 2FF Mini with the supplied adapters.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/20aeb83-1NCE_4FF_SIM_Dimensions.png",
        "1NCE_4FF_SIM_Dimensions.png",
        1064
      ],
      "align": "center",
      "sizing": "smart",
      "caption": "Bell IoT SIM Cards Industrial 4FF reference dimensions and pin assignment as of ETSI TS 102 221."
    }
  ]
}
[/block]


As 4FF is the smallest form factor that minimizes the plastic-backed SIM Card to the bare IC, we will use it as reference for the pinout. The pinout is the same for all IoT SIM Cards Industrial as the SIM IC is identical. Shown above is the pinout reference and dimensions of the 4FF SIM according to <a href="https://www.etsi.org/deliver/etsi_ts/102200_102299/102221/15.00.00_60/ts_102221v150000p.pdf" target="blank_">ETSI TS 102 221</a>. While the Bell IoT SIM Cards 4FF and eSIM MFF2 form factor are different, the pinout of the actual ICs are the same. The pinout table references the pinout of the dimensional reference figure for the 4FF IoT SIM Cards Industrial.

[block:parameters]
{
  "data": {
    "h-0": "Contact Pin",
    "h-1": "Spec. Description",
    "h-2": "Bell IoT SIM Cards Industrial Pinout",
    "0-0": "C1",
    "0-1": "**VCC**  \nSupply Voltage",
    "0-2": "VCC",
    "1-0": "C2",
    "1-1": "**RST**  \nReset Pin",
    "1-2": "RST",
    "2-0": "C3",
    "2-1": "**CLK**  \nClock Signal",
    "2-2": "CLK",
    "3-0": "C4 and C8",
    "3-1": "**Optional**  \nUSB interface according to ETSI TS 102 600",
    "3-2": "N/A",
    "4-0": "C5",
    "4-1": "**GND**  \nGround Connection",
    "4-2": "GND",
    "5-0": "C6",
    "5-1": "**VPP**  \nProgramming Voltage",
    "5-2": "N/A",
    "6-0": "C7",
    "6-1": "**I/O**  \nInput Output Data",
    "6-2": "I/O"
  },
  "cols": 3,
  "rows": 7,
  "align": [
    "left",
    "left",
    "left"
  ]
}
[/block]


***

# Shipping & Assembly Packaging

Bell 3in1 IoT SIM Cards Industrial are packaged in a half-size breakout card to save on plastic wastage. This makes handling and shipping of the different SIM form factors easier. Each of these breakout cards, shown below, contains one 3in1 SIM. For easier identification, on the back of the cards a barcode and numerical representation of the EAN code and the ICCID is printed. When ordering low quantities of IoT SIM Cards Industrial, the cards will be packaged and shipped in small plastic-wrapped packages. For larger orders will be fulfilled by shipping boxes of 100 or 500 SIMs respectively. These boxes are packaged in sequence, lowest to highest ICCID with a label sticker indicating the first and last ICCID of the box.

***

# IoT SIM Cards Industrial eID Identification

An eID is a 32-digit global unique identifier number, containing information that uniquely identifies the physical SIM.  Using the eUICC feature, the eID is the most important number to identify the SIM as the ICCID may change with the active profile. The eID is unique to the IoT SIM, and will remain always the same.

The eID can be read by the hardware modem using an AT-Command or manufacturer-specific request. For easier physical identification, each Bell IoT SIM Card Industrial has the eID of the particular SIM printed on the 4FF physical chip card.

For more information about eID, please, refer to the official [GSMA documentation](https://www.gsma.com/esim/resources/sgp-29-v1-0-eid-definition-and-assignment-process/)

***

# IoT SIM Cards Industrial Specifications

SIM Cards for mobile network applications follow strict standards for the physical form factor as well as the technology and interfaces. Bell IoT SIM Cards Industrial complies with these technical standard specifications. Besides the key standard compliances, SIM Cards are validated for specific environmental ranges in which they need to be operated in. The table below shows the most important Bell IoT SIM Cards Industrial specifications that are relevant for the deployment of the Bell IoT SIM Cards Industrial. Furthermore, references to the key standard compliances for the SIM interfaces are listed.

[block:html]
{
  "html": "<div class=\"rdmd-table\">\n\t<div class=\"rdmd-table-inner\">\n\t<style type=\"text/css\">.tdc { text-align:center;}</style>\n\t\t<table>\n\t\t\t<thead>\n\t\t\t\t<tr>\n\t\t\t\t\t<th>Parameter</th>\n\t\t\t\t\t<th>1NCE IoT SIM Card Industrial (3in1)</th>\n\t\t\t\t</tr>\n\t\t\t</thead>\n\t\t\t<tbody>\n\t\t\t\t<tr>\n\t\t\t\t\t<td>Form Factors (FF)</td>\n\t\t\t\t\t<td class=\"tdc\">2FF - Mini, 3FF - Micro, 4FF - Nano</td>\n\t\t\t\t</tr>\n\t\t\t\t<tr>\n\t\t\t\t\t<td>Supported Radio Access Technologies (RAT)</td>\n\t\t\t\t\t<td class=\"tdc\">2G, 3G, 4G, CAT-M1, NB-IoT</td>\n\t\t\t\t</tr>\n\t\t\t\t<tr>\n\t\t\t\t\t<td>Environmental Temperature</td>\n\t\t\t\t\t<td class=\"tdc\">-40°C to +105°C</td>\n\t\t\t\t</tr>\n\t\t\t\t<tr>\n\t\t\t\t\t<td>Operating Voltages</td>\n\t\t\t\t\t<td class=\"tdc\">Class A, B and C (1.62V – 5.5V)</td>\n\t\t\t\t</tr>\n\t\t\t\t<tr>\n\t\t\t\t\t<td>Data Retention Period</td>\n\t\t\t\t\t<td class=\"tdc\">min. 10 years</td>\n\t\t\t\t</tr>\n        <tr>\n\t\t\t\t\t<td>Number of profiles</td>\n\t\t\t\t\t<td class=\"tdc\">max. 10 </td>\n\t\t\t\t</tr>\n\t\t\t\t<tr>\n\t\t\t\t\t<td>Read/Write Cycles</td>\n\t\t\t\t\t<td class=\"tdc\">min. 2.000.000 cycles</td>\n\t\t\t\t\t<tr>\n\t\t\t\t\t\t<td>Key Standard Compliances</td>\n\t\t\t\t\t\t<td class=\"tdc\"><a href=\"https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=1833\" target=\"blank_\">3GPP TR 31.919</a></td>\n\t\t\t\t\t</tr>\n\t\t\t\t\t<tr>\n\t\t\t\t\t\t<td/>\n\t\t\t\t\t\t<td class=\"tdc\"><a href=\"https://www.etsi.org/deliver/etsi_ts/101200_101299/101220/13.01.00_60/ts_101220v130100p.pdf\" target=\"blank_\">ETSI TS 101 220</a></td>\n\t\t\t\t\t</tr>\n\t\t\t\t\t<tr>\n\t\t\t\t\t\t<td/>\n\t\t\t\t\t\t<td class=\"tdc\"><a href=\"https://www.etsi.org/deliver/etsi_ts/102200_102299/102221/15.00.00_60/ts_102221v150000p.pdf\" target=\"blank_\">ETSI TS 102 221</a></td>\n\t\t\t\t\t</tr>\n\t\t\t\t\t<tr>\n\t\t\t\t\t\t<td/>\n\t\t\t\t\t\t<td class=\"tdc\"><a href=\"https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=1802\" target=\"blank_\">3GPP TS 31.101</a></td>\n\t\t\t\t\t</tr>\n\t\t\t\t\t<tr>\n\t\t\t\t\t\t<td/>\n\t\t\t\t\t\t<td class=\"tdc\"><a href=\"https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=1807\" target=\"blank_\">3GPP TS 31.111</a></td>\n\t\t\t\t\t</tr>\n\t\t\t\t\t<tr>\n\t\t\t\t\t\t<td/>\n\t\t\t\t\t\t<td class=\"tdc\"><a href=\"https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=1831\" target=\"blank_\">3GPP TR 31.900</a></td>\n\t\t\t\t\t</tr>\n\t\t\t\t</tbody>\n\t\t\t</table>\n\t\t</div>\n\t</div>"
}
[/block]


***

# IoT SIM Cards Industrial Application Cases

As the plastic-backed IoT SIM Cards Industrial is currently still the most commonly used form factor in the mobile communication field, it is best suited as a general-purpose SIM for most off-the-shelve, ready-to-use IoT devices. The 3in1 form factor of the Bell IoT SIM Cards Industrial is compatible with a wide range of devices that accept this standardized form factor. This form factor of SIM is easy to install, exchange, swappable between devices and ready for the IoT production environment. These key features make the Bell IoT SIM Cards Industrial ideal for every stage of the IoT device life cycle, from early, flexible prototyping to deploying thousands of devices in the field. Also, Bell IoT SIM Cards Industrial are ideal for more demanding environments due to their enhanched physical attributes, for example, operating temperature.

For any open questions about the detailed 1NCE IoT SIM Cards Industrial product or more extensive help in selecting the right IoT SIM for the specific application case, feel free to contact us (<a href="https://1nce.com/en-eu/support" target="_blank">1NCE Contact</a>).
