---
title: "IoT SIM Chip Industrial"
slug: "sim-chips-iot-industrial"
excerpt: "Embedded SIM Card Specifications"
hidden: false
createdAt: "Mon Aug 05 2024 14:30:46 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Dec 01 2025 21:13:20 GMT+0000 (Coordinated Universal Time)"
---
The traditional plastic-backed SIM originated from the user equipment (UE) usage for telecommunication where customers needed to exchange SIMs easily as the devices were not bound to a particular SIM. Starting in 2016, the embedded SIM (eSIM) or embedded Universal Integrated Circuit Card (eUICC) gained interest from developers due to its smaller footprint and deeper integration possibilities. 

Especially in custom embedded Machine-to-Machine (M2M) and IoT hardware application cases, the IoT SIM Chip Industrial offers unique advantages compared to the traditional IoT SIM Card Business. In purpose-built IoT devices, there is no need for regular manual SIM Card swaps. Key factors like ruggedness, security and space constraints have high priority. For these special needs, the Bell IoT SIMs Chip Industrial provides the ideal solution. This section covers the Bell IoT SIM Chip Industrial product with its standardized form factor, technology specifications and outline recommended application cases.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/b30798f48082f8990c54f95717d8fa2ddc737dca1f4adceb1a5158115e1df41d-industrialSIM-EN.png",
        null,
        "1NCE IoT SIM Chip Industrial MFF2 Integrated Circuit."
      ],
      "align": "center",
      "sizing": "20% ",
      "caption": "Bell IoT SIM Chip Industrial MFF2 Integrated Circuit."
    }
  ]
}
[/block]


***

# IoT SIM Chip Industrial Form Factor

As the IoT SIM Chip Industrial evolved from the traditional IoT SIM Card Business, it shares the same technological functionality but just in a smaller physical packaged form factor. The IoT SIM Chip Industrial format is commonly designated as MFF2. The Bell IoT SIM Chip Industrial conforms to this MFF2 footprint in a Quad-Flat No-Leads 8 (QFN8) Integrated Circuit (IC) package. The MFF2 package is specified in <a href="https://www.etsi.org/deliver/etsi_ts/102600_102699/102671/09.00.00_60/ts_102671v090000p.pdf" target="blank_">ETSI 102 671</a>.

The QFN8 IoT SIM Chip Industrial package is not mounted inside a socketed adapter like the IoT SIM Card Business, it is designed to be directly soldered to the Printed Circuit Board (PCB) of a device. QFN8 is an often used footprint in electronic devices. Thus, it can be easily integrated into automated assembly production lines of IoT-enabled devices. The specifications of the form factor are shown in the figure below.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/8f83e1d-1NCE_eSIM_Dimensions.png",
        "1NCE_eSIM_Dimensions.png",
        1827
      ],
      "align": "center",
      "sizing": "80",
      "caption": "Bell MFF2 IoT SIM Chip Industrial Form Factor Dimensions"
    }
  ]
}
[/block]


Embedded-SIMs share the same basic pinout as IoT SIMs Card Business but in a different form factor shown in the figure above. The following table references the pin assignments and lists their respective functional pinout.

[block:parameters]
{
  "data": {
    "h-0": "Contact Pin",
    "h-1": "Spec. Description",
    "h-2": "Bell IoT SIM Chip Industrial Pinout",
    "0-0": "C1",
    "0-1": "**VCC**  \nSupply Voltage",
    "0-2": "VCC",
    "1-0": "C2",
    "1-1": "**RST**  \nReset Pin",
    "1-2": "RST",
    "2-0": "C3",
    "2-1": "**CLK**  \nClock Signal",
    "2-2": "CLK",
    "3-0": "C4 and C8",
    "3-1": "**Optional**  \nUSB interface according to ETSI TS 102 600",
    "3-2": "N/A",
    "4-0": "C5",
    "4-1": "**GND**  \nGround Connection",
    "4-2": "GND",
    "5-0": "C6",
    "5-1": "**VPP**  \nProgramming Voltage",
    "5-2": "N/A",
    "6-0": "C7",
    "6-1": "**I/O**  \nInput Output Data",
    "6-2": "I/O"
  },
  "cols": 3,
  "rows": 7,
  "align": [
    "left",
    "left",
    "left"
  ]
}
[/block]


***

# Shipping & Assembly Packaging

When ordering Bell IoT SIMs Chip Industrial, the QFN8 ICs are packaged in a standardized tape reel of 100, 500 and 3000 IoT SIMs Chip Industrial. These tape reels can be directly used in an automated production assembly line.

Bell IoT SIMs Chip Industrial are packaged in 12mm wide tape, which is 1.2mm thick and covered with a plastic film to keep the IoT SIM Chip Industrial ICs in place until production. The packing process and materials meet the requirements defined in JEDEC J-STD-033 with ESD precautions and proper handling procedures. The tape is provided on 7-inch (178mm) and 13-inch (330mm) reels. For lots of 100 or 500 IoT SIMs Chip Industrial, 7-inch reels are used and for 3000 IoT SIMs Chip Industrial 13-inch reels are used.

**Package outline**

![](https://files.readme.io/948f33a84761c2c4213387a79b00b93ada17bd9f27b427c05946effbe0481ca9-image.png)

**Package Footprint**

![](https://files.readme.io/7b3b41cd125600e0c8d6df30071c4aef89fcb9c1fa54cc4c86b4004f10c08a3e-image.png)

**Tape & Reel packing**

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/9fb616e62a74da6e4531c348a40b45daff2e61201909b0af1c8fc4f0b1db682a-image.png",
        null,
        ""
      ],
      "align": "right",
      "sizing": "-3px",
      "border": true
    }
  ]
}
[/block]


_<https://www.infineon.com/dgdl/Infineon-Integration_Guide_SLx16_SLx17-AdditionalTechnicalInformation-v01_00-EN.pdf?fileId=5546d46273a5366f0173e8316de94622>_

Each reel is vacuum packaged separately with a humidity indicator card, desiccant and a barcode label in a reel cardboard box. The barcode label shows the first and last IoT SIM Chip Industrial ICCID of the specific reel. IoT SIMs Chip Industrial are produced in sequence in ascending order where the smallest ICCID is produced first and is at the end of the tape in the middle of the reel. The user direction of unreeling is according to EIA-481 standard.

***

# IoT SIM Chip Industrial eID Identification

An eID is a 32-digit global unique identifier number, containing information that identifies the SIM supplier for the physical SIM.  Using eUICC feature, the eID is the most important number to identify the SIM. The ICCID may change with the change of the active profile, but eID is unique to the IoT SIM, and it is always the same.

The eID can be read by the hardware modem using an AT-Command or manufacturer-specific request. For easier physical identification, each 1NCE IoT SIM Card Industrial has the eID of the particular SIM printed on the 4FF physical chip card.

For more information about eID, please, refer to the official [GSMA documentation](https://www.gsma.com/esim/resources/sgp-29-v1-0-eid-definition-and-assignment-process/) 

***

# IoT SIM Chip Industrial Specifications

SIM Cards for mobile network applications follow strict standards for the physical form factor as well as the technology and interfaces. 1NCE IoT SIMs Chip Industrial comply with these technical standard specifications. Besides the key standard compliances, SIM Chips are validated for specific environmental ranges in which they need to be operated in.  The table below shows the most important 1NCE IoT SIM Chip Industrial specifications that are relevant for the deployment of the 1NCE IoT SIM Chip Industrial. Furthermore, references to the key standard compliances for the SIM interfaces are referenced.

[block:html]
{
  "html": "<div class=\"rdmd-table\">\n\t<div class=\"rdmd-table-inner\">\n\t<style type=\"text/css\">.tdc { text-align:center;}</style>\n\t\t<table>\n\t\t\t<thead>\n\t\t\t\t<tr>\n\t\t\t\t\t<th>Parameter</th>\n\t\t\t\t\t<th>1NCE IoT SIM Chip Industrial</th>\n\t\t\t\t</tr>\n\t\t\t</thead>\n\t\t\t<tbody>\n\t\t\t\t<tr>\n\t\t\t\t\t<td>Form Factor (FF)</td>\n\t\t\t\t\t<td class=\"tdc\">MFF2, QFN8 (IC Package)</td>\n\t\t\t\t</tr>\n\t\t\t\t<tr>\n\t\t\t\t\t<td>Supported Radio Access Technologies (RAT)</td>\n\t\t\t\t\t<td class=\"tdc\">2G, 3G, 4G, CAT-M1, NB-IoT</td>\n\t\t\t\t</tr>\n\t\t\t\t<tr>\n\t\t\t\t\t<td>Environmental Temperature</td>\n\t\t\t\t\t<td class=\"tdc\">-40°C to +105°C</td>\n\t\t\t\t</tr>\n\t\t\t\t<tr>\n\t\t\t\t\t<td>Operating Voltages</td>\n\t\t\t\t\t<td class=\"tdc\">Class A, B and C (1.62V – 5.5V)</td>\n\t\t\t\t</tr>\n\t\t\t\t<tr>\n\t\t\t\t\t<td>Data Retention Period</td>\n\t\t\t\t\t<td class=\"tdc\">min. 10 years</td>\n\t\t\t\t</tr>\n         <tr>\n\t\t\t\t\t<td>Number of profiles</td>\n\t\t\t\t\t<td class=\"tdc\">max. 10 </td>\n\t\t\t\t</tr>\n\t\t\t\t<tr>\n\t\t\t\t\t<td>Read/Write Cycles</td>\n\t\t\t\t\t<td class=\"tdc\">min. 2.000.000 cycles</td>\n\t\t\t\t\t<tr>\n\t\t\t\t\t\t<td>Key Standard Compliances</td>\n\t\t\t\t\t\t<td class=\"tdc\"><a href=\"https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=1833\" target=\"blank_\">3GPP TR 31.919</a></td>\n\t\t\t\t\t</tr>\n\t\t\t\t\t<tr>\n\t\t\t\t\t\t<td/>\n\t\t\t\t\t\t<td class=\"tdc\"><a href=\"https://www.etsi.org/deliver/etsi_ts/101200_101299/101220/13.01.00_60/ts_101220v130100p.pdf\" target=\"blank_\">ETSI TS 101 220</a></td>\n\t\t\t\t\t</tr>\n\t\t\t\t\t<tr>\n\t\t\t\t\t\t<td/>\n\t\t\t\t\t\t<td class=\"tdc\"><a href=\"https://www.etsi.org/deliver/etsi_ts/102200_102299/102221/15.00.00_60/ts_102221v150000p.pdf\" target=\"blank_\">ETSI TS 102 221</a></td>\n\t\t\t\t\t</tr>\n\t\t\t\t\t<tr>\n\t\t\t\t\t\t<td/>\n\t\t\t\t\t\t<td class=\"tdc\"><a href=\"https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=1802\" target=\"blank_\">3GPP TS 31.101</a></td>\n\t\t\t\t\t</tr>\n\t\t\t\t\t<tr>\n\t\t\t\t\t\t<td/>\n\t\t\t\t\t\t<td class=\"tdc\"><a href=\"https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=1807\" target=\"blank_\">3GPP TS 31.111</a></td>\n\t\t\t\t\t</tr>\n\t\t\t\t\t<tr>\n\t\t\t\t\t\t<td/>\n\t\t\t\t\t\t<td class=\"tdc\"><a href=\"https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=1831\" target=\"blank_\">3GPP TR 31.900</a></td>\n\t\t\t\t\t</tr>\n\t\t\t\t</tbody>\n\t\t\t</table>\n\t\t</div>\n\t</div>"
}
[/block]


***

# Application Cases IoT SIM Chip Industrial

Embedded-SIMs reduce the footprint of the SIM integration and also provide a more rugged and robust connection. In general, the IoT SIM Chip Industrial form factor is more optimized for typical IoT device environments where factors like heavy vibration, higher temperature ranges but also increased security plays a key role. 1NCE recommends the integration of IoT SIMs Chip Industrial in custom developed IoT devices and use cases where extraordinary environmental robustness is needed.  
As the IoT SIMs Chip Industrial is surface mounted to the PCB of a device, it provides higher security against end-user tampering as the SIM Card cannot be easily removed. For prototyping and designing custom IoT devices, special QFN8 adapters are available to adapt an IoT SIM Chip Industrial to the IoT SIM Card Industrial footprint.

For any open questions about the detailed 1NCE IoT SIM Chip Industrial product or more extensive help in selecting the right IoT SIM for the specific application case, feel free to contact us (<a href="https://1nce.com/en-eu/support" target="_blank">1NCE Contact</a>).
